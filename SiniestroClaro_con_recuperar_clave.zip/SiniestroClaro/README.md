# SiniestroClaro · Seguimiento móvil del estado de siniestros

**Asignatura:** DSY1105 Desarrollo de Aplicaciones Móviles · Duoc UC (Evaluación Parcial 2)
**Caso C05:** Servicios Corporativos Andes SpA (BPO de gestión de siniestros)
**Integrantes:** _Nombre Apellido_ · _Nombre Apellido_  — Sección 001D · Equipo _EQ0XX_

App Android (Kotlin + Jetpack Compose + Material Design 3) para que la persona asegurada reporte un siniestro,
vea su etapa, el historial y los documentos pendientes, y reciba avisos sin llamar a nadie.
Todos los datos son **ficticios** (Anexo 9 del cliente).

## Funcionalidades
| Requerimiento | Qué hace la app |
|---|---|
| RF-01 | Ingreso con RUT validado (módulo 11) y contraseña. **¿Olvidaste tu contraseña?** (RUT + correo registrado + código de un solo uso) y **Cambiar contraseña** desde el menú ⋮. Las claves se guardan con hash SHA-256 + sal. |
| RF-02/03 | Formulario de reporte validado campo a campo; entrega número `SIN-AA-NNNNNN`. Aviso de posible duplicado y de reporte fuera de plazo. |
| RF-04/05 | Lista de siniestros (abiertos primero) y detalle con etapa, compañía, liquidador (RN-14) y **próximo paso**. |
| RF-06 | Historial cronológico en lenguaje simple; las gestiones internas no se muestran (RN-13). |
| RF-07/08 | Adjuntar foto (cámara) o archivo (imagen/PDF ≤ 5 MB, máx. 15); documentos solicitados / entregados / pendientes. |
| RF-09 | Avisos dentro de la app + **notificaciones locales** que abren el siniestro. |
| RF-10/11/12 | Panel del liquidador (demo): asignar, registrar gestión, pedir documento, avanzar y cerrar, con reglas RN-01/08/09. |
| RNF-05/06 | Funciona sin conexión (Room), muestra fecha de la última información y guarda el borrador del reporte. |
| RNF-10 | RUT enmascarado en pantalla. |

## Cómo ejecutar
1. Instalar **Android Studio** (Koala o superior, JDK 17 incluido).
2. `File ▸ Open` y elegir esta carpeta. Esperar el *Gradle Sync* (necesita internet la primera vez).
3. Conectar un celular Android 8.0+ con **Depuración USB** activada (o crear un emulador) y presionar ▶ **Run**.
4. Para obtener el **APK**: `Build ▸ Build Bundle(s) / APK(s) ▸ Build APK(s)`.
   Queda en `app/build/outputs/apk/debug/app-debug.apk`; se puede copiar al teléfono e instalar
   (permitir «instalar apps desconocidas»).
5. En la pantalla de ingreso, tocar un asegurado de ejemplo (completa RUT y la contraseña de demo `Claro2026`) y luego **Ingresar**.

Prueba sugerida: Camila Rojas ▸ Mis siniestros ▸ SIN-26-004801 ▸ Documentos ▸ Adjuntar (cámara).
Luego menú ⋮ ▸ *Panel del liquidador* ▸ solicitar un documento o avanzar la etapa ▸ volver y ver el aviso.

## Arquitectura (MVVM)
```
app/src/main/java/cl/duoc/siniestroclaro
├── data/local        Room: entidades, DAOs, base de datos y datos de ejemplo
├── data/repository   SiniestroRepository (única fuente de datos; aquí irá Retrofit en la EFT)
├── domain            Reglas y validaciones puras (RUT, reporte, adjuntos, etapas) – sin Android
├── di                AppContainer (inyección manual)
├── util              Sesión, notificaciones, archivos, conexión, fechas
└── ui                theme · components · navigation · screens/<pantalla> (Screen + ViewModel)
```
Las validaciones viven en `domain/Validadores.kt` y los ViewModels solo exponen estado; las pantallas
únicamente lo dibujan. Pruebas unitarias en `app/src/test`.

## Recursos nativos
- **Cámara** (permiso en tiempo de ejecución, foto guardada en almacenamiento privado vía FileProvider).
- **Selector de archivos** del teléfono (imagen/PDF).
- **Notificaciones** (permiso POST_NOTIFICATIONS en Android 13+, con explicación previa).
- **Estado de red** para el modo sin conexión.

## Seguridad y datos personales
Contraseñas solo como hash con sal (nunca en texto plano ni en SharedPreferences); mensaje de error genérico en el ingreso y la recuperación; código de recuperación con vencimiento y límite de intentos; sin datos médicos/bancarios; backup desactivado; tráfico en claro deshabilitado; archivos solo en
almacenamiento privado; nombres de archivo saneados; RUT enmascarado.

## Pendiente para la EFT
API REST Spring Boot + Retrofit, pruebas del backend, notificaciones push (FCM), RF-13 a RF-18.
