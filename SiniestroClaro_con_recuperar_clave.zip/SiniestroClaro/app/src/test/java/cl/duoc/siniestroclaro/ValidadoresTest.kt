package cl.duoc.siniestroclaro

import cl.duoc.siniestroclaro.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate

class ValidadoresTest {
    private val hoy = LocalDate.of(2026, 10, 27)
    private val valido = ReporteForm(
        companiaId = 1, tipoId = 1, fechaOcurrencia = hoy.minusDays(1),
        comuna = "Maipú", descripcion = "Me chocaron en un semáforo"
    )

    @Test fun rutValidoConPuntosYGuion() = assertTrue(RutValidator.esValido("15.842.371-5"))
    @Test fun rutDeOchoCaracteres() = assertTrue(RutValidator.esValido("94185521"))
    @Test fun rutConDigitoIncorrecto() = assertFalse(RutValidator.esValido("15.842.371-4"))
    @Test fun rutVacioDaMensaje() = assertEquals("Escribe tu RUT", RutValidator.validar(""))
    @Test fun rutSeEnmascara() = assertEquals("**.***.371-5", RutValidator.enmascarar("158423715"))

    @Test fun reporteCompletoNoTieneErrores() =
        assertFalse(ReporteValidator.validar(valido, hoy, true).hayErrores)

    @Test fun fechaFuturaEsInvalida() {
        val e = ReporteValidator.validar(valido.copy(fechaOcurrencia = hoy.plusDays(1)), hoy, true)
        assertEquals("La fecha no puede ser posterior a hoy", e.fecha)
    }

    @Test fun descripcionCortaEsInvalida() =
        assertNotNull(ReporteValidator.validar(valido.copy(descripcion = "corto"), hoy, true).descripcion)

    @Test fun comunaConNumerosEsInvalida() =
        assertNotNull(ReporteValidator.validar(valido.copy(comuna = "Maipu123"), hoy, true).comuna)

    @Test fun companiaInactivaNoAdmiteReportes() =
        assertNotNull(ReporteValidator.validar(valido, hoy, false).compania)

    @Test fun faltanTodosLosCamposObligatorios() {
        val e = ReporteValidator.validar(ReporteForm(), hoy, null)
        assertNotNull(e.compania); assertNotNull(e.tipo); assertNotNull(e.fecha); assertNotNull(e.comuna); assertNotNull(e.descripcion)
    }

    @Test fun adjuntoEnCasoCerradoSeRechaza() {
        val e = AdjuntoValidator.validar("Fotografía del daño", true, "", Etapa.CERRADO, 0)
        assertNotNull(e.general)
    }

    @Test fun adjuntoSuperaMaximoDeDocumentos() =
        assertNotNull(AdjuntoValidator.validar("X", true, "", Etapa.EVALUACION, Limites.MAX_ADJUNTOS).general)

    @Test fun pdfMayorA5MbSeRechaza() =
        assertNotNull(AdjuntoValidator.errorArchivo("application/pdf", Limites.MAX_BYTES + 1))

    @Test fun formatoNoPermitidoSeRechaza() =
        assertNotNull(AdjuntoValidator.errorArchivo("text/plain", 100))

    @Test fun noSePuedePasarALiquidacionConPendientes() =
        assertNotNull(ReglasEtapa.validarAvance(Etapa.EVALUACION, 1))

    @Test fun sePuedePasarALiquidacionSinPendientes() =
        assertNull(ReglasEtapa.validarAvance(Etapa.EVALUACION, 0))

    @Test fun cierreDesdeRecibidoSoloComoDesistido() =
        assertEquals(listOf(Resultado.DESISTIDO), ReglasEtapa.resultadosPermitidos(Etapa.RECIBIDO))

    @Test fun proximoPasoConDocumentosPendientes() =
        assertTrue(ProximoPaso.texto(Etapa.EVALUACION, 2).contains("documentos pendientes"))

    @Test fun liquidadorSeMuestraConInicialDelApellido() =
        assertEquals("Paulina F. – Equipo Vehículos", Formato.responsable("Paulina Fernández Ruiz", "Vehículos", true))

    // ---- contraseña, correo y código de recuperación ----
    @Test fun claveVaciaDaMensaje() = assertEquals("Escribe tu contraseña", ClaveValidator.validar(""))
    @Test fun claveCortaEsInvalida() = assertNotNull(ClaveValidator.validar("abc123"))
    @Test fun claveSinNumerosEsInvalida() = assertEquals("Incluye letras y números", ClaveValidator.validar("soloLetras"))
    @Test fun claveConEspaciosEsInvalida() = assertEquals("No uses espacios", ClaveValidator.validar("Clave 2026x"))
    @Test fun claveValidaNoTieneError() = assertNull(ClaveValidator.validar("Claro2026"))
    @Test fun clavesDistintasNoCoinciden() =
        assertEquals("Las contraseñas no coinciden", ClaveValidator.confirmacion("Claro2026", "Claro2027"))
    @Test fun nuevaIgualALaActualEsInvalida() = assertNotNull(ClaveValidator.distintaDeLaActual("Claro2026", "Claro2026"))

    @Test fun correoInvalido() = assertNotNull(CorreoValidator.validar("camila@"))
    @Test fun correoValido() = assertNull(CorreoValidator.validar("camila.rojas@correo.ejemplo"))
    @Test fun correoSeEnmascara() = assertEquals("ca***@correo.ejemplo", CorreoValidator.enmascarar("camila.rojas@correo.ejemplo"))

    @Test fun hashNoGuardaTextoPlanoYCoincide() {
        val sal = ClaveHasher.nuevaSal()
        val h = ClaveHasher.hash("Claro2026", sal)
        assertNotEquals("Claro2026", h)
        assertTrue(ClaveHasher.coincide("Claro2026", sal, h))
        assertFalse(ClaveHasher.coincide("Claro2027", sal, h))
    }

    @Test fun codigoCorrectoDentroDeLaVigencia() {
        val g = CodigoRecuperacion()
        val c = g.emitir(1_000L)
        assertEquals(CodigoValidator.LARGO, c.length)
        assertEquals(ResultadoCodigo.CORRECTO, g.verificar(c, 2_000L))
    }

    @Test fun codigoVencidoSeRechaza() {
        val g = CodigoRecuperacion(vigenciaMs = 1_000L)
        val c = g.emitir(0L)
        assertEquals(ResultadoCodigo.EXPIRADO, g.verificar(c, 5_000L))
    }

    @Test fun codigoSeBloqueaTrasTresIntentos() {
        val g = CodigoRecuperacion()
        val c = g.emitir(0L)
        val malo = if (c == "000000") "111111" else "000000"
        assertEquals(ResultadoCodigo.INCORRECTO, g.verificar(malo, 1L))
        assertEquals(ResultadoCodigo.INCORRECTO, g.verificar(malo, 2L))
        assertEquals(ResultadoCodigo.BLOQUEADO, g.verificar(malo, 3L))
        assertEquals(ResultadoCodigo.BLOQUEADO, g.verificar(c, 4L))
    }
}
