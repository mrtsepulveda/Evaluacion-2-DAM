package cl.duoc.siniestroclaro.ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import cl.duoc.siniestroclaro.SiniestroApp
import cl.duoc.siniestroclaro.di.AppContainer

@Composable
fun rememberContainer(): AppContainer =
    (LocalContext.current.applicationContext as SiniestroApp).container

/** Crea un ViewModel inyectándole el contenedor de dependencias. */
@Composable
inline fun <reified VM : ViewModel> appViewModel(
    key: String? = null,
    crossinline crear: (AppContainer) -> VM
): VM {
    val container = rememberContainer()
    return viewModel<VM>(key = key, factory = viewModelFactory { initializer<VM> { crear(container) } })
}
