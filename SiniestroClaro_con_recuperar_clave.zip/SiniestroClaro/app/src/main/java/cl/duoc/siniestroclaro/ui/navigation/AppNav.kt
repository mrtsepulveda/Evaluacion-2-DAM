package cl.duoc.siniestroclaro.ui.navigation

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import cl.duoc.siniestroclaro.di.AppContainer
import cl.duoc.siniestroclaro.ui.screens.adjuntar.AdjuntarScreen
import cl.duoc.siniestroclaro.ui.screens.avisos.AvisosScreen
import cl.duoc.siniestroclaro.ui.screens.detalle.DetalleScreen
import cl.duoc.siniestroclaro.ui.screens.clave.CambiarClaveScreen
import cl.duoc.siniestroclaro.ui.screens.clave.RecuperarClaveScreen
import cl.duoc.siniestroclaro.ui.screens.home.HomeScreen
import cl.duoc.siniestroclaro.ui.screens.liquidador.LiquidadorScreen
import cl.duoc.siniestroclaro.ui.screens.login.LoginScreen
import cl.duoc.siniestroclaro.ui.screens.reportar.ReportarScreen

object Rutas {
    const val LOGIN = "login"
    const val HOME = "home"
    const val DETALLE = "detalle/{id}"
    const val REPORTAR = "reportar"
    const val ADJUNTAR = "adjuntar/{id}?solicitudId={solicitudId}"
    const val AVISOS = "avisos"
    const val LIQUIDADOR = "liquidador"
    const val RECUPERAR = "recuperar"
    const val CAMBIAR_CLAVE = "cambiar_clave"

    fun detalle(id: Int) = "detalle/$id"
    fun adjuntar(id: Int, solicitudId: Int?) = "adjuntar/$id" + (solicitudId?.let { "?solicitudId=$it" } ?: "")
}

@Composable
fun AppNav(container: AppContainer, abrirId: Int, alConsumir: () -> Unit) {
    val nav = rememberNavController()
    val sesion by container.session.aseguradoId.collectAsStateWithLifecycle()
    val inicio = remember { if (container.session.aseguradoId.value != null) Rutas.HOME else Rutas.LOGIN }

    // Abrir el siniestro correspondiente cuando se toca una notificación.
    LaunchedEffect(abrirId, sesion) {
        if (abrirId > 0 && sesion != null) {
            nav.navigate(Rutas.detalle(abrirId))
            alConsumir()
        }
    }

    NavHost(
        navController = nav,
        startDestination = inicio,
        enterTransition = { slideInHorizontally(tween(300)) { it / 4 } + fadeIn(tween(300)) },
        exitTransition = { fadeOut(tween(200)) },
        popEnterTransition = { fadeIn(tween(250)) },
        popExitTransition = { slideOutHorizontally(tween(300)) { it / 4 } + fadeOut(tween(250)) }
    ) {
        composable(Rutas.LOGIN) {
            LoginScreen(
                onIngreso = { nav.navigate(Rutas.HOME) { popUpTo(Rutas.LOGIN) { inclusive = true } } },
                onOlvide = { nav.navigate(Rutas.RECUPERAR) }
            )
        }
        composable(Rutas.RECUPERAR) {
            RecuperarClaveScreen(onBack = { nav.popBackStack() }, onListo = { nav.popBackStack() })
        }
        composable(Rutas.CAMBIAR_CLAVE) {
            CambiarClaveScreen(onBack = { nav.popBackStack() }, onListo = { nav.popBackStack() })
        }
        composable(Rutas.HOME) {
            HomeScreen(
                onDetalle = { nav.navigate(Rutas.detalle(it)) },
                onReportar = { nav.navigate(Rutas.REPORTAR) },
                onAvisos = { nav.navigate(Rutas.AVISOS) },
                onLiquidador = { nav.navigate(Rutas.LIQUIDADOR) },
                onCambiarClave = { nav.navigate(Rutas.CAMBIAR_CLAVE) },
                onSalir = {
                    container.session.cerrar()
                    nav.navigate(Rutas.LOGIN) { popUpTo(Rutas.HOME) { inclusive = true } }
                }
            )
        }
        composable(Rutas.DETALLE, arguments = listOf(navArgument("id") { type = NavType.IntType })) { e ->
            val id = e.arguments!!.getInt("id")
            DetalleScreen(id, onBack = { nav.popBackStack() }, onAdjuntar = { sol -> nav.navigate(Rutas.adjuntar(id, sol)) })
        }
        composable(Rutas.REPORTAR) {
            ReportarScreen(
                onBack = { nav.popBackStack() },
                onVerSiniestro = { id ->
                    nav.navigate(Rutas.detalle(id)) { popUpTo(Rutas.REPORTAR) { inclusive = true } }
                }
            )
        }
        composable(
            Rutas.ADJUNTAR,
            arguments = listOf(
                navArgument("id") { type = NavType.IntType },
                navArgument("solicitudId") { type = NavType.IntType; defaultValue = -1 }
            )
        ) { e ->
            AdjuntarScreen(
                siniestroId = e.arguments!!.getInt("id"),
                solicitudId = e.arguments!!.getInt("solicitudId"),
                onBack = { nav.popBackStack() }
            )
        }
        composable(Rutas.AVISOS) {
            AvisosScreen(onBack = { nav.popBackStack() }, onDetalle = { nav.navigate(Rutas.detalle(it)) })
        }
        composable(Rutas.LIQUIDADOR) { LiquidadorScreen(onBack = { nav.popBackStack() }) }
    }
}
