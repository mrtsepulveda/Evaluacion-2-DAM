package cl.duoc.siniestroclaro.ui.screens.avisos

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import cl.duoc.siniestroclaro.data.local.AvisoEntity
import cl.duoc.siniestroclaro.di.AppContainer
import cl.duoc.siniestroclaro.ui.appViewModel
import cl.duoc.siniestroclaro.ui.components.EstadoVacio
import cl.duoc.siniestroclaro.util.Fechas
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class AvisosViewModel(private val c: AppContainer) : ViewModel() {
    val avisos: StateFlow<List<AvisoEntity>> = c.session.aseguradoId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList()) else c.repo.avisos(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun abrir(a: AvisoEntity) { viewModelScope.launch { c.repo.marcarLeido(a.id) } }
    fun marcarTodos() {
        val id = c.session.aseguradoId.value ?: return
        viewModelScope.launch { c.repo.marcarTodosLeidos(id) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AvisosScreen(onBack: () -> Unit, onDetalle: (Int) -> Unit) {
    val vm = appViewModel { AvisosViewModel(it) }
    val avisos by vm.avisos.collectAsStateWithLifecycle()
    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Avisos") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Volver") } },
            actions = { TextButton(onClick = vm::marcarTodos) { Text("Marcar leídos") } }
        )
    }) { padding ->
        if (avisos.isEmpty()) {
            EstadoVacio(Icons.Filled.NotificationsNone, "Sin avisos por ahora", "Te avisaremos cuando algo cambie en tu caso.",
                Modifier.padding(padding))
        } else LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(avisos, key = { it.id }) { a ->
                Card(
                    onClick = { vm.abrir(a); onDetalle(a.siniestroId) }, modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (a.leido) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.primaryContainer
                    )
                ) {
                    Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Icon(if (a.leido) Icons.Filled.Drafts else Icons.Filled.MarkEmailUnread, null)
                        Column {
                            Text(a.motivo + if (!a.leido) " · Nuevo" else "", style = MaterialTheme.typography.titleMedium,
                                fontWeight = if (a.leido) FontWeight.Normal else FontWeight.Bold)
                            Text(a.mensaje, style = MaterialTheme.typography.bodyLarge)
                            Text(Fechas.fechaHora(a.fechaHora), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}
