package cl.duoc.siniestroclaro.domain

/** Reglas de las etapas (RN-01, RN-09) y textos de referencia (Aclaración 2). */
object ReglasEtapa {
    fun validarAvance(actual: Etapa, pendientes: Int): String? = when {
        actual == Etapa.CERRADO -> "El siniestro ya está cerrado"
        actual == Etapa.EVALUACION && pendientes > 0 ->
            "Primero deben estar todos los documentos entregados ($pendientes pendiente(s))"
        actual == Etapa.LIQUIDACION -> "Para terminar el caso usa la opción «Cerrar caso»"
        else -> null
    }

    fun resultadosPermitidos(e: Etapa): List<Resultado> = when (e) {
        Etapa.RECIBIDO -> listOf(Resultado.DESISTIDO)
        Etapa.EVALUACION -> listOf(Resultado.RECHAZADO, Resultado.DESISTIDO)
        Etapa.LIQUIDACION -> listOf(Resultado.APROBADO, Resultado.RECHAZADO)
        Etapa.CERRADO -> emptyList()
    }
}

object ProximoPaso {
    fun texto(etapa: Etapa, documentosPendientes: Int): String = when (etapa) {
        Etapa.RECIBIDO ->
            "Estamos revisando tu reporte para asignarlo a un liquidador. No necesitas hacer nada por ahora."
        Etapa.EVALUACION ->
            if (documentosPendientes > 0)
                "Necesitamos que nos envíes los documentos pendientes para continuar con tu caso."
            else
                "Tu liquidador está revisando tu caso. Si necesitamos algo más, te avisaremos."
        Etapa.LIQUIDACION ->
            "Tenemos todo lo necesario. Estamos definiendo la resolución con tu compañía de seguros."
        Etapa.CERRADO -> "Tu caso terminó. Revisa el resultado y el mensaje de cierre."
    }
}

object Formato {
    /** RN-14: solo nombre de pila, inicial del apellido y equipo. Ej.: "Paulina F. – Equipo Vehículos". */
    fun responsable(nombreCompleto: String, equipo: String, esLiquidador: Boolean): String {
        val partes = nombreCompleto.split(" ")
        val inicial = partes.getOrNull(1)?.firstOrNull()?.let { "$it." } ?: ""
        val unidad = if (esLiquidador) "Equipo $equipo" else equipo
        return "${partes.first()} $inicial – $unidad".replace("  ", " ")
    }
}
