package cl.duoc.siniestroclaro.domain

import java.time.LocalDate

enum class Etapa(val etiqueta: String, val orden: Int) {
    RECIBIDO("Recibido", 0),
    EVALUACION("En evaluación", 1),
    LIQUIDACION("En liquidación", 2),
    CERRADO("Cerrado", 3);

    companion object {
        fun from(nombre: String): Etapa = entries.first { it.name == nombre }
    }
}

enum class Resultado(val etiqueta: String) {
    APROBADO("Aprobado"),
    RECHAZADO("Rechazado"),
    DESISTIDO("Desistido")
}

/** Límites del negocio (RN-05, RN-10). */
object Limites {
    const val MAX_BYTES = 5L * 1024 * 1024
    const val MAX_ORIGEN_IMAGEN = 25L * 1024 * 1024
    const val MAX_ADJUNTOS = 15
    const val DIAS_FUERA_DE_PLAZO = 30L
}

/** Estados de un documento adjunto (Aclaración 9). */
object EstadoDocumento {
    const val PENDIENTE_ENVIO = "PENDIENTE_ENVIO"
    const val RECIBIDO = "RECIBIDO"
    const val RECHAZADO = "RECHAZADO"
}

data class ReporteForm(
    val companiaId: Int? = null,
    val tipoId: Int? = null,
    val fechaOcurrencia: LocalDate? = null,
    val comuna: String = "",
    val referencia: String = "",
    val descripcion: String = "",
    val huboTerceros: Boolean? = null,
    val denunciaPolicial: String? = null // "SI", "NO", "AUN_NO"
)
