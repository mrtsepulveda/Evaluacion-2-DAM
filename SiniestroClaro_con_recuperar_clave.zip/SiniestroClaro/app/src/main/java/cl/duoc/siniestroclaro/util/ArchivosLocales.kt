package cl.duoc.siniestroclaro.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import cl.duoc.siniestroclaro.domain.Limites
import java.io.ByteArrayOutputStream
import java.io.File

data class ArchivoLocal(val ruta: String, val nombre: String, val mime: String, val bytes: Long)
data class InfoArchivo(val nombre: String, val mime: String?, val bytes: Long)

/**
 * Acceso seguro a archivos: todo se guarda en el almacenamiento privado de la app (filesDir/evidencia),
 * nunca en carpetas públicas, y se sanea el nombre del archivo.
 */
class ArchivosLocales(private val context: Context) {
    private val carpeta: File get() = File(context.filesDir, "evidencia").apply { mkdirs() }

    fun nuevoArchivoFoto(): File = File(carpeta, "foto_${System.currentTimeMillis()}.jpg")

    fun uriParaCamara(archivo: File): Uri =
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", archivo)

    fun inspeccionar(uri: Uri): InfoArchivo {
        var nombre = "documento"
        var bytes = -1L
        context.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val iN = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val iS = c.getColumnIndex(OpenableColumns.SIZE)
                if (iN >= 0) nombre = c.getString(iN) ?: nombre
                if (iS >= 0 && !c.isNull(iS)) bytes = c.getLong(iS)
            }
        }
        return InfoArchivo(sanear(nombre), context.contentResolver.getType(uri), bytes)
    }

    /** Copia el archivo elegido al almacenamiento privado. */
    fun copiar(uri: Uri, nombre: String): File {
        val destino = File(carpeta, "${System.currentTimeMillis()}_$nombre")
        context.contentResolver.openInputStream(uri)?.use { entrada ->
            destino.outputStream().use { salida -> entrada.copyTo(salida) }
        } ?: error("No se pudo abrir el archivo")
        return destino
    }

    /** Reduce una imagen para cumplir el máximo de 5 MB (RN-10). Devuelve false si no fue posible. */
    fun reducirImagen(archivo: File): Boolean {
        val bmp = BitmapFactory.decodeFile(archivo.path, BitmapFactory.Options().apply { inSampleSize = 2 })
            ?: return false
        for (calidad in listOf(85, 70, 55, 40)) {
            val bytes = ByteArrayOutputStream().also { bmp.compress(Bitmap.CompressFormat.JPEG, calidad, it) }.toByteArray()
            if (bytes.size <= Limites.MAX_BYTES) {
                archivo.writeBytes(bytes)
                return true
            }
        }
        return false
    }

    private fun sanear(nombre: String) = nombre.replace(Regex("[^A-Za-z0-9._-]"), "_").take(80)
}
