package cl.duoc.siniestroclaro.ui.screens.reportar

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import cl.duoc.siniestroclaro.data.local.CompaniaEntity
import cl.duoc.siniestroclaro.data.local.SiniestroEntity
import cl.duoc.siniestroclaro.data.local.TipoSiniestroEntity
import cl.duoc.siniestroclaro.di.AppContainer
import cl.duoc.siniestroclaro.domain.ReporteErrores
import cl.duoc.siniestroclaro.domain.ReporteForm
import cl.duoc.siniestroclaro.domain.ReporteValidator
import cl.duoc.siniestroclaro.ui.appViewModel
import cl.duoc.siniestroclaro.ui.components.*
import cl.duoc.siniestroclaro.util.Fechas
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate

private data class Interno(
    val form: ReporteForm,
    val tocados: Set<String> = emptySet(),
    val intentado: Boolean = false,
    val enviando: Boolean = false,
    val duplicado: SiniestroEntity? = null,
    val creado: SiniestroEntity? = null
)

data class ReporteUi(
    val companias: List<CompaniaEntity> = emptyList(),
    val tipos: List<TipoSiniestroEntity> = emptyList(),
    val form: ReporteForm = ReporteForm(),
    val errores: ReporteErrores = ReporteErrores(), // solo los que ya se deben mostrar
    val hayErrores: Boolean = true,
    val esVehiculo: Boolean = false,
    val pedirConstancia: Boolean = false,
    val enviando: Boolean = false,
    val duplicado: SiniestroEntity? = null,
    val creado: SiniestroEntity? = null
)

class ReportarViewModel(private val c: AppContainer) : ViewModel() {
    private val aseguradoId = c.session.aseguradoId.value ?: -1
    // RNF-06: el borrador se recupera aunque se cierre la app o se pierda la conexión
    private val interno = MutableStateFlow(Interno(c.session.leerBorrador(aseguradoId)))

    val ui: StateFlow<ReporteUi> = combine(interno, c.repo.companias(), c.repo.tipos()) { i, cs, ts ->
        val cia = cs.firstOrNull { it.id == i.form.companiaId }
        val disponibles = if (cia == null) emptyList() else ts.filter { cia.lineas.split(",").contains(it.linea) }
        val tipo = disponibles.firstOrNull { it.id == i.form.tipoId }
        val esVehiculo = tipo?.linea == "VEHICULO"
        val f = i.form.copy(
            tipoId = tipo?.id,
            huboTerceros = if (esVehiculo) i.form.huboTerceros else null,
            denunciaPolicial = if (esVehiculo) i.form.denunciaPolicial else null
        )
        val todos = ReporteValidator.validar(f, LocalDate.now(), cia?.activa)
        val visibles = if (i.intentado) todos else ReporteErrores(
            compania = todos.compania.takeIf { "compania" in i.tocados },
            tipo = todos.tipo.takeIf { "tipo" in i.tocados },
            fecha = todos.fecha.takeIf { "fecha" in i.tocados },
            comuna = todos.comuna.takeIf { "comuna" in i.tocados },
            referencia = todos.referencia.takeIf { "referencia" in i.tocados },
            descripcion = todos.descripcion.takeIf { "descripcion" in i.tocados }
        )
        ReporteUi(
            companias = cs, tipos = disponibles, form = f, errores = visibles, hayErrores = todos.hayErrores,
            esVehiculo = esVehiculo, pedirConstancia = f.huboTerceros == true || f.denunciaPolicial == "SI",
            enviando = i.enviando, duplicado = i.duplicado, creado = i.creado
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ReporteUi())

    private fun cambiar(campo: String, f: (ReporteForm) -> ReporteForm) {
        interno.update { it.copy(form = f(it.form), tocados = it.tocados + campo) }
        c.session.guardarBorrador(aseguradoId, interno.value.form)
    }

    fun onCompania(id: Int) = cambiar("compania") { it.copy(companiaId = id) }
    fun onTipo(id: Int) = cambiar("tipo") { it.copy(tipoId = id) }
    fun onFecha(d: LocalDate) = cambiar("fecha") { it.copy(fechaOcurrencia = d) }
    fun onComuna(v: String) = cambiar("comuna") { it.copy(comuna = v.take(60)) }
    fun onReferencia(v: String) = cambiar("referencia") { it.copy(referencia = v.take(160)) }
    fun onDescripcion(v: String) = cambiar("descripcion") { it.copy(descripcion = v.take(520)) }
    fun onTerceros(v: Boolean) = cambiar("terceros") { it.copy(huboTerceros = v) }
    fun onDenuncia(v: String) = cambiar("denuncia") { it.copy(denunciaPolicial = v) }

    fun enviar() {
        interno.update { it.copy(intentado = true) }
        val u = ui.value
        if (u.hayErrores) return
        viewModelScope.launch {
            val dup = c.repo.buscarDuplicado(aseguradoId, u.form)
            if (dup != null) interno.update { it.copy(duplicado = dup) } else crear(u)
        }
    }

    /** Aclaración 3: se advierte, pero si la persona confirma, el reporte continúa. */
    fun confirmarDuplicado() {
        val u = ui.value
        interno.update { it.copy(duplicado = null) }
        viewModelScope.launch { crear(u) }
    }

    fun cancelarDuplicado() = interno.update { it.copy(duplicado = null) }

    private suspend fun crear(u: ReporteUi) {
        interno.update { it.copy(enviando = true) }
        val cia = u.companias.first { it.id == u.form.companiaId }
        val tipo = u.tipos.first { it.id == u.form.tipoId }
        val s = c.repo.reportar(aseguradoId, u.form, cia, tipo)
        c.session.borrarBorrador(aseguradoId)
        interno.update { it.copy(enviando = false, creado = s) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportarScreen(onBack: () -> Unit, onVerSiniestro: (Int) -> Unit) {
    val vm = appViewModel { ReportarViewModel(it) }
    val ui by vm.ui.collectAsStateWithLifecycle()

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Reportar siniestro") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Volver") } }
        )
    }) { padding ->
        Crossfade(targetState = ui.creado, label = "reporte", modifier = Modifier.padding(padding)) { creado ->
            if (creado != null) ReporteCreado(creado, ui.pedirConstancia) { onVerSiniestro(creado.id) }
            else Formulario(ui, vm)
        }
    }

    ui.duplicado?.let { dup ->
        AlertDialog(
            onDismissRequest = vm::cancelarDuplicado,
            icon = { Icon(Icons.Filled.ContentCopy, null) },
            title = { Text("¿Es el mismo hecho?") },
            text = { Text("Ya tienes un siniestro abierto con la misma compañía, tipo y fecha: ${dup.numero}. Si es otro hecho distinto, puedes continuar.") },
            confirmButton = { TextButton(onClick = vm::confirmarDuplicado) { Text("Es otro hecho, continuar") } },
            dismissButton = { TextButton(onClick = vm::cancelarDuplicado) { Text("Revisar") } }
        )
    }
}

@Composable
private fun Formulario(ui: ReporteUi, vm: ReportarViewModel) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text("Cuéntanos qué pasó. Solo pedimos lo necesario y no debes ingresar datos médicos ni bancarios.",
            style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))

        MenuDesplegable(
            label = "Compañía de seguros", icono = Icons.Filled.Business, opciones = ui.companias,
            seleccion = ui.companias.firstOrNull { it.id == ui.form.companiaId },
            texto = { if (it.activa) it.nombre else "${it.nombre} (no disponible)" },
            habilitada = { it.activa }, onSeleccion = { vm.onCompania(it.id) }, error = ui.errores.compania
        )
        MenuDesplegable(
            label = "¿Qué te ocurrió?", icono = Icons.Filled.ReportProblem, opciones = ui.tipos,
            seleccion = ui.tipos.firstOrNull { it.id == ui.form.tipoId }, texto = { it.nombre },
            onSeleccion = { vm.onTipo(it.id) }, error = ui.errores.tipo, enabled = ui.form.companiaId != null
        )
        CampoFecha(ui.form.fechaOcurrencia, vm::onFecha, "Fecha en que ocurrió", ui.errores.fecha)
        CampoValidado(ui.form.comuna, vm::onComuna, "Comuna donde ocurrió", Icons.Filled.LocationOn, ui.errores.comuna)
        CampoValidado(ui.form.referencia, vm::onReferencia, "Referencia del lugar (opcional)", Icons.Filled.Place,
            ui.errores.referencia, extra = "Calle, intersección o una descripción breve")
        CampoValidado(
            ui.form.descripcion, vm::onDescripcion, "¿Qué sucedió?", Icons.Filled.Description, ui.errores.descripcion,
            extra = "${ui.form.descripcion.trim().length}/500", singleLine = false, minLines = 4
        )

        AnimatedVisibility(ui.esVehiculo, enter = expandVertically(), exit = shrinkVertically()) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("¿Hubo otros vehículos involucrados?", style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                    Switch(checked = ui.form.huboTerceros == true, onCheckedChange = vm::onTerceros)
                }
                Text("¿Hiciste la denuncia policial?", style = MaterialTheme.typography.bodyLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("SI" to "Sí", "NO" to "No", "AUN_NO" to "Aún no").forEach { (clave, texto) ->
                        FilterChip(
                            selected = ui.form.denunciaPolicial == clave, onClick = { vm.onDenuncia(clave) },
                            label = { Text(texto) },
                            leadingIcon = if (ui.form.denunciaPolicial == clave) ({ Icon(Icons.Filled.Check, null, Modifier.size(18.dp)) }) else null
                        )
                    }
                }
            }
        }
        AnimatedVisibility(ui.pedirConstancia, enter = expandVertically(), exit = shrinkVertically()) {
            BannerEstado("Después te pediremos la constancia de denuncia policial. Puedes ir preparándola.", Icons.Filled.Info,
                Modifier.padding(top = 8.dp))
        }

        Spacer(Modifier.height(16.dp))
        Button(onClick = vm::enviar, enabled = !ui.enviando, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) {
            if (ui.enviando) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
            else Text("Reportar siniestro", style = MaterialTheme.typography.titleMedium)
        }
        Text("Tu avance se guarda solo: si se corta la señal, no perderás lo escrito.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 8.dp))
    }
}

@Composable
private fun ReporteCreado(s: SiniestroEntity, pedirConstancia: Boolean, onVer: () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { visible = true }
    val escala by animateFloatAsState(if (visible) 1f else 0.3f, spring(dampingRatio = Spring.DampingRatioMediumBouncy), label = "check")
    val portapapeles = LocalClipboardManager.current
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Filled.CheckCircle, null, Modifier.size(96.dp).scale(escala), tint = MaterialTheme.colorScheme.tertiary)
        Spacer(Modifier.height(16.dp))
        Text("Recibimos tu reporte", style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text("Tu número de siniestro es", style = MaterialTheme.typography.bodyLarge)
        Text(s.numero, style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
        Text("Guárdalo: puedes usarlo en cualquier canal. Hoy ${Fechas.fechaHora(s.fechaReporte)}.",
            style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        TextButton(onClick = { portapapeles.setText(AnnotatedString(s.numero)) }) {
            Icon(Icons.Filled.ContentCopy, null); Spacer(Modifier.width(8.dp)); Text("Copiar número")
        }
        if (pedirConstancia) {
            Spacer(Modifier.height(8.dp))
            BannerEstado("Te pediremos la constancia de denuncia policial.", Icons.Filled.Info)
        }
        Spacer(Modifier.height(24.dp))
        Button(onClick = onVer, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) { Text("Ver mi siniestro") }
    }
}
