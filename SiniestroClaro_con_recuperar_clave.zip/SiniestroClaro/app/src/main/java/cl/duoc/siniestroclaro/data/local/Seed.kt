package cl.duoc.siniestroclaro.data.local

import cl.duoc.siniestroclaro.domain.ClaveHasher
import cl.duoc.siniestroclaro.domain.EstadoDocumento
import cl.duoc.siniestroclaro.domain.Etapa
import cl.duoc.siniestroclaro.util.Fechas.dia
import cl.duoc.siniestroclaro.util.Fechas.millis

/** Datos de ejemplo del Anexo 9 (todos ficticios). Se cargan una sola vez. */
object Seed {
    /** Contraseña inicial de los asegurados de demostración (datos ficticios). */
    const val CLAVE_DEMO = "Claro2026"

    private fun AseguradoEntity.conClave(clave: String): AseguradoEntity {
        val sal = ClaveHasher.nuevaSal()
        return copy(claveHash = ClaveHasher.hash(clave, sal), claveSal = sal)
    }

    suspend fun cargar(cat: CatalogoDao, dao: SiniestroDao) {
        cat.insertarAsegurados(
            listOf<AseguradoEntity>(
                AseguradoEntity(1, "Camila Andrea Rojas Fuentes", "158423715", "camila.rojas@correo.ejemplo", "+56 9 0000 0101", "Maipú"),
                AseguradoEntity(2, "Jorge Luis Pizarro Contreras", "94185521", "jorge.pizarro@correo.ejemplo", "+56 9 0000 0102", "Puente Alto"),
                AseguradoEntity(3, "Valentina Soto Muñoz", "192058848", "vale.soto@correo.ejemplo", "+56 9 0000 0103", "Ñuñoa"),
                AseguradoEntity(4, "Héctor Manuel Araya Díaz", "78362197", "h.araya@correo.ejemplo", "+56 9 0000 0104", "Viña del Mar"),
                AseguradoEntity(5, "Daniela Paz Vergara Lagos", "175520937", "daniela.vergara@correo.ejemplo", "+56 9 0000 0105", "La Florida"),
                AseguradoEntity(6, "Ricardo Ignacio Espinoza Tapia", "136647083", "r.espinoza@correo.ejemplo", "+56 9 0000 0106", "Concepción"),
                AseguradoEntity(7, "Francisca Belén Morales Henríquez", "201184657", "fran.morales@correo.ejemplo", "+56 9 0000 0107", "Quilicura"),
                AseguradoEntity(8, "Luis Alberto Carrasco Peña", "112903372", "luis.carrasco@correo.ejemplo", "+56 9 0000 0108", "Rancagua")
            ).map { it.conClave(CLAVE_DEMO) }
        )
        cat.insertarCompanias(
            listOf(
                CompaniaEntity(1, "ASG-01", "Seguros Cordillera", "VEHICULO,HOGAR", 10, true),
                CompaniaEntity(2, "ASG-02", "Seguros Litoral", "HOGAR", 12, true),
                CompaniaEntity(3, "ASG-03", "Aseguradora Patagonia Sur", "VEHICULO,HOGAR", 10, true),
                CompaniaEntity(4, "ASG-04", "Seguros Valle Central", "VEHICULO", 8, true),
                CompaniaEntity(5, "ASG-05", "Protege Seguros", "HOGAR", 12, false)
            )
        )
        cat.insertarTipos(
            listOf(
                TipoSiniestroEntity(1, "TS-01", "Vehículo – choque o colisión", "VEHICULO", "Fotografía del daño;Constancia de denuncia policial;Presupuesto de reparación"),
                TipoSiniestroEntity(2, "TS-02", "Vehículo – robo", "VEHICULO", "Constancia de denuncia policial;Declaración de copia de llaves;Padrón del vehículo"),
                TipoSiniestroEntity(3, "TS-03", "Vehículo – rotura de cristales", "VEHICULO", "Fotografía del daño;Presupuesto o boleta"),
                TipoSiniestroEntity(4, "TS-04", "Hogar – daño por agua", "HOGAR", "Fotografía del daño;Informe o boleta del gasfíter;Presupuesto de reparación"),
                TipoSiniestroEntity(5, "TS-05", "Hogar – robo", "HOGAR", "Constancia de denuncia policial;Listado de especies;Boletas o facturas de lo robado"),
                TipoSiniestroEntity(6, "TS-06", "Hogar – incendio", "HOGAR", "Fotografía del daño;Certificado de Bomberos;Presupuesto de reparación")
            )
        )
        cat.insertarColaboradores(
            listOf(
                ColaboradorEntity(1, "LIQ-01", "Paulina Fernández Ruiz", "LIQUIDADOR", "Vehículos", true),
                ColaboradorEntity(2, "LIQ-02", "Matías Gallardo Silva", "LIQUIDADOR", "Hogar", true),
                ColaboradorEntity(3, "LIQ-03", "Rodrigo Salinas Ortega", "LIQUIDADOR", "Vehículos", true),
                ColaboradorEntity(4, "LIQ-04", "Constanza Ibarra Núñez", "LIQUIDADOR", "Hogar", true),
                ColaboradorEntity(5, "LIQ-05", "Andrés Bravo Medina", "LIQUIDADOR", "Vehículos", false),
                ColaboradorEntity(6, "ADM-01", "Natalia Reyes Campos", "ANALISTA", "Administración", true),
                ColaboradorEntity(7, "ADM-02", "Felipe Cortés Valdés", "ANALISTA", "Administración", true)
            )
        )

        suspend fun sin(
            numero: String, aseg: Int, cia: Int, tipo: Int, poliza: String, occ: String, rep: String,
            comuna: String, etapa: Etapa, liq: Int?, cambio: String, upd: String, desc: String,
            terceros: Boolean? = null, denuncia: String? = null, fuera: Boolean = false,
            resultado: String? = null, cierre: String? = null,
            gestiones: List<List<Any>>
        ): Int {
            val id = dao.insertar(
                SiniestroEntity(
                    numero = numero, aseguradoId = aseg, companiaId = cia, tipoId = tipo, poliza = poliza,
                    fechaOcurrencia = dia(occ), fechaReporte = millis("$rep 09:00"), comuna = comuna,
                    descripcion = desc, huboTerceros = terceros, denunciaPolicial = denuncia,
                    etapa = etapa.name, fechaCambioEtapa = millis(cambio), liquidadorId = liq,
                    fueraDePlazo = fuera, resultado = resultado, mensajeCierre = cierre,
                    motivoDesistimiento = if (resultado == "DESISTIDO") cierre else null,
                    ultimaActualizacion = millis(upd)
                )
            ).toInt()
            // cada gestión: [fechaHora, tipo, descripción, responsable, visible]
            gestiones.forEach { g ->
                dao.insertarGestion(
                    GestionEntity(
                        siniestroId = id, fechaHora = millis(g[0] as String), tipo = g[1] as String,
                        descripcion = g[2] as String, responsable = g[3] as String, visible = g[4] as Boolean
                    )
                )
            }
            return id
        }

        val rep = { f: String -> listOf(f, "REPORTE", "Recibimos el reporte de tu siniestro.", "Tú", true) }
        val nat = "Natalia R. – Administración"
        val fel = "Felipe C. – Administración"
        val pau = "Paulina F. – Equipo Vehículos"

        val s4801 = sin("SIN-26-004801", 1, 1, 1, "POL-ASG01-77812", "2026-09-02", "2026-09-02", "Maipú",
            Etapa.LIQUIDACION, 1, "2026-09-18 15:45", "2026-09-18 15:45", "Me chocaron por detrás en un semáforo.", true, "SI",
            gestiones = listOf(
                rep("2026-09-02 18:40"),
                listOf("2026-09-03 09:15", "ASIGNACION", "Tu caso fue asignado a $pau.", nat, true),
                listOf("2026-09-03 09:15", "CAMBIO_ETAPA", "Tu caso pasó a \"En evaluación\".", nat, true),
                listOf("2026-09-05 11:02", "SOLICITUD_DOCUMENTO", "Necesitamos el presupuesto de reparación del taller.", pau, true),
                listOf("2026-09-08 16:30", "DOCUMENTO_RECIBIDO", "Recibimos tu presupuesto de reparación.", "Tú", true),
                listOf("2026-09-10 10:20", "GESTION", "Se coordina inspección con taller; contacto telefónico con jefe de taller.", pau, false),
                listOf("2026-09-12 10:00", "GESTION", "Revisamos tu vehículo en el taller.", pau, true),
                listOf("2026-09-18 15:45", "CAMBIO_ETAPA", "Tu caso pasó a \"En liquidación\". Estamos definiendo la resolución con tu compañía.", pau, true)
            ))
        val s4815 = sin("SIN-26-004815", 2, 2, 5, "POL-ASG02-31470", "2026-08-27", "2026-08-29", "Puente Alto",
            Etapa.EVALUACION, 2, "2026-08-30 09:00", "2026-09-17 09:00", "Entraron a mi casa mientras estaba de viaje.", denuncia = "SI",
            gestiones = listOf(
                rep("2026-08-29 10:05"),
                listOf("2026-08-30 09:00", "ASIGNACION", "Tu caso fue asignado a Matías G. – Equipo Hogar.", fel, true),
                listOf("2026-09-02 12:10", "SOLICITUD_DOCUMENTO", "Necesitamos la constancia de denuncia policial y las boletas de lo robado.", "Matías G. – Equipo Hogar", true),
                listOf("2026-09-04 10:00", "DOCUMENTO_RECIBIDO", "Recibimos tu constancia de denuncia policial.", "Tú", true),
                listOf("2026-09-17 09:00", "RECORDATORIO", "Aún tienes documentos pendientes para continuar con tu caso.", "Sistema", true)
            ))
        val s4822 = sin("SIN-26-004822", 3, 4, 3, "POL-ASG04-20955", "2026-09-10", "2026-09-10", "Providencia",
            Etapa.CERRADO, 3, "2026-09-21 12:30", "2026-09-21 12:30", "Una piedra trizó el parabrisas en la autopista.",
            resultado = "APROBADO",
            cierre = "Tu siniestro fue aprobado por Seguros Valle Central. La compañía se contactará contigo para coordinar la reposición del parabrisas.",
            gestiones = listOf(
                rep("2026-09-10 20:10"),
                listOf("2026-09-11 09:00", "ASIGNACION", "Tu caso fue asignado a Rodrigo S. – Equipo Vehículos.", nat, true),
                listOf("2026-09-15 11:00", "DOCUMENTO_RECIBIDO", "Recibimos tu boleta de reposición.", "Tú", true),
                listOf("2026-09-21 12:30", "CIERRE", "Tu caso fue cerrado: Aprobado.", "Rodrigo S. – Equipo Vehículos", true)
            ))
        val s4830 = sin("SIN-26-004830", 4, 3, 4, "POL-ASG03-66218", "2026-09-14", "2026-09-16", "Viña del Mar",
            Etapa.EVALUACION, 4, "2026-09-17 10:00", "2026-09-22 10:00", "Se filtró agua desde el piso de arriba y mojó el cielo del living.",
            gestiones = listOf(
                rep("2026-09-16 08:30"),
                listOf("2026-09-17 10:00", "ASIGNACION", "Tu caso fue asignado a Constanza I. – Equipo Hogar.", nat, true),
                listOf("2026-09-18 10:05", "SOLICITUD_DOCUMENTO", "Necesitamos el informe o boleta del gasfíter.", "Constanza I. – Equipo Hogar", true),
                listOf("2026-09-22 10:00", "GESTION", "Revisamos los daños en tu domicilio.", "Constanza I. – Equipo Hogar", true)
            ))
        val s4838 = sin("SIN-26-004838", 5, 1, 2, "POL-ASG01-90314", "2026-09-20", "2026-09-21", "La Florida",
            Etapa.EVALUACION, 1, "2026-09-22 09:30", "2026-09-23 14:10", "Me robaron el auto estacionado afuera de mi casa.", denuncia = "AUN_NO",
            gestiones = listOf(
                rep("2026-09-21 19:00"),
                listOf("2026-09-22 09:30", "ASIGNACION", "Tu caso fue asignado a $pau.", fel, true),
                listOf("2026-09-23 14:10", "SOLICITUD_DOCUMENTO", "Necesitamos la constancia de denuncia policial y el padrón del vehículo.", pau, true)
            ))
        val s4851 = sin("SIN-26-004851", 6, 3, 6, "POL-ASG03-12790", "2026-09-25", "2026-09-26", "Concepción",
            Etapa.RECIBIDO, null, "2026-09-26 09:00", "2026-09-26 09:00", "Se incendió la cocina por una falla eléctrica.",
            gestiones = listOf(rep("2026-09-26 09:00")))
        val s4857 = sin("SIN-26-004857", 7, 4, 1, "POL-ASG04-51207", "2026-09-29", "2026-09-30", "Quilicura",
            Etapa.RECIBIDO, null, "2026-09-30 09:42", "2026-09-30 09:42", "Al salir del estacionamiento otro auto retrocedió y me golpeó la puerta.",
            terceros = true, denuncia = "NO",
            gestiones = listOf(rep("2026-09-30 09:42")))
        val s4860 = sin("SIN-26-004860", 8, 2, 4, "POL-ASG02-48821", "2026-08-10", "2026-09-28", "Rancagua",
            Etapa.RECIBIDO, null, "2026-09-28 10:00", "2026-09-28 10:00", "Descubrí una filtración antigua en el baño.", fuera = true,
            gestiones = listOf(rep("2026-09-28 10:00")))
        val s4712 = sin("SIN-26-004712", 1, 1, 3, "POL-ASG01-77812", "2026-07-15", "2026-07-15", "Santiago",
            Etapa.CERRADO, 3, "2026-07-30 10:00", "2026-07-30 10:00", "Se rompió el cristal lateral.", resultado = "DESISTIDO",
            cierre = "Cerramos tu caso porque nos indicaste que no continuarás con el reclamo. Gracias por avisarnos.",
            gestiones = listOf(rep("2026-07-15 12:00"), listOf("2026-07-30 10:00", "CIERRE", "Tu caso fue cerrado: Desistido.", "Rodrigo S. – Equipo Vehículos", true)))
        val s4745 = sin("SIN-26-004745", 2, 4, 1, "POL-ASG04-33102", "2026-07-30", "2026-08-01", "La Reina",
            Etapa.CERRADO, 5, "2026-08-19 11:00", "2026-08-19 11:00", "Choque leve en una intersección.", resultado = "RECHAZADO",
            cierre = "Seguros Valle Central rechazó tu siniestro tras revisar los antecedentes. Si tienes dudas, escríbenos.",
            gestiones = listOf(rep("2026-08-01 09:00"), listOf("2026-08-19 11:00", "CIERRE", "Tu caso fue cerrado: Rechazado.", "Andrés B. – Equipo Vehículos", true)))

        suspend fun sol(s: Int, tipo: String, f: String, entregado: String? = null) = dao.insertarSolicitud(
            SolicitudDocEntity(
                siniestroId = s, tipoDocumento = tipo, fechaSolicitud = millis("$f 12:00"),
                estado = if (entregado != null) "ENTREGADO" else "PENDIENTE",
                fechaEntrega = entregado?.let { millis("$it 12:00") }
            )
        )
        sol(s4801, "Presupuesto de reparación", "2026-09-05", "2026-09-08")
        sol(s4815, "Constancia de denuncia policial", "2026-09-02", "2026-09-04")
        sol(s4815, "Boletas o facturas de lo robado", "2026-09-02")
        sol(s4830, "Informe o boleta del gasfíter", "2026-09-18")
        sol(s4838, "Constancia de denuncia policial", "2026-09-23")
        sol(s4838, "Padrón del vehículo", "2026-09-23")

        suspend fun doc(s: Int, archivo: String, tipo: String, f: String, por: String = "Asegurado") = dao.insertarDocumento(
            DocumentoEntity(
                siniestroId = s, nombreArchivo = archivo, mime = if (archivo.endsWith(".pdf")) "application/pdf" else "image/jpeg",
                tipoDocumento = tipo, fechaCarga = millis("$f 12:00"), cargadoPor = por,
                estado = EstadoDocumento.RECIBIDO
            )
        )
        doc(s4801, "foto_parachoques_1.jpg", "Fotografía del daño", "2026-09-02")
        doc(s4801, "foto_parachoques_2.jpg", "Fotografía del daño", "2026-09-02")
        doc(s4801, "presupuesto_taller.pdf", "Presupuesto de reparación", "2026-09-08")
        doc(s4815, "constancia_denuncia.pdf", "Constancia de denuncia policial", "2026-09-04")
        doc(s4822, "parabrisas_trizado.jpg", "Fotografía del daño", "2026-09-10")
        doc(s4822, "boleta_reposicion.pdf", "Presupuesto o boleta", "2026-09-15")
        doc(s4830, "mancha_cielo_living.jpg", "Fotografía del daño", "2026-09-16")

        suspend fun aviso(s: Int, a: Int, f: String, motivo: String, msg: String, leido: Boolean) = dao.insertarAviso(
            AvisoEntity(siniestroId = s, aseguradoId = a, fechaHora = millis(f), motivo = motivo, mensaje = msg, leido = leido)
        )
        aviso(s4801, 1, "2026-09-18 15:45", "Cambio de etapa", "Tu siniestro SIN-26-004801 pasó a \"En liquidación\".", true)
        aviso(s4815, 2, "2026-09-17 09:00", "Recordatorio", "Aún falta un documento para tu siniestro SIN-26-004815.", false)
        aviso(s4822, 3, "2026-09-21 12:30", "Cierre", "Tu siniestro SIN-26-004822 fue aprobado. Revisa el mensaje de cierre.", true)
        aviso(s4830, 4, "2026-09-18 10:05", "Solicitud de documento", "Necesitamos el informe o boleta del gasfíter para tu siniestro SIN-26-004830.", true)
        aviso(s4838, 5, "2026-09-23 14:10", "Solicitud de documento", "Necesitamos 2 documentos para tu siniestro SIN-26-004838.", false)
        aviso(s4745, 2, "2026-08-19 11:00", "Cierre", "Tu siniestro SIN-26-004745 fue cerrado. Revisa el detalle de la resolución.", true)
    }
}
