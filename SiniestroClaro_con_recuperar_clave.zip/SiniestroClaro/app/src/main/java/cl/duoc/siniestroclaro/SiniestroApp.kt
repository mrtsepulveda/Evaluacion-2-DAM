package cl.duoc.siniestroclaro

import android.app.Application
import cl.duoc.siniestroclaro.di.AppContainer
import kotlinx.coroutines.launch

class SiniestroApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        container.appScope.launch { container.repo.sembrarSiNecesario() }
    }
}
