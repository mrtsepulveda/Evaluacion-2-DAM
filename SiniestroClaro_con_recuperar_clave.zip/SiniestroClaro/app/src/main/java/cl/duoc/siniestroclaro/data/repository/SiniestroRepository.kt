package cl.duoc.siniestroclaro.data.repository

import cl.duoc.siniestroclaro.data.local.*
import cl.duoc.siniestroclaro.domain.*
import cl.duoc.siniestroclaro.util.NotificadorAvisos
import cl.duoc.siniestroclaro.util.SessionStore
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.Locale
import kotlin.random.Random

/**
 * Única fuente de datos de la UI. Hoy lee/escribe en Room; en la EFT aquí se agregará Retrofit
 * (API REST Spring Boot) sin tocar pantallas ni ViewModels.
 * Los métodos del panel del liquidador devuelven un mensaje de error o null si todo salió bien.
 */
class SiniestroRepository(
    private val catalogo: CatalogoDao,
    private val dao: SiniestroDao,
    private val notificador: NotificadorAvisos,
    private val session: SessionStore
) {
    // ---------- lectura ----------
    fun asegurado(id: Int) = catalogo.asegurado(id)
    fun asegurados() = catalogo.asegurados()
    suspend fun buscarPorRut(rutNormalizado: String) = catalogo.porRut(rutNormalizado)
    // ---------- contraseña: ingreso, recuperación y cambio ----------
    /** Mismo mensaje para RUT inexistente y clave errónea: no se revela qué RUT están registrados. */
    suspend fun iniciarSesion(rutNormalizado: String, clave: String): AseguradoEntity? {
        val a = catalogo.porRut(rutNormalizado) ?: return null
        return a.takeIf { ClaveHasher.coincide(clave, it.claveSal, it.claveHash) }
    }

    /** Devuelve el asegurado solo si el RUT y el correo registrado coinciden. */
    suspend fun verificarIdentidad(rutNormalizado: String, correo: String): AseguradoEntity? =
        catalogo.porRut(rutNormalizado)?.takeIf { it.correo.equals(correo.trim(), ignoreCase = true) }

    suspend fun restablecerClave(aseguradoId: Int, nueva: String) = guardarClave(aseguradoId, nueva)

    /** Devuelve un mensaje de error, o null si la contraseña se cambió. */
    suspend fun cambiarClave(aseguradoId: Int, actual: String, nueva: String): String? {
        val a = catalogo.aseguradoUno(aseguradoId) ?: return "No encontramos tu cuenta"
        if (!ClaveHasher.coincide(actual, a.claveSal, a.claveHash)) return "La contraseña actual no es correcta"
        guardarClave(aseguradoId, nueva)
        return null
    }

    private suspend fun guardarClave(aseguradoId: Int, clave: String) {
        val sal = ClaveHasher.nuevaSal()
        catalogo.guardarClave(aseguradoId, ClaveHasher.hash(clave, sal), sal)
    }

    fun companias() = catalogo.companias()
    fun tipos() = catalogo.tipos()
    fun colaboradores() = catalogo.colaboradores()
    suspend fun tipoUno(id: Int) = catalogo.tipo(id)

    fun siniestros(aseguradoId: Int) = dao.delAsegurado(aseguradoId)
    fun siniestro(id: Int) = dao.porId(id)
    suspend fun siniestroUno(id: Int) = dao.porIdUna(id)
    fun abiertos() = dao.abiertos()
    fun gestiones(id: Int, soloVisibles: Boolean): Flow<List<GestionEntity>> =
        if (soloVisibles) dao.gestionesVisibles(id) else dao.gestiones(id)
    fun solicitudes(id: Int) = dao.solicitudes(id)
    suspend fun solicitudUna(id: Int) = dao.solicitud(id)
    fun documentos(id: Int) = dao.documentos(id)
    suspend fun contarDocumentos(id: Int) = dao.contarDocumentos(id)
    fun avisos(aseguradoId: Int) = dao.avisos(aseguradoId)
    fun noLeidos(aseguradoId: Int) = dao.noLeidos(aseguradoId)
    suspend fun marcarLeido(id: Int) = dao.marcarLeido(id)
    suspend fun marcarTodosLeidos(aseguradoId: Int) = dao.marcarTodosLeidos(aseguradoId)

    suspend fun sembrarSiNecesario() {
        if (catalogo.contarAsegurados() == 0) Seed.cargar(catalogo, dao)
    }

    // ---------- reporte (RF-02, RF-03) ----------
    suspend fun buscarDuplicado(aseguradoId: Int, f: ReporteForm): SiniestroEntity? =
        dao.duplicado(aseguradoId, f.companiaId!!, f.tipoId!!, f.fechaOcurrencia!!.toEpochDay())

    suspend fun reportar(
        aseguradoId: Int, f: ReporteForm, compania: CompaniaEntity, tipo: TipoSiniestroEntity
    ): SiniestroEntity {
        val ahora = System.currentTimeMillis()
        val hoy = LocalDate.now()
        val ocurrencia = f.fechaOcurrencia!!
        val correlativo = (dao.ultimoNumero()?.substringAfterLast('-')?.toIntOrNull() ?: 0) + 1
        val s = SiniestroEntity(
            numero = String.format(Locale.ROOT, "SIN-%02d-%06d", hoy.year % 100, correlativo),
            aseguradoId = aseguradoId, companiaId = compania.id, tipoId = tipo.id,
            poliza = "POL-${compania.codigo.replace("-", "")}-${Random.nextInt(10000, 99999)}",
            fechaOcurrencia = ocurrencia.toEpochDay(), fechaReporte = ahora,
            comuna = f.comuna.trim(), referenciaLugar = f.referencia.trim().ifBlank { null },
            descripcion = f.descripcion.trim(), huboTerceros = f.huboTerceros, denunciaPolicial = f.denunciaPolicial,
            etapa = Etapa.RECIBIDO.name, fechaCambioEtapa = ahora, liquidadorId = null,
            fueraDePlazo = ChronoUnit.DAYS.between(ocurrencia, hoy) > Limites.DIAS_FUERA_DE_PLAZO, // RN-05
            ultimaActualizacion = ahora
        )
        val id = dao.insertar(s).toInt()
        dao.insertarGestion(GestionEntity(siniestroId = id, fechaHora = ahora, tipo = "REPORTE",
            descripcion = "Recibimos el reporte de tu siniestro.", responsable = "Tú", visible = true))
        return s.copy(id = id)
    }

    // ---------- documentos (RF-07, RF-08, Aclaración 9) ----------
    suspend fun adjuntar(
        s: SiniestroEntity, nombre: String, ruta: String, mime: String, tipoDoc: String,
        comentario: String, solicitudId: Int?, bytes: Long, enLinea: Boolean
    ) {
        val doc = DocumentoEntity(
            siniestroId = s.id, nombreArchivo = nombre, rutaArchivo = ruta, mime = mime, tipoDocumento = tipoDoc,
            fechaCarga = System.currentTimeMillis(), cargadoPor = "Asegurado", comentario = comentario.trim().ifBlank { null },
            solicitudId = solicitudId, tamanoKb = (bytes / 1024).toInt(),
            estado = if (enLinea) EstadoDocumento.RECIBIDO else EstadoDocumento.PENDIENTE_ENVIO
        )
        val id = dao.insertarDocumento(doc).toInt()
        if (enLinea) confirmarRecepcion(doc.copy(id = id))
    }

    /** Envía los documentos guardados sin conexión cuando vuelve la señal. */
    suspend fun sincronizarPendientes(aseguradoId: Int) {
        dao.documentosSinEnviar(aseguradoId).forEach { confirmarRecepcion(it) }
    }

    private suspend fun confirmarRecepcion(d: DocumentoEntity) {
        val s = dao.porIdUna(d.siniestroId) ?: return
        val ahora = System.currentTimeMillis()
        if (s.etapa == Etapa.CERRADO.name) { // RN-11: no se acepta, y el asegurado debe enterarse
            dao.actualizarDocumento(d.copy(estado = EstadoDocumento.RECHAZADO))
            avisar(s, "Documento no recibido",
                "No pudimos recibir tu documento porque tu siniestro ${s.numero} ya estaba cerrado.")
            return
        }
        dao.actualizarDocumento(d.copy(estado = EstadoDocumento.RECIBIDO))
        d.solicitudId?.let { sid ->
            dao.solicitud(sid)?.let { dao.actualizarSolicitud(it.copy(estado = "ENTREGADO", fechaEntrega = ahora)) }
        }
        dao.insertarGestion(GestionEntity(siniestroId = s.id, fechaHora = ahora, tipo = "DOCUMENTO_RECIBIDO",
            descripcion = "Recibimos tu documento: ${d.tipoDocumento}.", responsable = "Tú", visible = true))
        dao.tocar(s.id, ahora)
    }

    // ---------- panel del liquidador / analista (demo de RF-10, RF-11, RF-12) ----------
    suspend fun asignar(id: Int): String? {
        val s = dao.porIdUna(id) ?: return "No encontramos el siniestro"
        if (s.etapa != Etapa.RECIBIDO.name) return "Solo se asignan siniestros en etapa Recibido"
        val tipo = catalogo.tipo(s.tipoId) ?: return "Tipo de siniestro desconocido"
        val equipo = if (tipo.linea == "VEHICULO") "Vehículos" else "Hogar" // RN-08
        val candidatos = catalogo.liquidadoresActivos(equipo)
        val elegido = candidatos.minByOrNull { dao.cargaLiquidador(it.id) } ?: return "No hay liquidadores activos en $equipo"
        val analista = catalogo.analista()
        val quien = analista?.let { Formato.responsable(it.nombre, it.equipo, false) } ?: "Administración"
        val nombre = Formato.responsable(elegido.nombre, elegido.equipo, true)
        val ahora = System.currentTimeMillis()
        dao.actualizar(s.copy(etapa = Etapa.EVALUACION.name, liquidadorId = elegido.id,
            fechaCambioEtapa = ahora, ultimaActualizacion = ahora))
        dao.insertarGestion(GestionEntity(siniestroId = id, fechaHora = ahora, tipo = "ASIGNACION",
            descripcion = "Tu caso fue asignado a $nombre.", responsable = quien, visible = true))
        dao.insertarGestion(GestionEntity(siniestroId = id, fechaHora = ahora, tipo = "CAMBIO_ETAPA",
            descripcion = "Tu caso pasó a \"${Etapa.EVALUACION.etiqueta}\".", responsable = quien, visible = true))
        avisar(s, "Asignamos tu caso", "Tu siniestro ${s.numero} fue asignado a $nombre y pasó a \"En evaluación\".")
        return null
    }

    suspend fun registrarGestion(id: Int, texto: String, visible: Boolean): String? {
        val s = dao.porIdUna(id) ?: return "No encontramos el siniestro"
        if (s.etapa == Etapa.CERRADO.name) return "El siniestro está cerrado"
        if (s.liquidadorId == null) return "Primero debe asignarse un liquidador"
        val ahora = System.currentTimeMillis()
        dao.insertarGestion(GestionEntity(siniestroId = id, fechaHora = ahora, tipo = "GESTION",
            descripcion = texto.trim(), responsable = responsable(s), visible = visible))
        if (visible) dao.tocar(id, ahora) // las internas no cambian lo que ve el asegurado (RNF-09)
        return null
    }

    suspend fun solicitarDocumento(id: Int, tipoDoc: String, comentario: String): String? {
        val s = dao.porIdUna(id) ?: return "No encontramos el siniestro"
        if (s.etapa != Etapa.EVALUACION.name) return "Solo se piden documentos mientras el caso está En evaluación"
        val ahora = System.currentTimeMillis()
        dao.insertarSolicitud(SolicitudDocEntity(siniestroId = id, tipoDocumento = tipoDoc,
            comentario = comentario.trim().ifBlank { null }, fechaSolicitud = ahora))
        dao.insertarGestion(GestionEntity(siniestroId = id, fechaHora = ahora, tipo = "SOLICITUD_DOCUMENTO",
            descripcion = "Necesitamos el siguiente documento: $tipoDoc.", responsable = responsable(s), visible = true))
        dao.tocar(id, ahora)
        avisar(s, "Te pedimos un documento", "Necesitamos «$tipoDoc» para tu siniestro ${s.numero}.")
        return null
    }

    suspend fun avanzar(id: Int): String? {
        val s = dao.porIdUna(id) ?: return "No encontramos el siniestro"
        val etapa = Etapa.from(s.etapa)
        if (etapa == Etapa.RECIBIDO) return asignar(id)
        ReglasEtapa.validarAvance(etapa, dao.pendientes(id))?.let { return it }
        val ahora = System.currentTimeMillis()
        dao.actualizar(s.copy(etapa = Etapa.LIQUIDACION.name, fechaCambioEtapa = ahora, ultimaActualizacion = ahora))
        dao.insertarGestion(GestionEntity(siniestroId = id, fechaHora = ahora, tipo = "CAMBIO_ETAPA",
            descripcion = "Tu caso pasó a \"En liquidación\". Estamos definiendo la resolución con tu compañía.",
            responsable = responsable(s), visible = true))
        avisar(s, "Tu caso avanzó", "Tu siniestro ${s.numero} pasó a \"En liquidación\".")
        return null
    }

    suspend fun cerrar(id: Int, resultado: Resultado, mensaje: String): String? {
        val s = dao.porIdUna(id) ?: return "No encontramos el siniestro"
        val etapa = Etapa.from(s.etapa)
        if (resultado !in ReglasEtapa.resultadosPermitidos(etapa))
            return "Desde \"${etapa.etiqueta}\" no se puede cerrar como ${resultado.etiqueta}"
        val ahora = System.currentTimeMillis()
        dao.actualizar(s.copy(etapa = Etapa.CERRADO.name, resultado = resultado.name, mensajeCierre = mensaje.trim(),
            motivoDesistimiento = if (resultado == Resultado.DESISTIDO) mensaje.trim() else null,
            fechaCambioEtapa = ahora, ultimaActualizacion = ahora))
        dao.insertarGestion(GestionEntity(siniestroId = id, fechaHora = ahora, tipo = "CIERRE",
            descripcion = "Tu caso fue cerrado: ${resultado.etiqueta}.", responsable = responsable(s), visible = true))
        avisar(s, "Cerramos tu caso", "Tu siniestro ${s.numero} fue cerrado. Revisa el mensaje de cierre.")
        return null
    }

    // ---------- internos ----------
    private suspend fun responsable(s: SiniestroEntity): String =
        s.liquidadorId?.let { catalogo.colaborador(it) }?.let { Formato.responsable(it.nombre, it.equipo, true) }
            ?: "Equipo Andes"

    /** Registra el aviso (RF-09) y, si es la persona que está usando el teléfono, muestra la notificación. */
    private suspend fun avisar(s: SiniestroEntity, motivo: String, mensaje: String) {
        val ahora = System.currentTimeMillis()
        val id = dao.insertarAviso(AvisoEntity(siniestroId = s.id, aseguradoId = s.aseguradoId,
            fechaHora = ahora, motivo = motivo, mensaje = mensaje)).toInt()
        if (session.aseguradoId.value == s.aseguradoId) notificador.mostrar(id, s.id, motivo, mensaje)
    }
}
