package cl.duoc.siniestroclaro.di

import android.content.Context
import cl.duoc.siniestroclaro.data.local.AppDatabase
import cl.duoc.siniestroclaro.data.repository.SiniestroRepository
import cl.duoc.siniestroclaro.util.ArchivosLocales
import cl.duoc.siniestroclaro.util.ConexionMonitor
import cl.duoc.siniestroclaro.util.NotificadorAvisos
import cl.duoc.siniestroclaro.util.SessionStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** Inyección de dependencias manual: un solo lugar donde se construyen las piezas. */
class AppContainer(context: Context) {
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val db = AppDatabase.crear(context)
    val session = SessionStore(context)
    val notificador = NotificadorAvisos(context)
    val archivos = ArchivosLocales(context)
    val conexion = ConexionMonitor(context)
    val repo = SiniestroRepository(db.catalogoDao(), db.siniestroDao(), notificador, session)
}
