package cl.duoc.siniestroclaro.util

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged

/** Informa si hay conexión. Base para el modo sin conexión (RNF-05) y futura sincronización con la API. */
class ConexionMonitor(context: Context) {
    private val cm = context.getSystemService(ConnectivityManager::class.java)

    fun estaEnLinea(): Boolean {
        val red = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(red) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    val enLinea: Flow<Boolean> = callbackFlow {
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { trySend(true) }
            override fun onLost(network: Network) { trySend(estaEnLinea()) }
        }
        cm.registerDefaultNetworkCallback(cb)
        trySend(estaEnLinea())
        awaitClose { cm.unregisterNetworkCallback(cb) }
    }.distinctUntilChanged()
}
