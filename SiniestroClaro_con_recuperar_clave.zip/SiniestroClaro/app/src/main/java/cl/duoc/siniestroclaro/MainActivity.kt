package cl.duoc.siniestroclaro

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import cl.duoc.siniestroclaro.ui.navigation.AppNav
import cl.duoc.siniestroclaro.ui.theme.SiniestroClaroTheme

class MainActivity : ComponentActivity() {
    // id de siniestro que viene desde una notificación (-1 = ninguno)
    private var abrirId by mutableIntStateOf(-1)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        abrirId = intent.getIntExtra(EXTRA_SINIESTRO, -1)
        val container = (application as SiniestroApp).container
        setContent {
            SiniestroClaroTheme {
                AppNav(container, abrirId) { abrirId = -1 }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        abrirId = intent.getIntExtra(EXTRA_SINIESTRO, -1)
    }

    companion object { const val EXTRA_SINIESTRO = "siniestro_id" }
}
