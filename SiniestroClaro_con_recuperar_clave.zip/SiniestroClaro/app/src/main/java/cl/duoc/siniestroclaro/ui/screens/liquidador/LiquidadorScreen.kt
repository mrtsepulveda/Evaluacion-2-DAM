package cl.duoc.siniestroclaro.ui.screens.liquidador

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import cl.duoc.siniestroclaro.data.local.SiniestroEntity
import cl.duoc.siniestroclaro.di.AppContainer
import cl.duoc.siniestroclaro.domain.*
import cl.duoc.siniestroclaro.ui.appViewModel
import cl.duoc.siniestroclaro.ui.components.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class Mensajes(
    val aviso: String? = null,
    val errGestion: String? = null,
    val errDoc: String? = null,
    val errResultado: String? = null,
    val errMensaje: String? = null
)

data class LiqUi(
    val abiertos: List<SiniestroEntity> = emptyList(),
    val sel: SiniestroEntity? = null,
    val etapa: Etapa? = null,
    val pendientes: Int = 0,
    val liquidador: String? = null,
    val docsOpciones: List<String> = emptyList(),
    val resultados: List<Resultado> = emptyList(),
    val m: Mensajes = Mensajes()
)

private data class BaseLiq(
    val abiertos: List<SiniestroEntity>, val sel: SiniestroEntity?, val docs: List<String>,
    val liquidador: String?, val pendientes: Int
)

/**
 * Demo del lado del liquidador/analista (RF-10, RF-11, RF-12): permite probar de punta a punta
 * que lo que se registra aquí cambia lo que ve el asegurado y dispara los avisos.
 */
class LiquidadorViewModel(private val c: AppContainer) : ViewModel() {
    private val selId = MutableStateFlow<Int?>(null)
    private val msgs = MutableStateFlow(Mensajes())

    private val pendientes = selId.flatMapLatest { id ->
        if (id == null) flowOf(0) else c.repo.solicitudes(id).map { l -> l.count { it.estado == "PENDIENTE" } }
    }

    private val base = combine(c.repo.abiertos(), selId, c.repo.tipos(), c.repo.colaboradores(), pendientes) { ab, id, ts, cols, pend ->
        val sel = ab.firstOrNull { it.id == id }
        BaseLiq(
            ab, sel, ts.firstOrNull { it.id == sel?.tipoId }?.documentos?.split(";") ?: emptyList(),
            sel?.liquidadorId?.let { lid -> cols.firstOrNull { it.id == lid } }?.let { Formato.responsable(it.nombre, it.equipo, true) },
            pend
        )
    }

    val ui: StateFlow<LiqUi> = combine(base, msgs) { b, m ->
        val etapa = b.sel?.let { Etapa.from(it.etapa) }
        LiqUi(b.abiertos, b.sel, etapa, b.pendientes, b.liquidador, b.docs,
            etapa?.let { ReglasEtapa.resultadosPermitidos(it) } ?: emptyList(), m)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), LiqUi())

    fun seleccionar(id: Int) { selId.value = id; msgs.value = Mensajes() }
    fun avisoMostrado() = msgs.update { it.copy(aviso = null) }

    fun registrarGestion(texto: String, visible: Boolean, onOk: () -> Unit) {
        val id = selId.value ?: return
        val err = LiquidadorValidator.gestion(texto)
        msgs.update { it.copy(errGestion = err) }
        if (err != null) return
        viewModelScope.launch {
            val e = c.repo.registrarGestion(id, texto, visible)
            if (e == null) { msgs.update { it.copy(aviso = "Gestión registrada") }; onOk() }
            else msgs.update { it.copy(errGestion = e) }
        }
    }

    fun solicitar(tipo: String?, comentario: String, onOk: () -> Unit) {
        val id = selId.value ?: return
        val err = LiquidadorValidator.documento(tipo)
        msgs.update { it.copy(errDoc = err) }
        if (err != null) return
        viewModelScope.launch {
            val e = c.repo.solicitarDocumento(id, tipo!!, comentario)
            if (e == null) { msgs.update { it.copy(aviso = "Documento solicitado. El asegurado recibió un aviso") }; onOk() }
            else msgs.update { it.copy(errDoc = e) }
        }
    }

    fun avanzar() {
        val id = selId.value ?: return
        viewModelScope.launch {
            val e = c.repo.avanzar(id)
            msgs.update { it.copy(aviso = e ?: "Etapa actualizada. El asegurado recibió un aviso") }
        }
    }

    fun cerrar(resultado: Resultado?, mensaje: String, onOk: () -> Unit) {
        val id = selId.value ?: return
        val eR = LiquidadorValidator.resultado(resultado)
        val eM = LiquidadorValidator.mensajeCierre(mensaje)
        msgs.update { it.copy(errResultado = eR, errMensaje = eM) }
        if (eR != null || eM != null) return
        viewModelScope.launch {
            val e = c.repo.cerrar(id, resultado!!, mensaje)
            if (e == null) { msgs.update { it.copy(aviso = "Caso cerrado. El asegurado recibió un aviso") }; onOk() }
            else msgs.update { it.copy(errResultado = e) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiquidadorScreen(onBack: () -> Unit) {
    val vm = appViewModel { LiquidadorViewModel(it) }
    val ui by vm.ui.collectAsStateWithLifecycle()
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(ui.m.aviso) { ui.m.aviso?.let { snack.showSnackbar(it); vm.avisoMostrado() } }

    var gestion by rememberSaveable { mutableStateOf("") }
    var visible by rememberSaveable { mutableStateOf(true) }
    var tipoDoc by rememberSaveable { mutableStateOf<String?>(null) }
    var comentario by rememberSaveable { mutableStateOf("") }
    var resultado by rememberSaveable { mutableStateOf<Resultado?>(null) }
    var cierre by rememberSaveable { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Panel del liquidador (demo)") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Volver") } }
            )
        },
        snackbarHost = { SnackbarHost(snack) }
    ) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            BannerEstado(
                "Simula lo que haría el equipo de Andes. Lo que registres aquí aparece en el historial y avisos del asegurado dueño del caso.",
                Icons.Filled.SupportAgent
            )
            MenuDesplegable(
                label = "Siniestro abierto", icono = Icons.Filled.FolderOpen, opciones = ui.abiertos, seleccion = ui.sel,
                texto = { "${it.numero} · ${Etapa.from(it.etapa).etiqueta}" }, onSeleccion = { vm.seleccionar(it.id) }, error = null
            )
            val etapa = ui.etapa
            if (ui.sel == null || etapa == null) {
                Text("Elige un siniestro para gestionarlo.", style = MaterialTheme.typography.bodyLarge)
                return@Column
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                EtapaChip(etapa)
                Text(ui.liquidador ?: "Sin liquidador", style = MaterialTheme.typography.bodyMedium)
            }
            Text("Documentos pendientes: ${ui.pendientes}", style = MaterialTheme.typography.bodyMedium)

            // --- Cambiar etapa
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Etapa", style = MaterialTheme.typography.titleMedium)
                    if (etapa == Etapa.LIQUIDACION) Text("Para terminar el caso usa «Cerrar caso».", style = MaterialTheme.typography.bodyMedium)
                    else Button(onClick = vm::avanzar, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
                        Text(if (etapa == Etapa.RECIBIDO) "Asignar a un liquidador" else "Avanzar a En liquidación")
                    }
                }
            }

            // --- Registrar gestión (RF-10)
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Registrar gestión", style = MaterialTheme.typography.titleMedium)
                    CampoValidado(gestion, { gestion = it }, "Descripción de la gestión", Icons.Filled.Edit, ui.m.errGestion,
                        extra = "${gestion.length}/300")
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(checked = visible, onCheckedChange = { visible = it })
                        Spacer(Modifier.width(8.dp))
                        Text(if (visible) "Visible para el asegurado" else "Interna (el asegurado no la ve)", style = MaterialTheme.typography.bodyMedium)
                    }
                    FilledTonalButton(onClick = { vm.registrarGestion(gestion, visible) { gestion = "" } },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) { Text("Guardar gestión") }
                }
            }

            // --- Solicitar documento (RF-11)
            AnimatedVisibility(etapa == Etapa.EVALUACION) {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Solicitar documento", style = MaterialTheme.typography.titleMedium)
                        MenuDesplegable("Documento", Icons.Filled.Description, ui.docsOpciones, tipoDoc, { it }, { tipoDoc = it }, ui.m.errDoc)
                        CampoValidado(comentario, { comentario = it.take(300) }, "Comentario (opcional)", Icons.Filled.Edit, null)
                        FilledTonalButton(onClick = { vm.solicitar(tipoDoc, comentario) { tipoDoc = null; comentario = "" } },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) { Text("Pedir documento") }
                    }
                }
            }

            // --- Cerrar caso (RN-02)
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Cerrar caso", style = MaterialTheme.typography.titleMedium)
                    MenuDesplegable("Resultado", Icons.Filled.TaskAlt, ui.resultados, resultado, { it.etiqueta }, { resultado = it }, ui.m.errResultado)
                    CampoValidado(cierre, { cierre = it.take(520) }, "Mensaje de cierre para el asegurado", Icons.Filled.Edit, ui.m.errMensaje,
                        singleLine = false, minLines = 3)
                    FilledTonalButton(onClick = { vm.cerrar(resultado, cierre) { resultado = null; cierre = "" } },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) { Text("Cerrar caso") }
                }
            }
        }
    }
}
