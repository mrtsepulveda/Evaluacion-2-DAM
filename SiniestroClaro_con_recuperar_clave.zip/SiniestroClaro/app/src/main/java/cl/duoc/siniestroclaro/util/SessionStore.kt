package cl.duoc.siniestroclaro.util

import android.content.Context
import cl.duoc.siniestroclaro.domain.ReporteForm
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.time.LocalDate

/**
 * Sesión simulada (RF-01, sin login real) y borrador del reporte (RNF-06).
 * Solo se guarda el id del asegurado: nunca claves ni datos sensibles (RNF-08).
 */
class SessionStore(context: Context) {
    private val prefs = context.getSharedPreferences("sesion", Context.MODE_PRIVATE)
    private val _id = MutableStateFlow(prefs.getInt("asegurado_id", -1).takeIf { it > 0 })
    val aseguradoId: StateFlow<Int?> = _id

    fun iniciar(id: Int) {
        prefs.edit().putInt("asegurado_id", id).apply()
        _id.value = id
    }

    fun cerrar() {
        prefs.edit().remove("asegurado_id").apply()
        _id.value = null
    }

    /** Última vez que se confirmó información con conexión (RNF-05). */
    var ultimaSync: Long
        get() = prefs.getLong("ultima_sync", 0L)
        set(v) { prefs.edit().putLong("ultima_sync", v).apply() }

    fun guardarBorrador(id: Int, f: ReporteForm) {
        prefs.edit()
            .putInt("b${id}_cia", f.companiaId ?: -1)
            .putInt("b${id}_tipo", f.tipoId ?: -1)
            .putLong("b${id}_fecha", f.fechaOcurrencia?.toEpochDay() ?: Long.MIN_VALUE)
            .putString("b${id}_comuna", f.comuna)
            .putString("b${id}_ref", f.referencia)
            .putString("b${id}_desc", f.descripcion)
            .putInt("b${id}_terc", when (f.huboTerceros) { true -> 1; false -> 0; null -> -1 })
            .putString("b${id}_den", f.denunciaPolicial)
            .apply()
    }

    fun leerBorrador(id: Int): ReporteForm {
        val fecha = prefs.getLong("b${id}_fecha", Long.MIN_VALUE)
        return ReporteForm(
            companiaId = prefs.getInt("b${id}_cia", -1).takeIf { it > 0 },
            tipoId = prefs.getInt("b${id}_tipo", -1).takeIf { it > 0 },
            fechaOcurrencia = if (fecha == Long.MIN_VALUE) null else LocalDate.ofEpochDay(fecha),
            comuna = prefs.getString("b${id}_comuna", "") ?: "",
            referencia = prefs.getString("b${id}_ref", "") ?: "",
            descripcion = prefs.getString("b${id}_desc", "") ?: "",
            huboTerceros = when (prefs.getInt("b${id}_terc", -1)) { 1 -> true; 0 -> false; else -> null },
            denunciaPolicial = prefs.getString("b${id}_den", null)
        )
    }

    fun borrarBorrador(id: Int) {
        val e = prefs.edit()
        listOf("cia", "tipo", "fecha", "comuna", "ref", "desc", "terc", "den").forEach { e.remove("b${id}_$it") }
        e.apply()
    }
}
