package cl.duoc.siniestroclaro.domain

import java.time.LocalDate

/** Validación de RUT chileno (RN-03) y utilidades de formato (RNF-10). Lógica pura, sin Android. */
object RutValidator {
    fun normalizar(s: String): String = s.replace(".", "").replace("-", "").replace(" ", "").uppercase()

    fun esValido(input: String): Boolean {
        val r = normalizar(input)
        if (r.length !in 8..9) return false
        val cuerpo = r.dropLast(1)
        if (!cuerpo.all { it.isDigit() }) return false
        var suma = 0
        var mult = 2
        for (c in cuerpo.reversed()) {
            suma += (c - '0') * mult
            mult = if (mult == 7) 2 else mult + 1
        }
        val esperado = when (val res = 11 - (suma % 11)) {
            11 -> '0'
            10 -> 'K'
            else -> '0' + res
        }
        return r.last() == esperado
    }

    fun validar(input: String): String? {
        val r = normalizar(input)
        return when {
            r.isEmpty() -> "Escribe tu RUT"
            r.length < 8 -> "Tu RUT parece incompleto"
            !esValido(r) -> "El RUT no es válido. Revisa el dígito verificador"
            else -> null
        }
    }

    fun formatear(input: String): String {
        val r = normalizar(input)
        if (r.length < 2) return r
        val cuerpo = r.dropLast(1).reversed().chunked(3).joinToString(".").reversed()
        return "$cuerpo-${r.last()}"
    }

    /** "15.842.371-5" -> "**.***.371-5" */
    fun enmascarar(input: String): String {
        val f = formatear(input)
        if (f.length < 6) return f
        return f.dropLast(5).map { if (it.isDigit()) '*' else it }.joinToString("") + f.takeLast(5)
    }
}

data class ReporteErrores(
    val compania: String? = null,
    val tipo: String? = null,
    val fecha: String? = null,
    val comuna: String? = null,
    val referencia: String? = null,
    val descripcion: String? = null
) {
    val hayErrores: Boolean
        get() = listOfNotNull(compania, tipo, fecha, comuna, referencia, descripcion).isNotEmpty()
}

object ReporteValidator {
    private val soloLetras = Regex("^[\\p{L} .'-]{3,60}$")

    fun validar(f: ReporteForm, hoy: LocalDate, companiaActiva: Boolean?): ReporteErrores {
        val desc = f.descripcion.trim()
        return ReporteErrores(
            compania = when {
                f.companiaId == null -> "Elige la compañía de tu seguro"
                companiaActiva == false -> "Esta compañía ya no admite reportes nuevos"
                else -> null
            },
            tipo = if (f.tipoId == null) "Elige qué fue lo que ocurrió" else null,
            fecha = when {
                f.fechaOcurrencia == null -> "Indica qué día ocurrió"
                f.fechaOcurrencia.isAfter(hoy) -> "La fecha no puede ser posterior a hoy"
                else -> null
            },
            comuna = when {
                f.comuna.isBlank() -> "Indica la comuna donde ocurrió"
                !soloLetras.matches(f.comuna.trim()) -> "Escribe solo letras (por ejemplo: Maipú)"
                else -> null
            },
            referencia = if (f.referencia.length > 150) "Máximo 150 caracteres" else null,
            descripcion = when {
                desc.isEmpty() -> "Cuéntanos brevemente qué pasó"
                desc.length < 10 -> "Escribe al menos 10 caracteres"
                desc.length > 500 -> "Máximo 500 caracteres"
                else -> null
            }
        )
    }
}

data class AdjuntoErrores(
    val general: String? = null,
    val tipo: String? = null,
    val archivo: String? = null,
    val comentario: String? = null
) {
    val hayErrores: Boolean get() = listOfNotNull(general, tipo, archivo, comentario).isNotEmpty()
}

object AdjuntoValidator {
    /** Validación del archivo elegido (RN-10). */
    fun errorArchivo(mime: String?, bytes: Long): String? = when {
        mime == null || !(mime.startsWith("image/") || mime == "application/pdf") ->
            "Solo se aceptan imágenes o PDF"
        bytes <= 0 -> "El archivo está vacío"
        mime == "application/pdf" && bytes > Limites.MAX_BYTES ->
            "El PDF pesa más de 5 MB. Elige uno más liviano"
        bytes > Limites.MAX_ORIGEN_IMAGEN -> "La imagen es demasiado pesada"
        else -> null
    }

    fun validar(
        tipo: String?,
        tieneArchivo: Boolean,
        comentario: String,
        etapa: Etapa,
        cantidadActual: Int
    ): AdjuntoErrores = AdjuntoErrores(
        general = when {
            etapa == Etapa.CERRADO -> "Este siniestro está cerrado y ya no admite documentos."
            cantidadActual >= Limites.MAX_ADJUNTOS -> "Llegaste al máximo de 15 documentos para este siniestro."
            else -> null
        },
        tipo = if (tipo.isNullOrBlank()) "Indica qué tipo de documento es" else null,
        archivo = if (!tieneArchivo) "Toma una foto o elige un archivo" else null,
        comentario = if (comentario.length > 300) "Máximo 300 caracteres" else null
    )
}

/** Validaciones de los formularios del panel del liquidador (demo). */
object LiquidadorValidator {
    fun gestion(texto: String): String? = when {
        texto.isBlank() -> "Escribe qué gestión realizaste"
        texto.trim().length < 5 -> "Describe un poco más la gestión"
        texto.length > 300 -> "Máximo 300 caracteres"
        else -> null
    }

    fun documento(tipo: String?): String? = if (tipo.isNullOrBlank()) "Elige el documento que necesitas" else null
    fun resultado(r: Resultado?): String? = if (r == null) "Elige el resultado del cierre" else null
    fun mensajeCierre(m: String): String? = when {
        m.isBlank() -> "Escribe el mensaje de cierre para el asegurado"
        m.trim().length < 10 -> "El mensaje debe tener al menos 10 caracteres"
        m.length > 500 -> "Máximo 500 caracteres"
        else -> null
    }
}
