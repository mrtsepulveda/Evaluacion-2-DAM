package cl.duoc.siniestroclaro.ui.screens.clave

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import cl.duoc.siniestroclaro.di.AppContainer
import cl.duoc.siniestroclaro.domain.ClaveValidator
import cl.duoc.siniestroclaro.domain.CodigoRecuperacion
import cl.duoc.siniestroclaro.domain.CodigoValidator
import cl.duoc.siniestroclaro.domain.CorreoValidator
import cl.duoc.siniestroclaro.domain.ResultadoCodigo
import cl.duoc.siniestroclaro.domain.RutValidator
import cl.duoc.siniestroclaro.ui.appViewModel
import cl.duoc.siniestroclaro.ui.components.BannerEstado
import cl.duoc.siniestroclaro.ui.components.CampoClave
import cl.duoc.siniestroclaro.ui.components.CampoValidado
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class PasoRecuperacion { IDENTIFICAR, CODIGO, NUEVA_CLAVE, LISTO }

data class RecuperarUi(
    val paso: PasoRecuperacion = PasoRecuperacion.IDENTIFICAR,
    val rut: String = "",
    val correo: String = "",
    val codigo: String = "",
    val nueva: String = "",
    val repetida: String = "",
    val errorRut: String? = null,
    val errorCorreo: String? = null,
    val errorCodigo: String? = null,
    val errorNueva: String? = null,
    val errorRepetida: String? = null,
    val errorGeneral: String? = null,
    val correoEnmascarado: String = "",
    val codigoDemo: String = "",
    val trabajando: Boolean = false
)

class RecuperarClaveViewModel(private val c: AppContainer) : ViewModel() {
    private val _ui = MutableStateFlow(RecuperarUi())
    val ui = _ui.asStateFlow()

    private val generador = CodigoRecuperacion()
    private var aseguradoId: Int? = null

    fun onRut(v: String) {
        val limpio = v.filter { it.isDigit() || it == 'k' || it == 'K' }.take(9)
        val error = if (limpio.length >= 8) RutValidator.validar(limpio) else null
        _ui.update { it.copy(rut = RutValidator.formatear(limpio), errorRut = error, errorGeneral = null) }
    }

    fun onCorreo(v: String) = _ui.update { it.copy(correo = v.take(80), errorCorreo = null, errorGeneral = null) }
    fun onCodigo(v: String) =
        _ui.update { it.copy(codigo = v.filter(Char::isDigit).take(CodigoValidator.LARGO), errorCodigo = null) }
    fun onNueva(v: String) = _ui.update { it.copy(nueva = v.take(ClaveValidator.MAX), errorNueva = null) }
    fun onRepetida(v: String) = _ui.update { it.copy(repetida = v.take(ClaveValidator.MAX), errorRepetida = null) }

    /** Paso 1: el RUT y el correo deben coincidir con los registrados. */
    fun identificar() {
        val s = _ui.value
        val errRut = RutValidator.validar(s.rut)
        val errCorreo = CorreoValidator.validar(s.correo)
        if (errRut != null || errCorreo != null) {
            _ui.update { it.copy(errorRut = errRut, errorCorreo = errCorreo) }
            return
        }
        viewModelScope.launch {
            _ui.update { it.copy(trabajando = true, errorGeneral = null) }
            val a = c.repo.verificarIdentidad(RutValidator.normalizar(s.rut), s.correo)
            if (a == null) {
                // Mensaje neutro: no se confirma si el RUT existe o no.
                _ui.update { it.copy(trabajando = false, errorGeneral = "No pudimos validar tus datos. Revisa el RUT y el correo registrado.") }
            } else {
                aseguradoId = a.id
                val codigo = generador.emitir(System.currentTimeMillis())
                _ui.update {
                    it.copy(trabajando = false, paso = PasoRecuperacion.CODIGO, codigo = "",
                        correoEnmascarado = CorreoValidator.enmascarar(a.correo), codigoDemo = codigo)
                }
            }
        }
    }

    fun reenviarCodigo() {
        _ui.update { it.copy(codigoDemo = generador.emitir(System.currentTimeMillis()), codigo = "", errorCodigo = null) }
    }

    /** Paso 2: código de un solo uso (vence en 5 minutos, 3 intentos). */
    fun verificarCodigo() {
        val err = CodigoValidator.validar(_ui.value.codigo)
        if (err != null) { _ui.update { it.copy(errorCodigo = err) }; return }
        when (generador.verificar(_ui.value.codigo, System.currentTimeMillis())) {
            ResultadoCodigo.CORRECTO -> _ui.update { it.copy(paso = PasoRecuperacion.NUEVA_CLAVE, errorCodigo = null) }
            ResultadoCodigo.INCORRECTO ->
                _ui.update { it.copy(errorCodigo = "Código incorrecto. Te quedan ${generador.intentosRestantes()} intentos") }
            ResultadoCodigo.EXPIRADO ->
                _ui.update { it.copy(errorCodigo = "El código venció. Pide uno nuevo") }
            ResultadoCodigo.BLOQUEADO ->
                _ui.update { it.copy(errorCodigo = "Demasiados intentos. Pide un código nuevo") }
        }
    }

    /** Paso 3: nueva contraseña validada y guardada con hash. */
    fun guardar() {
        val s = _ui.value
        val errNueva = ClaveValidator.validar(s.nueva)
        val errRep = if (errNueva == null) ClaveValidator.confirmacion(s.nueva, s.repetida) else null
        if (errNueva != null || errRep != null) {
            _ui.update { it.copy(errorNueva = errNueva, errorRepetida = errRep) }
            return
        }
        val id = aseguradoId ?: return
        viewModelScope.launch {
            _ui.update { it.copy(trabajando = true) }
            c.repo.restablecerClave(id, s.nueva)
            _ui.update { it.copy(trabajando = false, paso = PasoRecuperacion.LISTO, nueva = "", repetida = "") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecuperarClaveScreen(onBack: () -> Unit, onListo: () -> Unit) {
    val vm = appViewModel { RecuperarClaveViewModel(it) }
    val ui by vm.ui.collectAsStateWithLifecycle()

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Recuperar contraseña") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Volver") } }
        )
    }) { padding ->
        AnimatedContent(
            targetState = ui.paso,
            transitionSpec = {
                (slideInHorizontally { it / 4 } + fadeIn()) togetherWith (slideOutHorizontally { -it / 4 } + fadeOut())
            },
            label = "pasos",
            modifier = Modifier.padding(padding)
        ) { paso ->
            Column(
                Modifier.verticalScroll(rememberScrollState()).padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                when (paso) {
                    PasoRecuperacion.IDENTIFICAR -> {
                        Text("¿Olvidaste tu contraseña?", style = MaterialTheme.typography.headlineSmall)
                        Text(
                            "No te preocupes. Escribe tu RUT y el correo que tienes registrado y te enviaremos un código para crear una nueva.",
                            style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        CampoValidado(
                            value = ui.rut, onValueChange = vm::onRut, label = "Tu RUT", icono = Icons.Filled.Badge,
                            error = ui.errorRut, extra = "Ejemplo: 12.345.678-5", capitalizacion = KeyboardCapitalization.Characters
                        )
                        OutlinedCorreo(ui, vm)
                        ui.errorGeneral?.let { BannerError(it) }
                        Button(
                            onClick = vm::identificar, enabled = !ui.trabajando,
                            modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)
                        ) {
                            if (ui.trabajando) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                            else Text("Enviar código", style = MaterialTheme.typography.titleMedium)
                        }
                    }

                    PasoRecuperacion.CODIGO -> {
                        Text("Revisa tu correo", style = MaterialTheme.typography.headlineSmall)
                        Text(
                            "Enviamos un código de ${CodigoValidator.LARGO} dígitos a ${ui.correoEnmascarado}. Vence en 5 minutos.",
                            style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        BannerEstado("Demostración: aquí no se envía un correo real. Tu código es ${ui.codigoDemo}.", Icons.Filled.Info)
                        CampoValidado(
                            value = ui.codigo, onValueChange = vm::onCodigo, label = "Código", icono = Icons.Filled.Pin,
                            error = ui.errorCodigo, extra = "${CodigoValidator.LARGO} dígitos"
                        )
                        Button(
                            onClick = vm::verificarCodigo,
                            modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)
                        ) { Text("Verificar código", style = MaterialTheme.typography.titleMedium) }
                        TextButton(onClick = vm::reenviarCodigo, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                            Text("Enviar un código nuevo")
                        }
                    }

                    PasoRecuperacion.NUEVA_CLAVE -> {
                        Text("Crea tu nueva contraseña", style = MaterialTheme.typography.headlineSmall)
                        CampoClave(
                            value = ui.nueva, onValueChange = vm::onNueva, label = "Nueva contraseña", error = ui.errorNueva,
                            extra = "Mínimo ${ClaveValidator.MIN} caracteres, con letras y números"
                        )
                        CampoClave(
                            value = ui.repetida, onValueChange = vm::onRepetida, label = "Repite la contraseña", error = ui.errorRepetida
                        )
                        Button(
                            onClick = vm::guardar, enabled = !ui.trabajando,
                            modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)
                        ) {
                            if (ui.trabajando) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                            else Text("Guardar contraseña", style = MaterialTheme.typography.titleMedium)
                        }
                    }

                    PasoRecuperacion.LISTO -> {
                        Icon(Icons.Filled.CheckCircle, null, Modifier.size(64.dp).align(Alignment.CenterHorizontally),
                            tint = MaterialTheme.colorScheme.primary)
                        Text("¡Listo! Cambiaste tu contraseña", style = MaterialTheme.typography.headlineSmall)
                        Text(
                            "Ya puedes ingresar con tu RUT y la nueva contraseña.",
                            style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Button(onClick = onListo, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) {
                            Text("Volver a ingresar", style = MaterialTheme.typography.titleMedium)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun OutlinedCorreo(ui: RecuperarUi, vm: RecuperarClaveViewModel) {
    OutlinedTextField(
        value = ui.correo,
        onValueChange = vm::onCorreo,
        label = { Text("Correo registrado") },
        leadingIcon = { Icon(Icons.Filled.Email, null) },
        trailingIcon = { if (ui.errorCorreo != null) Icon(Icons.Filled.Error, "Campo con error", tint = MaterialTheme.colorScheme.error) },
        isError = ui.errorCorreo != null,
        supportingText = { cl.duoc.siniestroclaro.ui.components.TextoApoyo(ui.errorCorreo, "El que usaste al contratar tu seguro") },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, capitalization = KeyboardCapitalization.None),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun BannerError(texto: String) {
    Surface(Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.errorContainer) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(Icons.Filled.Warning, null, tint = MaterialTheme.colorScheme.onErrorContainer)
            Text(texto, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onErrorContainer)
        }
    }
}
