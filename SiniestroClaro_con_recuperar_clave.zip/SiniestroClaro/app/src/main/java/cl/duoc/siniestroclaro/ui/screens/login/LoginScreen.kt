package cl.duoc.siniestroclaro.ui.screens.login

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.LockReset
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import cl.duoc.siniestroclaro.data.local.AseguradoEntity
import cl.duoc.siniestroclaro.di.AppContainer
import cl.duoc.siniestroclaro.data.local.Seed
import cl.duoc.siniestroclaro.domain.ClaveValidator
import cl.duoc.siniestroclaro.domain.RutValidator
import cl.duoc.siniestroclaro.ui.appViewModel
import cl.duoc.siniestroclaro.ui.components.CampoClave
import cl.duoc.siniestroclaro.ui.components.CampoValidado
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class LoginUi(
    val rut: String = "",
    val clave: String = "",
    val error: String? = null,
    val errorClave: String? = null,
    val buscando: Boolean = false
)

class LoginViewModel(private val c: AppContainer) : ViewModel() {
    private val _ui = MutableStateFlow(LoginUi())
    val ui = _ui.asStateFlow()
    val ejemplos = c.repo.asegurados().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun onRut(valor: String) {
        val limpio = valor.filter { it.isDigit() || it == 'k' || it == 'K' }.take(9)
        // validación en vivo: solo cuando ya hay un RUT completo escrito
        val error = if (limpio.length >= 8) RutValidator.validar(limpio) else null
        _ui.update { it.copy(rut = RutValidator.formatear(limpio), error = error) }
    }

    fun onClave(valor: String) = _ui.update { it.copy(clave = valor.take(ClaveValidator.MAX), errorClave = null) }

    fun usarEjemplo(a: AseguradoEntity) {
        onRut(a.rutNormalizado)
        _ui.update { it.copy(clave = Seed.CLAVE_DEMO, errorClave = null) }
    }

    fun ingresar(onOk: () -> Unit) {
        val errorRut = RutValidator.validar(_ui.value.rut)
        val errorClave = if (_ui.value.clave.isEmpty()) "Escribe tu contraseña" else null
        if (errorRut != null || errorClave != null) {
            _ui.update { it.copy(error = errorRut, errorClave = errorClave) }
            return
        }
        viewModelScope.launch {
            _ui.update { it.copy(buscando = true) }
            val asegurado = c.repo.iniciarSesion(RutValidator.normalizar(_ui.value.rut), _ui.value.clave)
            if (asegurado == null) {
                _ui.update { it.copy(buscando = false, errorClave = "RUT o contraseña incorrectos") }
            } else {
                c.session.iniciar(asegurado.id)
                _ui.update { it.copy(buscando = false) }
                onOk()
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LoginScreen(onIngreso: () -> Unit, onOlvide: () -> Unit) {
    val vm = appViewModel { LoginViewModel(it) }
    val ui by vm.ui.collectAsStateWithLifecycle()
    val ejemplos by vm.ejemplos.collectAsStateWithLifecycle()

    Scaffold { padding ->
        Column(
            Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(Modifier.height(24.dp))
            Icon(Icons.Filled.Shield, null, Modifier.size(56.dp), tint = MaterialTheme.colorScheme.primary)
            Text("SiniestroClaro", style = MaterialTheme.typography.headlineMedium)
            Text(
                "Sigue el estado de tu siniestro sin llamar ni ir a una oficina.",
                style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            CampoValidado(
                value = ui.rut, onValueChange = vm::onRut, label = "Tu RUT", icono = Icons.Filled.Badge,
                error = ui.error, extra = "Ejemplo: 12.345.678-5", capitalizacion = KeyboardCapitalization.Characters
            )
            CampoClave(value = ui.clave, onValueChange = vm::onClave, label = "Contraseña", error = ui.errorClave)
            TextButton(onClick = onOlvide, modifier = Modifier.align(Alignment.End)) {
                Icon(Icons.Filled.LockReset, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("¿Olvidaste tu contraseña?")
            }
            Button(
                onClick = { vm.ingresar(onIngreso) }, enabled = !ui.buscando,
                modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)
            ) {
                if (ui.buscando) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                else Text("Ingresar", style = MaterialTheme.typography.titleMedium)
            }
            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            Text("Versión de demostración", style = MaterialTheme.typography.titleMedium)
            Text(
                "Toca un asegurado de ejemplo (datos ficticios) para completar el RUT y la contraseña de demostración (${Seed.CLAVE_DEMO}):",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                ejemplos.forEach { a ->
                    AssistChip(onClick = { vm.usarEjemplo(a) }, label = { Text(a.nombreCompleto.split(" ").take(3).joinToString(" ").let { n -> n }) })
                }
            }
        }
    }
}
