package cl.duoc.siniestroclaro.ui.screens.home

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import cl.duoc.siniestroclaro.di.AppContainer
import cl.duoc.siniestroclaro.domain.Etapa
import cl.duoc.siniestroclaro.domain.RutValidator
import cl.duoc.siniestroclaro.ui.appViewModel
import cl.duoc.siniestroclaro.ui.components.BannerEstado
import cl.duoc.siniestroclaro.ui.components.EstadoVacio
import cl.duoc.siniestroclaro.ui.components.EtapaChip
import cl.duoc.siniestroclaro.util.Fechas
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class ItemSiniestro(
    val id: Int, val numero: String, val compania: String, val tipo: String,
    val etapa: Etapa, val ultimaActualizacion: Long
)

data class HomeUi(
    val cargado: Boolean = false,
    val nombre: String = "",
    val rutEnmascarado: String = "",
    val items: List<ItemSiniestro> = emptyList(),
    val avisosSinLeer: Int = 0
)

@OptIn(ExperimentalCoroutinesApi::class)
class HomeViewModel(private val c: AppContainer) : ViewModel() {
    val ui: StateFlow<HomeUi> = c.session.aseguradoId.flatMapLatest { id ->
        if (id == null) flowOf(HomeUi())
        else combine(
            c.repo.asegurado(id), c.repo.siniestros(id), c.repo.companias(), c.repo.tipos(), c.repo.noLeidos(id)
        ) { a, ss, cs, ts, n ->
            HomeUi(
                cargado = a != null,
                nombre = a?.nombreCompleto?.substringBefore(' ') ?: "",
                rutEnmascarado = a?.let { RutValidator.enmascarar(it.rutNormalizado) } ?: "",
                items = ss.map { s ->
                    ItemSiniestro(
                        s.id, s.numero, cs.firstOrNull { it.id == s.companiaId }?.nombre ?: "",
                        ts.firstOrNull { it.id == s.tipoId }?.nombre ?: "", Etapa.from(s.etapa), s.ultimaActualizacion
                    )
                },
                avisosSinLeer = n
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HomeUi())

    val enLinea = c.conexion.enLinea.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    fun ultimaSync(): String = c.session.ultimaSync.let { if (it == 0L) "—" else Fechas.fechaHora(it) }

    /** Con conexión: envía lo pendiente y deja constancia de la última información confirmada. */
    fun sincronizar() {
        val id = c.session.aseguradoId.value ?: return
        viewModelScope.launch {
            c.repo.sincronizarPendientes(id)
            c.session.ultimaSync = System.currentTimeMillis()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onDetalle: (Int) -> Unit,
    onReportar: () -> Unit,
    onAvisos: () -> Unit,
    onLiquidador: () -> Unit,
    onCambiarClave: () -> Unit,
    onSalir: () -> Unit
) {
    val vm = appViewModel { HomeViewModel(it) }
    val ui by vm.ui.collectAsStateWithLifecycle()
    val enLinea by vm.enLinea.collectAsStateWithLifecycle()
    LaunchedEffect(enLinea) { if (enLinea) vm.sincronizar() }
    PermisoNotificaciones()

    var menu by remember { mutableStateOf(false) }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Mis siniestros") },
                actions = {
                    IconButton(onClick = onAvisos) {
                        BadgedBox(badge = { if (ui.avisosSinLeer > 0) Badge { Text("${ui.avisosSinLeer}") } }) {
                            Icon(Icons.Filled.Notifications, contentDescription = "Avisos")
                        }
                    }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Más opciones") }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(
                                text = { Text("Panel del liquidador (demo)") },
                                leadingIcon = { Icon(Icons.Filled.SupportAgent, null) },
                                onClick = { menu = false; onLiquidador() }
                            )
                            DropdownMenuItem(
                                text = { Text("Cambiar contraseña") },
                                leadingIcon = { Icon(Icons.Filled.Lock, null) },
                                onClick = { menu = false; onCambiarClave() }
                            )
                            DropdownMenuItem(
                                text = { Text("Cambiar de asegurado") },
                                leadingIcon = { Icon(Icons.AutoMirrored.Filled.Logout, null) },
                                onClick = { menu = false; onSalir() }
                            )
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onReportar, icon = { Icon(Icons.Filled.Add, null) }, text = { Text("Reportar siniestro") }
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (!enLinea) item {
                BannerEstado(
                    "Sin conexión. Estás viendo la última información conocida, del ${vm.ultimaSync()}.",
                    Icons.Filled.WifiOff
                )
            }
            item {
                Column(Modifier.padding(vertical = 4.dp)) {
                    Text(if (ui.nombre.isNotEmpty()) "Hola, ${ui.nombre}" else "Hola", style = MaterialTheme.typography.headlineMedium)
                    if (ui.rutEnmascarado.isNotEmpty())
                        Text("RUT ${ui.rutEnmascarado}", style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            if (ui.cargado && ui.items.isEmpty()) item {
                EstadoVacio(
                    Icons.Filled.FolderOpen, "No tienes siniestros reportados",
                    "Si te ocurrió algo, toca «Reportar siniestro» y te acompañamos paso a paso."
                )
            }
            items(ui.items, key = { it.id }) { s ->
                TarjetaSiniestro(s, onClick = { onDetalle(s.id) }, modifier = Modifier.animateItem())
            }
        }
    }
}

@Composable
private fun TarjetaSiniestro(s: ItemSiniestro, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Card(onClick = onClick, modifier = modifier.fillMaxWidth().animateContentSize()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(s.numero, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                EtapaChip(s.etapa)
            }
            Text(s.tipo, style = MaterialTheme.typography.bodyLarge)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(Icons.Filled.Business, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(s.compania, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("Última actualización: ${Fechas.fechaHora(s.ultimaActualizacion)}",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/** Explica para qué se piden los avisos y luego solicita el permiso (Android 13+). */
@Composable
private fun PermisoNotificaciones() {
    if (Build.VERSION.SDK_INT < 33) return
    val ctx = LocalContext.current
    var explicar by rememberSaveable { mutableStateOf(false) }
    val lanzador = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            explicar = true
    }
    if (explicar) {
        AlertDialog(
            onDismissRequest = { explicar = false },
            icon = { Icon(Icons.Filled.Notifications, null) },
            title = { Text("¿Quieres recibir avisos?") },
            text = { Text("Te avisaremos solo cuando algo importante cambie en tu caso: nueva etapa, documento solicitado o cierre. Así no tienes que revisar ni llamar.") },
            confirmButton = { TextButton(onClick = { explicar = false; lanzador.launch(Manifest.permission.POST_NOTIFICATIONS) }) { Text("Activar avisos") } },
            dismissButton = { TextButton(onClick = { explicar = false }) { Text("Ahora no") } }
        )
    }
}
