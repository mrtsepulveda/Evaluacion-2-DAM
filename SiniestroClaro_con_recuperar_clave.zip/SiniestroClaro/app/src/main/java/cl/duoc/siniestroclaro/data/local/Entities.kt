package cl.duoc.siniestroclaro.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

// Modelo simplificado del MER (3FN) entregado por el cliente. Datos 100 % ficticios.

@Entity(tableName = "asegurado")
data class AseguradoEntity(
    @PrimaryKey val id: Int,
    val nombreCompleto: String,
    val rutNormalizado: String,
    val correo: String,
    val telefono: String,
    val comuna: String,
    val claveHash: String = "", // SHA-256 con sal; nunca la clave en texto plano
    val claveSal: String = ""
)

@Entity(tableName = "compania")
data class CompaniaEntity(
    @PrimaryKey val id: Int,
    val codigo: String,
    val nombre: String,
    val lineas: String, // "VEHICULO,HOGAR"
    val plazoDias: Int,
    val activa: Boolean
)

@Entity(tableName = "tipo_siniestro")
data class TipoSiniestroEntity(
    @PrimaryKey val id: Int,
    val codigo: String,
    val nombre: String,
    val linea: String, // VEHICULO | HOGAR
    val documentos: String // separados por ";"
)

@Entity(tableName = "colaborador")
data class ColaboradorEntity(
    @PrimaryKey val id: Int,
    val codigo: String,
    val nombre: String,
    val rol: String, // LIQUIDADOR | ANALISTA
    val equipo: String,
    val activo: Boolean
)

@Entity(
    tableName = "siniestro",
    foreignKeys = [
        ForeignKey(AseguradoEntity::class, ["id"], ["aseguradoId"]),
        ForeignKey(CompaniaEntity::class, ["id"], ["companiaId"]),
        ForeignKey(TipoSiniestroEntity::class, ["id"], ["tipoId"])
    ],
    indices = [Index(value = ["numero"], unique = true), Index("aseguradoId"), Index("companiaId"), Index("tipoId")]
)
data class SiniestroEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val numero: String,
    val aseguradoId: Int,
    val companiaId: Int,
    val tipoId: Int,
    val poliza: String,
    val fechaOcurrencia: Long, // epochDay
    val fechaReporte: Long, // millis
    val comuna: String,
    val referenciaLugar: String? = null,
    val descripcion: String,
    val huboTerceros: Boolean? = null,
    val denunciaPolicial: String? = null,
    val etapa: String,
    val fechaCambioEtapa: Long,
    val liquidadorId: Int? = null,
    val fueraDePlazo: Boolean = false,
    val resultado: String? = null,
    val mensajeCierre: String? = null,
    val motivoDesistimiento: String? = null,
    val ultimaActualizacion: Long
)

@Entity(
    tableName = "gestion",
    foreignKeys = [ForeignKey(SiniestroEntity::class, ["id"], ["siniestroId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("siniestroId")]
)
data class GestionEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val siniestroId: Int,
    val fechaHora: Long,
    val tipo: String,
    val descripcion: String,
    val responsable: String,
    val visible: Boolean // RN-13: las internas nunca se muestran al asegurado
)

@Entity(
    tableName = "solicitud_documento",
    foreignKeys = [ForeignKey(SiniestroEntity::class, ["id"], ["siniestroId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("siniestroId")]
)
data class SolicitudDocEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val siniestroId: Int,
    val tipoDocumento: String,
    val comentario: String? = null,
    val fechaSolicitud: Long,
    val estado: String = "PENDIENTE", // PENDIENTE | ENTREGADO
    val fechaEntrega: Long? = null
)

@Entity(
    tableName = "documento",
    foreignKeys = [ForeignKey(SiniestroEntity::class, ["id"], ["siniestroId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("siniestroId")]
)
data class DocumentoEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val siniestroId: Int,
    val nombreArchivo: String,
    val rutaArchivo: String? = null,
    val mime: String,
    val tipoDocumento: String,
    val fechaCarga: Long,
    val cargadoPor: String,
    val comentario: String? = null,
    val solicitudId: Int? = null,
    val tamanoKb: Int = 0,
    val estado: String // EstadoDocumento
)

@Entity(
    tableName = "aviso",
    foreignKeys = [ForeignKey(SiniestroEntity::class, ["id"], ["siniestroId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("siniestroId"), Index("aseguradoId")]
)
data class AvisoEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val siniestroId: Int,
    val aseguradoId: Int,
    val fechaHora: Long,
    val motivo: String,
    val mensaje: String,
    val leido: Boolean = false
)
