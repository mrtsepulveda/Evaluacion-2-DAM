package cl.duoc.siniestroclaro.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        AseguradoEntity::class, CompaniaEntity::class, TipoSiniestroEntity::class, ColaboradorEntity::class,
        SiniestroEntity::class, GestionEntity::class, SolicitudDocEntity::class, DocumentoEntity::class,
        AvisoEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun catalogoDao(): CatalogoDao
    abstract fun siniestroDao(): SiniestroDao

    companion object {
        fun crear(context: Context): AppDatabase =
            Room.databaseBuilder(context, AppDatabase::class.java, "siniestros.db")
                .fallbackToDestructiveMigration() // v1 -> v2 agrega clave; los datos de demo se vuelven a sembrar
                .build()
    }
}
