package cl.duoc.siniestroclaro.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import cl.duoc.siniestroclaro.domain.Etapa
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter

private val FormatoFecha: DateTimeFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy")

/** La etapa se comunica con ícono + texto, no solo con color (Aclaración 10-d, RNF-04). */
@Composable
fun EtapaChip(etapa: Etapa, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val (icono, fondo, texto) = when (etapa) {
        Etapa.RECIBIDO -> Triple(Icons.Filled.Inbox, cs.secondaryContainer, cs.onSecondaryContainer)
        Etapa.EVALUACION -> Triple(Icons.Filled.Search, cs.primaryContainer, cs.onPrimaryContainer)
        Etapa.LIQUIDACION -> Triple(Icons.Filled.Gavel, cs.primaryContainer, cs.onPrimaryContainer)
        Etapa.CERRADO -> Triple(Icons.Filled.TaskAlt, cs.tertiaryContainer, cs.onTertiaryContainer)
    }
    Surface(shape = RoundedCornerShape(50), color = fondo, modifier = modifier) {
        Row(
            Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(icono, contentDescription = null, tint = texto, modifier = Modifier.size(18.dp))
            Text(etapa.etiqueta, color = texto, style = MaterialTheme.typography.labelLarge)
        }
    }
}

/** Línea de avance de 4 pasos con animación al cambiar de etapa. */
@Composable
fun EtapaStepper(etapa: Etapa, modifier: Modifier = Modifier) {
    val progreso by animateFloatAsState((etapa.orden + 1) / 4f, tween(800), label = "progreso")
    Column(modifier, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        LinearProgressIndicator(
            progress = { progreso },
            modifier = Modifier.fillMaxWidth().height(8.dp),
            strokeCap = androidx.compose.ui.graphics.StrokeCap.Round
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Etapa.entries.forEach { e ->
                val alcanzada = e.orden <= etapa.orden
                val fondo by animateColorAsState(
                    if (alcanzada) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                    tween(600), label = "paso"
                )
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(28.dp).background(fondo, CircleShape), contentAlignment = Alignment.Center) {
                        if (alcanzada) Icon(Icons.Filled.Check, null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(18.dp))
                        else Text("${e.orden + 1}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        e.etiqueta, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center,
                        fontWeight = if (e == etapa) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }
    }
}

/** Mensaje de error (con ícono) o texto de ayuda bajo un campo. */
@Composable
fun TextoApoyo(error: String?, extra: String? = null) {
    Column(Modifier.animateContentSize()) {
        if (error != null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Warning, null, Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text(error)
            }
        } else if (extra != null) Text(extra)
    }
}

@Composable
private fun IconoError(visible: Boolean) {
    AnimatedVisibility(visible, enter = scaleIn() + fadeIn(), exit = scaleOut() + fadeOut()) {
        Icon(Icons.Filled.Error, contentDescription = "Campo con error", tint = MaterialTheme.colorScheme.error)
    }
}

@Composable
fun CampoValidado(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    icono: ImageVector,
    error: String?,
    modifier: Modifier = Modifier,
    extra: String? = null,
    singleLine: Boolean = true,
    minLines: Int = 1,
    capitalizacion: KeyboardCapitalization = KeyboardCapitalization.Sentences
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        leadingIcon = { Icon(icono, null) },
        trailingIcon = { IconoError(error != null) },
        isError = error != null,
        supportingText = { TextoApoyo(error, extra) },
        singleLine = singleLine,
        minLines = minLines,
        keyboardOptions = KeyboardOptions(capitalization = capitalizacion),
        modifier = modifier.fillMaxWidth()
    )
}

/** Campo de contraseña con ícono de candado, botón mostrar/ocultar y mensaje de error. */
@Composable
fun CampoClave(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    error: String?,
    modifier: Modifier = Modifier,
    extra: String? = null
) {
    var visible by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        leadingIcon = { Icon(Icons.Filled.Lock, null) },
        trailingIcon = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconoError(error != null)
                IconButton(onClick = { visible = !visible }) {
                    Icon(
                        if (visible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                        contentDescription = if (visible) "Ocultar contraseña" else "Mostrar contraseña"
                    )
                }
            }
        },
        isError = error != null,
        supportingText = { TextoApoyo(error, extra) },
        singleLine = true,
        visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        modifier = modifier.fillMaxWidth()
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun <T> MenuDesplegable(
    label: String,
    icono: ImageVector,
    opciones: List<T>,
    seleccion: T?,
    texto: (T) -> String,
    onSeleccion: (T) -> Unit,
    error: String?,
    modifier: Modifier = Modifier,
    habilitada: (T) -> Boolean = { true },
    enabled: Boolean = true
) {
    var abierto by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = abierto, onExpandedChange = { if (enabled) abierto = it }, modifier = modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = seleccion?.let(texto) ?: "",
            onValueChange = {},
            readOnly = true,
            enabled = enabled,
            label = { Text(label) },
            leadingIcon = { Icon(icono, null) },
            trailingIcon = {
                if (error != null) IconoError(true) else ExposedDropdownMenuDefaults.TrailingIcon(abierto)
            },
            isError = error != null,
            supportingText = { TextoApoyo(error) },
            modifier = Modifier.menuAnchor().fillMaxWidth()
        )
        ExposedDropdownMenu(expanded = abierto, onDismissRequest = { abierto = false }) {
            opciones.forEach { o ->
                DropdownMenuItem(
                    text = { Text(texto(o), style = MaterialTheme.typography.bodyLarge) },
                    enabled = habilitada(o),
                    onClick = { onSeleccion(o); abierto = false }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CampoFecha(
    fecha: LocalDate?,
    onFecha: (LocalDate) -> Unit,
    label: String,
    error: String?,
    modifier: Modifier = Modifier
) {
    var mostrar by remember { mutableStateOf(false) }
    Box(modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = fecha?.format(FormatoFecha) ?: "",
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            leadingIcon = { Icon(Icons.Filled.CalendarMonth, null) },
            trailingIcon = { IconoError(error != null) },
            isError = error != null,
            supportingText = { TextoApoyo(error, "Toca para elegir la fecha") },
            modifier = Modifier.fillMaxWidth()
        )
        Box(Modifier.matchParentSize().clickable(onClickLabel = "Elegir fecha") { mostrar = true })
    }
    if (mostrar) {
        val estado = rememberDatePickerState(
            initialSelectedDateMillis = fecha?.atStartOfDay(ZoneOffset.UTC)?.toInstant()?.toEpochMilli()
        )
        DatePickerDialog(
            onDismissRequest = { mostrar = false },
            confirmButton = {
                TextButton(onClick = {
                    estado.selectedDateMillis?.let {
                        onFecha(Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate())
                    }
                    mostrar = false
                }) { Text("Aceptar") }
            },
            dismissButton = { TextButton(onClick = { mostrar = false }) { Text("Cancelar") } }
        ) { DatePicker(estado) }
    }
}

@Composable
fun FilaDato(etiqueta: String, valor: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(etiqueta, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(valor, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
fun BannerEstado(texto: String, icono: ImageVector, modifier: Modifier = Modifier) {
    Surface(modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.secondaryContainer) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(icono, null, tint = MaterialTheme.colorScheme.onSecondaryContainer)
            Text(texto, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSecondaryContainer)
        }
    }
}

@Composable
fun EstadoVacio(icono: ImageVector, titulo: String, detalle: String, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxWidth().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(icono, null, Modifier.size(56.dp), tint = MaterialTheme.colorScheme.outline)
        Text(titulo, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
        Text(detalle, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
