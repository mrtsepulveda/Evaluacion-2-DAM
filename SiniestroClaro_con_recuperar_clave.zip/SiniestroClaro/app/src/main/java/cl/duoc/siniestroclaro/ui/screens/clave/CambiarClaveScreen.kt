package cl.duoc.siniestroclaro.ui.screens.clave

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import cl.duoc.siniestroclaro.di.AppContainer
import cl.duoc.siniestroclaro.domain.ClaveValidator
import cl.duoc.siniestroclaro.ui.appViewModel
import cl.duoc.siniestroclaro.ui.components.BannerEstado
import cl.duoc.siniestroclaro.ui.components.CampoClave
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class CambiarClaveUi(
    val actual: String = "",
    val nueva: String = "",
    val repetida: String = "",
    val errorActual: String? = null,
    val errorNueva: String? = null,
    val errorRepetida: String? = null,
    val guardando: Boolean = false,
    val exito: Boolean = false
)

class CambiarClaveViewModel(private val c: AppContainer) : ViewModel() {
    private val _ui = MutableStateFlow(CambiarClaveUi())
    val ui = _ui.asStateFlow()

    fun onActual(v: String) = _ui.update { it.copy(actual = v.take(ClaveValidator.MAX), errorActual = null) }
    fun onNueva(v: String) = _ui.update { it.copy(nueva = v.take(ClaveValidator.MAX), errorNueva = null) }
    fun onRepetida(v: String) = _ui.update { it.copy(repetida = v.take(ClaveValidator.MAX), errorRepetida = null) }

    fun guardar() {
        val s = _ui.value
        val errActual = if (s.actual.isEmpty()) "Escribe tu contraseña actual" else null
        val errNueva = ClaveValidator.validar(s.nueva) ?: ClaveValidator.distintaDeLaActual(s.actual, s.nueva)
        val errRep = if (errNueva == null) ClaveValidator.confirmacion(s.nueva, s.repetida) else null
        if (errActual != null || errNueva != null || errRep != null) {
            _ui.update { it.copy(errorActual = errActual, errorNueva = errNueva, errorRepetida = errRep) }
            return
        }
        val id = c.session.aseguradoId.value ?: return
        viewModelScope.launch {
            _ui.update { it.copy(guardando = true) }
            val error = c.repo.cambiarClave(id, s.actual, s.nueva)
            _ui.update {
                if (error == null) it.copy(guardando = false, exito = true, actual = "", nueva = "", repetida = "")
                else it.copy(guardando = false, errorActual = error)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CambiarClaveScreen(onBack: () -> Unit, onListo: () -> Unit) {
    val vm = appViewModel { CambiarClaveViewModel(it) }
    val ui by vm.ui.collectAsStateWithLifecycle()
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Cambiar contraseña") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Volver") } }
            )
        }
    ) { padding ->
        if (ui.exito) {
            Column(
                Modifier.padding(padding).padding(24.dp).fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Icon(Icons.Filled.CheckCircle, null, Modifier.size(64.dp), tint = MaterialTheme.colorScheme.primary)
                Text("¡Listo! Cambiaste tu contraseña", style = MaterialTheme.typography.headlineSmall)
                Button(onClick = onListo, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) { Text("Volver") }
            }
            return@Scaffold
        }
        Column(
            Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            BannerEstado("Elige una contraseña que no uses en otras apps.", Icons.Filled.CheckCircle)
            CampoClave(value = ui.actual, onValueChange = vm::onActual, label = "Contraseña actual", error = ui.errorActual)
            CampoClave(
                value = ui.nueva, onValueChange = vm::onNueva, label = "Nueva contraseña", error = ui.errorNueva,
                extra = "Mínimo ${ClaveValidator.MIN} caracteres, con letras y números"
            )
            CampoClave(value = ui.repetida, onValueChange = vm::onRepetida, label = "Repite la nueva contraseña", error = ui.errorRepetida)
            Button(
                onClick = vm::guardar, enabled = !ui.guardando,
                modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)
            ) {
                if (ui.guardando) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                else Text("Guardar contraseña", style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}
