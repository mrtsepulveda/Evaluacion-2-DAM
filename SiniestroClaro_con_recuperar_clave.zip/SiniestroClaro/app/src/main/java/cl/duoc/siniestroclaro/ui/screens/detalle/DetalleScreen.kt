package cl.duoc.siniestroclaro.ui.screens.detalle

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import cl.duoc.siniestroclaro.data.local.*
import cl.duoc.siniestroclaro.di.AppContainer
import cl.duoc.siniestroclaro.domain.*
import cl.duoc.siniestroclaro.ui.appViewModel
import cl.duoc.siniestroclaro.ui.components.*
import cl.duoc.siniestroclaro.util.Fechas
import coil.compose.AsyncImage
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import java.io.File

data class SolicitudUi(val solicitud: SolicitudDocEntity, val enviadoSinConfirmar: Boolean)

data class DetalleUi(
    val cargando: Boolean = true,
    val siniestro: SiniestroEntity? = null,
    val etapa: Etapa = Etapa.RECIBIDO,
    val companiaNombre: String = "",
    val tipoNombre: String = "",
    val liquidador: String? = null,
    val proximoPaso: String = "",
    val gestiones: List<GestionEntity> = emptyList(),
    val solicitudes: List<SolicitudUi> = emptyList(),
    val documentos: List<DocumentoEntity> = emptyList(),
    val plazoDias: Int = 0,
    val diasEnEtapa: Long = 0,
    val sugeridos: List<String> = emptyList()
)

private data class Base(
    val s: SiniestroEntity?, val cs: List<CompaniaEntity>, val ts: List<TipoSiniestroEntity>, val cols: List<ColaboradorEntity>
)

class DetalleViewModel(c: AppContainer, id: Int) : ViewModel() {
    private val base = combine(c.repo.siniestro(id), c.repo.companias(), c.repo.tipos(), c.repo.colaboradores()) { s, cs, ts, cols ->
        Base(s, cs, ts, cols)
    }
    // RN-13: el asegurado solo recibe las gestiones visibles
    private val extras = combine(c.repo.gestiones(id, true), c.repo.solicitudes(id), c.repo.documentos(id)) { g, so, d ->
        Triple(g, so, d)
    }

    val ui = combine(base, extras) { b, e ->
        val s = b.s ?: return@combine DetalleUi(cargando = false)
        val (g, so, d) = e
        val etapa = Etapa.from(s.etapa)
        val cia = b.cs.firstOrNull { it.id == s.companiaId }
        val tipo = b.ts.firstOrNull { it.id == s.tipoId }
        val pendientes = so.count { it.estado == "PENDIENTE" }
        DetalleUi(
            cargando = false, siniestro = s, etapa = etapa,
            companiaNombre = cia?.nombre ?: "", tipoNombre = tipo?.nombre ?: "",
            liquidador = s.liquidadorId?.let { lid -> b.cols.firstOrNull { it.id == lid } }
                ?.let { Formato.responsable(it.nombre, it.equipo, true) },
            proximoPaso = ProximoPaso.texto(etapa, pendientes),
            gestiones = g,
            solicitudes = so.map { sol ->
                SolicitudUi(sol, d.any { it.solicitudId == sol.id && it.estado == EstadoDocumento.PENDIENTE_ENVIO })
            },
            documentos = d, plazoDias = cia?.plazoDias ?: 0, diasEnEtapa = Fechas.diasDesde(s.fechaCambioEtapa),
            sugeridos = tipo?.documentos?.split(";") ?: emptyList()
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DetalleUi())
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetalleScreen(id: Int, onBack: () -> Unit, onAdjuntar: (Int?) -> Unit) {
    val vm = appViewModel(key = "detalle$id") { DetalleViewModel(it, id) }
    val ui by vm.ui.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(ui.siniestro?.numero ?: "Siniestro") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Volver") } }
        )
    }) { padding ->
        val s = ui.siniestro
        if (s == null) {
            Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
                if (ui.cargando) CircularProgressIndicator() else Text("No encontramos este siniestro")
            }
            return@Scaffold
        }
        Column(
            Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1) La etapa es lo primero que se entiende (RNF-02)
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(ui.tipoNombre, style = MaterialTheme.typography.titleLarge)
                    Text(ui.companiaNombre, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    EtapaChip(ui.etapa)
                    EtapaStepper(ui.etapa)
                }
            }
            // 2) Qué viene ahora y si hay que hacer algo
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(Icons.Filled.Info, null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                    Column {
                        Text("¿Qué sigue?", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Text(ui.proximoPaso, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                }
            }
            if (ui.etapa == Etapa.CERRADO) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Resultado: ${s.resultado?.let { Resultado.valueOf(it).etiqueta } ?: "—"}",
                            style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onTertiaryContainer)
                        Text(s.mensajeCierre ?: "", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onTertiaryContainer)
                    }
                }
            }
            TabRow(selectedTabIndex = tab) {
                listOf("Resumen", "Historial", "Documentos").forEachIndexed { i, t ->
                    Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t, style = MaterialTheme.typography.labelLarge) })
                }
            }
            AnimatedContent(
                targetState = tab, label = "pestañas",
                transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(120)) }
            ) { t ->
                when (t) {
                    0 -> Resumen(ui, s)
                    1 -> Historial(ui.gestiones)
                    else -> Documentos(ui, onAdjuntar)
                }
            }
        }
    }
}

@Composable
private fun Resumen(ui: DetalleUi, s: SiniestroEntity) {
    Column {
        FilaDato("Número de siniestro", s.numero)
        FilaDato("Póliza (referencial)", s.poliza)
        FilaDato("Fecha de ocurrencia", Fechas.fechaDesdeDia(s.fechaOcurrencia))
        FilaDato("Fecha de reporte", Fechas.fecha(s.fechaReporte))
        FilaDato("Comuna", s.comuna)
        FilaDato("Quién ve tu caso", ui.liquidador ?: "Por asignar")
        FilaDato("Última actualización", Fechas.fechaHora(s.ultimaActualizacion))
        if (ui.etapa != Etapa.CERRADO) {
            val plazo = if (ui.etapa == Etapa.EVALUACION && ui.plazoDias > 0) " · Plazo estimado de evaluación: ${ui.plazoDias} días hábiles" else ""
            FilaDato("Tiempo en esta etapa", "${ui.diasEnEtapa} días$plazo")
        }
        if (s.fueraDePlazo) {
            Spacer(Modifier.height(8.dp))
            BannerEstado("Este reporte se hizo pasados 30 días del hecho. Lo aceptamos igual y la compañía lo revisará.", Icons.Filled.Info)
        }
    }
}

@Composable
private fun Historial(gestiones: List<GestionEntity>) {
    if (gestiones.isEmpty()) {
        EstadoVacio(Icons.Filled.History, "Aún no hay gestiones", "Aquí verás todo lo que hacemos en tu caso.")
        return
    }
    Column {
        gestiones.forEachIndexed { i, g ->
            Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(14.dp).background(MaterialTheme.colorScheme.primary, CircleShape))
                    if (i < gestiones.lastIndex)
                        Box(Modifier.width(2.dp).weight(1f).background(MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)))
                }
                Column(Modifier.padding(bottom = 16.dp)) {
                    Text(g.descripcion, style = MaterialTheme.typography.bodyLarge)
                    Text("${Fechas.fechaHora(g.fechaHora)} · ${g.responsable}", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun Documentos(ui: DetalleUi, onAdjuntar: (Int?) -> Unit) {
    val cerrado = ui.etapa == Etapa.CERRADO
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Documentos que te pedimos", style = MaterialTheme.typography.titleMedium)
        if (ui.solicitudes.isEmpty()) {
            Text("Por ahora no te hemos pedido documentos.", style = MaterialTheme.typography.bodyMedium)
            if (!cerrado && ui.sugeridos.isNotEmpty())
                Text("En este tipo de siniestro normalmente se piden: ${ui.sugeridos.joinToString(", ")}.",
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        ui.solicitudes.forEach { su ->
            val sol = su.solicitud
            OutlinedCard(Modifier.fillMaxWidth().animateContentSize()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(sol.tipoDocumento, style = MaterialTheme.typography.titleMedium)
                    Text("Pedido el ${Fechas.fecha(sol.fechaSolicitud)}", style = MaterialTheme.typography.bodySmall)
                    val entregado = sol.estado == "ENTREGADO"
                    EstadoTexto(
                        icono = if (entregado) Icons.Filled.CheckCircle else if (su.enviadoSinConfirmar) Icons.Filled.Schedule else Icons.Filled.HourglassEmpty,
                        texto = when {
                            entregado -> "Entregado${sol.fechaEntrega?.let { " el ${Fechas.fecha(it)}" } ?: ""}"
                            su.enviadoSinConfirmar -> "Guardado en tu teléfono, aún sin enviar"
                            else -> "Pendiente"
                        }
                    )
                    if (sol.estado == "PENDIENTE" && !su.enviadoSinConfirmar && !cerrado)
                        FilledTonalButton(onClick = { onAdjuntar(sol.id) }, modifier = Modifier.heightIn(min = 48.dp)) {
                            Icon(Icons.Filled.AttachFile, null); Spacer(Modifier.width(8.dp)); Text("Entregar este documento")
                        }
                }
            }
        }
        HorizontalDivider()
        Text("Lo que has enviado", style = MaterialTheme.typography.titleMedium)
        if (ui.documentos.isEmpty()) Text("Todavía no has enviado documentos.", style = MaterialTheme.typography.bodyMedium)
        ui.documentos.forEach { d -> TarjetaDocumento(d) }
        if (cerrado) {
            BannerEstado("El caso está cerrado: ya no se pueden adjuntar documentos.", Icons.Filled.Lock)
        } else {
            Button(onClick = { onAdjuntar(null) }, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) {
                Icon(Icons.Filled.CameraAlt, null); Spacer(Modifier.width(8.dp)); Text("Adjuntar foto o documento")
            }
        }
    }
}

@Composable
private fun TarjetaDocumento(d: DocumentoEntity) {
    OutlinedCard(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            val archivo = d.rutaArchivo?.let { File(it) }?.takeIf { it.exists() }
            if (archivo != null && d.mime.startsWith("image/")) {
                AsyncImage(model = archivo, contentDescription = "Vista previa de ${d.tipoDocumento}",
                    contentScale = ContentScale.Crop, modifier = Modifier.size(56.dp).clip(MaterialTheme.shapes.small))
            } else {
                Icon(if (d.mime == "application/pdf") Icons.Filled.PictureAsPdf else Icons.Filled.Image, null, Modifier.size(40.dp))
            }
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(d.tipoDocumento, style = MaterialTheme.typography.titleMedium)
                Text("${d.nombreArchivo} · ${Fechas.fecha(d.fechaCarga)}", style = MaterialTheme.typography.bodySmall)
                when (d.estado) {
                    EstadoDocumento.RECIBIDO -> EstadoTexto(Icons.Filled.CheckCircle, "Recibido por nuestro equipo")
                    EstadoDocumento.PENDIENTE_ENVIO -> EstadoTexto(Icons.Filled.Schedule, "Sin enviar: se enviará cuando tengas conexión")
                    else -> EstadoTexto(Icons.Filled.Error, "No recibido: el caso ya estaba cerrado")
                }
            }
        }
    }
}

@Composable
private fun EstadoTexto(icono: androidx.compose.ui.graphics.vector.ImageVector, texto: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Icon(icono, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
        Text(texto, style = MaterialTheme.typography.bodyMedium)
    }
}
