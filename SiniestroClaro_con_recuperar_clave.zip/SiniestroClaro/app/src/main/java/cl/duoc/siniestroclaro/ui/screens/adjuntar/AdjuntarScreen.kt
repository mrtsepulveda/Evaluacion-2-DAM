package cl.duoc.siniestroclaro.ui.screens.adjuntar

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import cl.duoc.siniestroclaro.data.local.SiniestroEntity
import cl.duoc.siniestroclaro.di.AppContainer
import cl.duoc.siniestroclaro.domain.*
import cl.duoc.siniestroclaro.ui.appViewModel
import cl.duoc.siniestroclaro.ui.components.*
import cl.duoc.siniestroclaro.ui.rememberContainer
import cl.duoc.siniestroclaro.util.ArchivoLocal
import cl.duoc.siniestroclaro.util.InfoArchivo
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class AdjuntarUi(
    val siniestro: SiniestroEntity? = null,
    val opcionesTipo: List<String> = emptyList(),
    val tipo: String? = null,
    val tipoBloqueado: Boolean = false,
    val comentario: String = "",
    val archivo: ArchivoLocal? = null,
    val errores: AdjuntoErrores = AdjuntoErrores(),
    val procesando: Boolean = false,
    val resultado: String? = null
)

class AdjuntarViewModel(private val c: AppContainer, private val siniestroId: Int, private val solicitudId: Int) : ViewModel() {
    private val _ui = MutableStateFlow(AdjuntarUi())
    val ui = _ui.asStateFlow()

    init {
        viewModelScope.launch {
            val s = c.repo.siniestroUno(siniestroId) ?: return@launch
            val propios = c.repo.tipoUno(s.tipoId)?.documentos?.split(";") ?: emptyList()
            val sol = if (solicitudId > 0) c.repo.solicitudUna(solicitudId) else null
            val opciones = (propios + sol?.tipoDocumento + "Otro documento").filterNotNull().distinct()
            _ui.update { it.copy(siniestro = s, opcionesTipo = opciones, tipo = sol?.tipoDocumento, tipoBloqueado = sol != null) }
        }
    }

    fun onTipo(t: String) { _ui.update { it.copy(tipo = t, errores = it.errores.copy(tipo = null)) } }
    fun onComentario(t: String) { _ui.update { it.copy(comentario = t.take(310), errores = it.errores.copy(comentario = if (t.length > 300) "Máximo 300 caracteres" else null)) } }

    private fun ponerArchivo(a: ArchivoLocal) {
        _ui.value.archivo?.let { File(it.ruta).delete() } // el anterior ya no se usará
        _ui.update { it.copy(archivo = a, errores = it.errores.copy(archivo = null), procesando = false) }
    }

    private fun errorArchivo(msg: String) {
        _ui.update { it.copy(procesando = false, errores = it.errores.copy(archivo = msg)) }
    }

    /** Foto tomada con la cámara (ya está en el almacenamiento privado). */
    fun onFotoTomada(ruta: String) {
        viewModelScope.launch {
            _ui.update { it.copy(procesando = true) }
            val f = File(ruta)
            withContext(Dispatchers.IO) { if (f.length() > Limites.MAX_BYTES) { c.archivos.reducirImagen(f) }; Unit }
            when {
                f.length() <= 0 -> { f.delete(); errorArchivo("No pudimos guardar la foto. Intenta de nuevo") }
                f.length() > Limites.MAX_BYTES -> { f.delete(); errorArchivo("La foto pesa más de 5 MB. Intenta de nuevo") }
                else -> ponerArchivo(ArchivoLocal(f.path, f.name, "image/jpeg", f.length()))
            }
        }
    }

    /** Archivo elegido desde el teléfono (imagen o PDF). */
    fun onArchivoElegido(uri: Uri) {
        viewModelScope.launch {
            _ui.update { it.copy(procesando = true) }
            try {
                val (info, copia) = withContext<Pair<InfoArchivo, Any>>(Dispatchers.IO) {
                    val info = c.archivos.inspeccionar(uri)
                    val err = AdjuntoValidator.errorArchivo(info.mime, info.bytes)
                    if (err != null) return@withContext info to err
                    val f = c.archivos.copiar(uri, info.nombre)
                    if (info.mime!!.startsWith("image/") && f.length() > Limites.MAX_BYTES && !c.archivos.reducirImagen(f)) {
                        f.delete(); return@withContext info to "No pudimos reducir la imagen a menos de 5 MB"
                    }
                    info to f
                }
                if (copia is String) errorArchivo(copia)
                else (copia as File).let { ponerArchivo(ArchivoLocal(it.path, it.name, info.mime!!, it.length())) }
            } catch (e: Exception) {
                errorArchivo("No pudimos abrir ese archivo")
            }
        }
    }

    fun onPermisoCamaraDenegado() = errorArchivo("Sin permiso de cámara. Puedes elegir una foto desde tus archivos")

    fun quitarArchivo() {
        _ui.value.archivo?.let { File(it.ruta).delete() }
        _ui.update { it.copy(archivo = null) }
    }

    fun enviar() {
        val u = _ui.value
        val s = u.siniestro ?: return
        viewModelScope.launch {
            val fresco = c.repo.siniestroUno(s.id) ?: return@launch
            val errores = AdjuntoValidator.validar(u.tipo, u.archivo != null, u.comentario, Etapa.from(fresco.etapa), c.repo.contarDocumentos(s.id))
            _ui.update { it.copy(errores = errores) }
            if (errores.hayErrores) return@launch
            val a = u.archivo!!
            val enLinea = c.conexion.estaEnLinea()
            c.repo.adjuntar(fresco, a.nombre, a.ruta, a.mime, u.tipo!!, u.comentario, solicitudId.takeIf { it > 0 }, a.bytes, enLinea)
            _ui.update {
                it.copy(
                    archivo = null,
                    resultado = if (enLinea) "Recibimos tu documento y ya quedó asociado a tu siniestro."
                    else "Guardamos tu documento en el teléfono. Lo enviaremos apenas tengas conexión; mientras tanto figura como «Sin enviar»."
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdjuntarScreen(siniestroId: Int, solicitudId: Int, onBack: () -> Unit) {
    val vm = appViewModel(key = "adjuntar$siniestroId-$solicitudId") { AdjuntarViewModel(it, siniestroId, solicitudId) }
    val ui by vm.ui.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val archivos = rememberContainer().archivos

    // ---- Recurso nativo 1: cámara (con permiso en tiempo de ejecución) ----
    var rutaPendiente by rememberSaveable { mutableStateOf<String?>(null) }
    val tomarFoto = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val ruta = rutaPendiente
        rutaPendiente = null
        if (ok && ruta != null) vm.onFotoTomada(ruta) else ruta?.let { File(it).delete() }
    }
    val lanzarCamara = {
        val f = archivos.nuevoArchivoFoto()
        rutaPendiente = f.path
        tomarFoto.launch(archivos.uriParaCamara(f))
    }
    val permisoCamara = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) lanzarCamara() else vm.onPermisoCamaraDenegado()
    }

    // ---- Recurso nativo 2: selector de archivos del teléfono (imagen o PDF) ----
    val elegirArchivo = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let(vm::onArchivoElegido)
    }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Adjuntar documento") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Volver") } }
        )
    }) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ui.siniestro?.let { Text("Siniestro ${it.numero}", style = MaterialTheme.typography.titleMedium) }
            AnimatedVisibility(ui.errores.general != null) {
                BannerEstado(ui.errores.general ?: "", Icons.Filled.Warning)
            }
            MenuDesplegable(
                label = "Tipo de documento", icono = Icons.Filled.Description, opciones = ui.opcionesTipo,
                seleccion = ui.tipo, texto = { it }, onSeleccion = vm::onTipo, error = ui.errores.tipo,
                enabled = !ui.tipoBloqueado
            )

            Text("Elige cómo quieres entregarlo", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                FilledTonalButton(
                    onClick = {
                        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) lanzarCamara()
                        else permisoCamara.launch(Manifest.permission.CAMERA)
                    },
                    modifier = Modifier.weight(1f).heightIn(min = 56.dp)
                ) { Icon(Icons.Filled.CameraAlt, null); Spacer(Modifier.width(8.dp)); Text("Tomar foto") }
                FilledTonalButton(
                    onClick = { elegirArchivo.launch(arrayOf("image/*", "application/pdf")) },
                    modifier = Modifier.weight(1f).heightIn(min = 56.dp)
                ) { Icon(Icons.Filled.AttachFile, null); Spacer(Modifier.width(8.dp)); Text("Elegir archivo") }
            }
            Text("Imágenes o PDF, hasta 5 MB. Tip: la foto debe verse completa y con buena luz.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

            Card(Modifier.fillMaxWidth().animateContentSize()) {
                Box(Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.Center) {
                    when {
                        ui.procesando -> CircularProgressIndicator()
                        ui.archivo == null -> Text("Aún no has elegido un archivo", style = MaterialTheme.typography.bodyMedium)
                        else -> {
                            val a = ui.archivo!!
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (a.mime.startsWith("image/"))
                                    AsyncImage(model = File(a.ruta), contentDescription = "Vista previa", contentScale = ContentScale.Fit,
                                        modifier = Modifier.fillMaxWidth().heightIn(max = 220.dp).clip(MaterialTheme.shapes.medium))
                                else Icon(Icons.Filled.PictureAsPdf, null, Modifier.size(64.dp))
                                Text("${a.nombre} · ${a.bytes / 1024} KB", style = MaterialTheme.typography.bodySmall)
                                TextButton(onClick = vm::quitarArchivo) { Icon(Icons.Filled.Close, null); Spacer(Modifier.width(4.dp)); Text("Quitar") }
                            }
                        }
                    }
                }
            }
            TextoApoyo(ui.errores.archivo)

            CampoValidado(
                ui.comentario, vm::onComentario, "Comentario (opcional)", Icons.Filled.Edit, ui.errores.comentario,
                extra = "${ui.comentario.length}/300", singleLine = false, minLines = 2
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = vm::enviar, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) {
                Text("Enviar documento", style = MaterialTheme.typography.titleMedium)
            }
        }
    }

    ui.resultado?.let { msg ->
        AlertDialog(
            onDismissRequest = onBack,
            icon = { Icon(Icons.Filled.CheckCircle, null) },
            title = { Text("Listo") },
            text = { Text(msg) },
            confirmButton = { TextButton(onClick = onBack) { Text("Volver a mi siniestro") } }
        )
    }
}
