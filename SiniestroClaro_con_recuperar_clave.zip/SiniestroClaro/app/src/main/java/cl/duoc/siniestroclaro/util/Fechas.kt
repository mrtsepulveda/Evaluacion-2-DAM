package cl.duoc.siniestroclaro.util

import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

object Fechas {
    private val zona: ZoneId = ZoneId.systemDefault()
    private val fFecha = DateTimeFormatter.ofPattern("dd-MM-yyyy")
    private val fHora = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm")

    /** "2026-09-02 18:40" -> epoch millis (se usa para los datos de ejemplo). */
    fun millis(texto: String): Long =
        LocalDateTime.parse(texto.trim().replace(" ", "T")).atZone(zona).toInstant().toEpochMilli()

    fun dia(texto: String): Long = LocalDate.parse(texto).toEpochDay()
    fun fecha(ms: Long): String = Instant.ofEpochMilli(ms).atZone(zona).format(fFecha)
    fun fechaHora(ms: Long): String = Instant.ofEpochMilli(ms).atZone(zona).format(fHora)
    fun fechaDesdeDia(epochDay: Long): String = LocalDate.ofEpochDay(epochDay).format(fFecha)
    fun hoy(): LocalDate = LocalDate.now(zona)

    fun diasDesde(ms: Long): Long =
        ChronoUnit.DAYS.between(Instant.ofEpochMilli(ms).atZone(zona).toLocalDate(), hoy())
}
