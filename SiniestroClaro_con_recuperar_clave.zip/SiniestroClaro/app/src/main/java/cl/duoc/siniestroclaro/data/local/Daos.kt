package cl.duoc.siniestroclaro.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CatalogoDao {
    @Query("SELECT COUNT(*) FROM asegurado") suspend fun contarAsegurados(): Int
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertarAsegurados(l: List<AseguradoEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertarCompanias(l: List<CompaniaEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertarTipos(l: List<TipoSiniestroEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertarColaboradores(l: List<ColaboradorEntity>)

    @Query("SELECT * FROM asegurado ORDER BY id") fun asegurados(): Flow<List<AseguradoEntity>>
    @Query("SELECT * FROM asegurado WHERE id = :id") fun asegurado(id: Int): Flow<AseguradoEntity?>
    @Query("SELECT * FROM asegurado WHERE rutNormalizado = :rut LIMIT 1") suspend fun porRut(rut: String): AseguradoEntity?
    @Query("SELECT * FROM asegurado WHERE id = :id") suspend fun aseguradoUno(id: Int): AseguradoEntity?
    @Query("UPDATE asegurado SET claveHash = :hash, claveSal = :sal WHERE id = :id")
    suspend fun guardarClave(id: Int, hash: String, sal: String)
    @Query("SELECT * FROM compania ORDER BY codigo") fun companias(): Flow<List<CompaniaEntity>>
    @Query("SELECT * FROM tipo_siniestro ORDER BY codigo") fun tipos(): Flow<List<TipoSiniestroEntity>>
    @Query("SELECT * FROM tipo_siniestro WHERE id = :id") suspend fun tipo(id: Int): TipoSiniestroEntity?
    @Query("SELECT * FROM colaborador ORDER BY id") fun colaboradores(): Flow<List<ColaboradorEntity>>
    @Query("SELECT * FROM colaborador WHERE id = :id") suspend fun colaborador(id: Int): ColaboradorEntity?
    @Query("SELECT * FROM colaborador WHERE rol = 'LIQUIDADOR' AND equipo = :equipo AND activo = 1")
    suspend fun liquidadoresActivos(equipo: String): List<ColaboradorEntity>
    @Query("SELECT * FROM colaborador WHERE rol = 'ANALISTA' AND activo = 1 ORDER BY id LIMIT 1")
    suspend fun analista(): ColaboradorEntity?
}

@Dao
interface SiniestroDao {
    // --- siniestros
    @Query(
        "SELECT * FROM siniestro WHERE aseguradoId = :id " +
            "ORDER BY CASE WHEN etapa = 'CERRADO' THEN 1 ELSE 0 END, ultimaActualizacion DESC"
    )
    fun delAsegurado(id: Int): Flow<List<SiniestroEntity>>

    @Query("SELECT * FROM siniestro WHERE id = :id") fun porId(id: Int): Flow<SiniestroEntity?>
    @Query("SELECT * FROM siniestro WHERE id = :id") suspend fun porIdUna(id: Int): SiniestroEntity?
    @Query("SELECT * FROM siniestro WHERE etapa != 'CERRADO' ORDER BY numero") fun abiertos(): Flow<List<SiniestroEntity>>

    @Query(
        "SELECT * FROM siniestro WHERE aseguradoId = :a AND companiaId = :c AND tipoId = :t " +
            "AND fechaOcurrencia = :f AND etapa != 'CERRADO' LIMIT 1"
    )
    suspend fun duplicado(a: Int, c: Int, t: Int, f: Long): SiniestroEntity?

    @Query("SELECT numero FROM siniestro ORDER BY CAST(substr(numero, 8) AS INTEGER) DESC LIMIT 1")
    suspend fun ultimoNumero(): String?

    @Query("SELECT COUNT(*) FROM siniestro WHERE liquidadorId = :id AND etapa != 'CERRADO'")
    suspend fun cargaLiquidador(id: Int): Int

    @Insert suspend fun insertar(s: SiniestroEntity): Long
    @Update suspend fun actualizar(s: SiniestroEntity)
    @Query("UPDATE siniestro SET ultimaActualizacion = :t WHERE id = :id") suspend fun tocar(id: Int, t: Long)

    // --- historial
    @Insert suspend fun insertarGestion(g: GestionEntity): Long
    @Query("SELECT * FROM gestion WHERE siniestroId = :id AND visible = 1 ORDER BY fechaHora ASC, id ASC")
    fun gestionesVisibles(id: Int): Flow<List<GestionEntity>>
    @Query("SELECT * FROM gestion WHERE siniestroId = :id ORDER BY fechaHora ASC, id ASC")
    fun gestiones(id: Int): Flow<List<GestionEntity>>

    // --- documentos solicitados y adjuntos
    @Insert suspend fun insertarSolicitud(s: SolicitudDocEntity): Long
    @Update suspend fun actualizarSolicitud(s: SolicitudDocEntity)
    @Query("SELECT * FROM solicitud_documento WHERE id = :id") suspend fun solicitud(id: Int): SolicitudDocEntity?
    @Query("SELECT * FROM solicitud_documento WHERE siniestroId = :id ORDER BY fechaSolicitud, id")
    fun solicitudes(id: Int): Flow<List<SolicitudDocEntity>>
    @Query("SELECT COUNT(*) FROM solicitud_documento WHERE siniestroId = :id AND estado = 'PENDIENTE'")
    suspend fun pendientes(id: Int): Int

    @Insert suspend fun insertarDocumento(d: DocumentoEntity): Long
    @Update suspend fun actualizarDocumento(d: DocumentoEntity)
    @Query("SELECT * FROM documento WHERE siniestroId = :id ORDER BY fechaCarga DESC, id DESC")
    fun documentos(id: Int): Flow<List<DocumentoEntity>>
    @Query("SELECT COUNT(*) FROM documento WHERE siniestroId = :id") suspend fun contarDocumentos(id: Int): Int
    @Query(
        "SELECT d.* FROM documento d INNER JOIN siniestro s ON s.id = d.siniestroId " +
            "WHERE s.aseguradoId = :a AND d.estado = 'PENDIENTE_ENVIO'"
    )
    suspend fun documentosSinEnviar(a: Int): List<DocumentoEntity>

    // --- avisos
    @Insert suspend fun insertarAviso(a: AvisoEntity): Long
    @Query("SELECT * FROM aviso WHERE aseguradoId = :a ORDER BY fechaHora DESC, id DESC")
    fun avisos(a: Int): Flow<List<AvisoEntity>>
    @Query("SELECT COUNT(*) FROM aviso WHERE aseguradoId = :a AND leido = 0") fun noLeidos(a: Int): Flow<Int>
    @Query("UPDATE aviso SET leido = 1 WHERE id = :id") suspend fun marcarLeido(id: Int)
    @Query("UPDATE aviso SET leido = 1 WHERE aseguradoId = :a") suspend fun marcarTodosLeidos(a: Int)
}
