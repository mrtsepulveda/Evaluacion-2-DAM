package cl.duoc.siniestroclaro.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Estilo sobrio y tranquilo (Aclaración 10): azul petróleo + verde suave, sin rojos de urgencia.
private val Claro = lightColorScheme(
    primary = Color(0xFF1F5F7A), onPrimary = Color.White,
    primaryContainer = Color(0xFFD3E9F2), onPrimaryContainer = Color(0xFF0A2A38),
    secondary = Color(0xFF506772), onSecondary = Color.White,
    secondaryContainer = Color(0xFFDDE8EE), onSecondaryContainer = Color(0xFF0E1E26),
    tertiary = Color(0xFF2E7D5B), onTertiary = Color.White,
    tertiaryContainer = Color(0xFFD2EFE0), onTertiaryContainer = Color(0xFF00210F),
    background = Color(0xFFF6F9FA), onBackground = Color(0xFF171C1F),
    surface = Color(0xFFF6F9FA), onSurface = Color(0xFF171C1F),
    surfaceVariant = Color(0xFFE1E8EC), onSurfaceVariant = Color(0xFF40484C),
    outline = Color(0xFF70787D),
    error = Color(0xFFB3261E), onError = Color.White,
    errorContainer = Color(0xFFF9DEDC), onErrorContainer = Color(0xFF410E0B)
)

private val Oscuro = darkColorScheme(
    primary = Color(0xFF8DCDE6), onPrimary = Color(0xFF00334A),
    primaryContainer = Color(0xFF004B66), onPrimaryContainer = Color(0xFFD3E9F2),
    secondaryContainer = Color(0xFF384A53), onSecondaryContainer = Color(0xFFDDE8EE),
    tertiary = Color(0xFF8ED8B2), tertiaryContainer = Color(0xFF0F5136), onTertiaryContainer = Color(0xFFD2EFE0),
    background = Color(0xFF0F1417), surface = Color(0xFF0F1417),
    onBackground = Color(0xFFDFE3E6), onSurface = Color(0xFFDFE3E6)
)

// Textos más grandes para adultos mayores y baja visión (RNF-04).
private val Tipografia = Typography(
    headlineMedium = TextStyle(fontSize = 26.sp, lineHeight = 32.sp, fontWeight = FontWeight.SemiBold),
    titleLarge = TextStyle(fontSize = 22.sp, lineHeight = 28.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 18.sp, lineHeight = 24.sp, fontWeight = FontWeight.Medium),
    bodyLarge = TextStyle(fontSize = 18.sp, lineHeight = 26.sp),
    bodyMedium = TextStyle(fontSize = 16.sp, lineHeight = 22.sp),
    bodySmall = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    labelLarge = TextStyle(fontSize = 16.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium)
)

@Composable
fun SiniestroClaroTheme(oscuro: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (oscuro) Oscuro else Claro, typography = Tipografia, content = content)
}
