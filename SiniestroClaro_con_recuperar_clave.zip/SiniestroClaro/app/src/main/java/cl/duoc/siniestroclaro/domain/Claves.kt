package cl.duoc.siniestroclaro.domain

import java.security.MessageDigest
import java.security.SecureRandom

/** Validaciones de contraseña, correo y código de recuperación. Lógica pura, sin Android. */
object ClaveValidator {
    const val MIN = 8
    const val MAX = 40

    fun validar(clave: String): String? = when {
        clave.isEmpty() -> "Escribe tu contraseña"
        clave.length < MIN -> "Debe tener al menos $MIN caracteres"
        clave.length > MAX -> "Máximo $MAX caracteres"
        clave.any { it.isWhitespace() } -> "No uses espacios"
        !clave.any { it.isLetter() } || !clave.any { it.isDigit() } -> "Incluye letras y números"
        else -> null
    }

    fun confirmacion(nueva: String, repetida: String): String? = when {
        repetida.isEmpty() -> "Repite la nueva contraseña"
        nueva != repetida -> "Las contraseñas no coinciden"
        else -> null
    }

    fun distintaDeLaActual(actual: String, nueva: String): String? =
        if (actual == nueva) "La nueva contraseña debe ser distinta de la actual" else null
}

object CorreoValidator {
    private val formato = Regex("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")

    fun validar(correo: String): String? = when {
        correo.isBlank() -> "Escribe tu correo registrado"
        !formato.matches(correo.trim()) -> "El correo no tiene un formato válido"
        else -> null
    }

    /** "camila.rojas@correo.ejemplo" -> "ca***@correo.ejemplo" */
    fun enmascarar(correo: String): String {
        val partes = correo.split("@")
        if (partes.size != 2) return correo
        val usuario = partes[0]
        return usuario.take(2) + "***@" + partes[1]
    }
}

object CodigoValidator {
    const val LARGO = 6
    fun validar(codigo: String): String? = when {
        codigo.isEmpty() -> "Escribe el código de $LARGO dígitos"
        codigo.length < LARGO -> "El código tiene $LARGO dígitos"
        else -> null
    }
}

/** Hash con sal por usuario: la contraseña nunca se guarda en texto plano (RNF-08). */
object ClaveHasher {
    private val azar = SecureRandom()

    fun nuevaSal(): String = ByteArray(16).also { azar.nextBytes(it) }.toHex()

    fun hash(clave: String, sal: String): String =
        MessageDigest.getInstance("SHA-256").digest((sal + clave).toByteArray(Charsets.UTF_8)).toHex()

    fun coincide(clave: String, sal: String, hashGuardado: String): Boolean =
        hashGuardado.isNotEmpty() && MessageDigest.isEqual(
            hash(clave, sal).toByteArray(Charsets.UTF_8), hashGuardado.toByteArray(Charsets.UTF_8)
        )

    private fun ByteArray.toHex() = joinToString("") { "%02x".format(it) }
}

enum class ResultadoCodigo { CORRECTO, INCORRECTO, EXPIRADO, BLOQUEADO }

/**
 * Código de un solo uso para recuperar la contraseña. Vence a los 5 minutos y se bloquea tras 3 intentos fallidos.
 * En la versión real el código llegaría por correo; en esta demo se muestra en pantalla.
 */
class CodigoRecuperacion(
    private val vigenciaMs: Long = 5 * 60_000L,
    private val maxIntentos: Int = 3,
    private val azar: SecureRandom = SecureRandom()
) {
    private var codigo: String = ""
    private var emitidoEn: Long = 0
    private var intentos: Int = 0

    fun emitir(ahora: Long): String {
        codigo = (0 until CodigoValidator.LARGO).joinToString("") { azar.nextInt(10).toString() }
        emitidoEn = ahora
        intentos = 0
        return codigo
    }

    fun intentosRestantes(): Int = (maxIntentos - intentos).coerceAtLeast(0)

    fun verificar(ingresado: String, ahora: Long): ResultadoCodigo = when {
        codigo.isEmpty() || intentos >= maxIntentos -> ResultadoCodigo.BLOQUEADO
        ahora - emitidoEn > vigenciaMs -> ResultadoCodigo.EXPIRADO
        ingresado == codigo -> ResultadoCodigo.CORRECTO
        else -> { intentos++; if (intentos >= maxIntentos) ResultadoCodigo.BLOQUEADO else ResultadoCodigo.INCORRECTO }
    }
}
