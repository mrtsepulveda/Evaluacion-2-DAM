# Arquitectura EventPass

## Flujo de compra y emisión

```
Comprador
   │  POST /api/ordenes   (JWT)
   ▼
API Gateway (:8080)  ─────────────────────────────┐
   │                                              │
   ▼                                              │
order-service                                     │
  guarda Orden PENDIENTE_EMISION                  │
  responde 201 de inmediato                       │
                                                  │
ticket-processor  (Lambda)                        │
  GET  /internal/ordenes/pendientes               │
  POST /internal/ordenes/{id}/reclamar            │
  POST /internal/eventos/{id}/reservar-cupo       │
       └─ UPDATE atómico aforo_disponible         │
  POST /internal/tickets  → código EP-XXXXXXXX    │
  POST /internal/ordenes/{id}/emitida             │
       o /rechazar si no hay cupo                 │
                                                  │
Staff  POST /api/tickets/{codigo}/validar         │
  ticket EMITIDO → UTILIZADO (no reutilizable)    │
```

## Por qué se separa la compra de la emisión

Si se descontara el aforo y se generara el código en el mismo request de compra, una preventa concurrente podría bloquear hilos, caer el servicio o sobrevender. La orden se acepta rápido; el aforo se reserva solo cuando el worker procesa la cola.

## Base de datos

Cada microservicio tiene su propio esquema (H2 file o PostgreSQL). No hay FK entre servicios: `usuarioId` y `eventoId` se guardan como identificadores.
