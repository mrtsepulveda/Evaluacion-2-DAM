package com.eventpass.orden.client;

import com.eventpass.common.exception.RecursoNoEncontradoException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClient;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Component
public class EventoClient {

    private final RestClient restClient;

    public EventoClient(@Value("${eventpass.event-service-url}") String baseUrl) {
        this.restClient = RestClient.builder().baseUrl(baseUrl).build();
    }

    public EventoSnapshot obtener(Long eventoId) {
        try {
            EventoSnapshot snapshot = restClient.get()
                    .uri("/api/eventos/{id}", eventoId)
                    .retrieve()
                    .body(EventoSnapshot.class);
            if (snapshot == null) {
                throw new RecursoNoEncontradoException("Evento no encontrado");
            }
            return snapshot;
        } catch (HttpClientErrorException.NotFound ex) {
            throw new RecursoNoEncontradoException("Evento no encontrado");
        }
    }

    public record EventoSnapshot(
            Long id,
            String nombre,
            String descripcion,
            LocalDateTime fechaHora,
            Integer aforoTotal,
            Integer aforoDisponible,
            BigDecimal precio,
            boolean activo
    ) {
    }
}
