package com.eventpass.orden.web;

import com.eventpass.orden.dto.CrearOrdenRequest;
import com.eventpass.orden.dto.OrdenResponse;
import com.eventpass.orden.service.OrdenAppService;
import com.eventpass.common.security.UsuarioAutenticado;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/ordenes")
public class OrdenController {

    private final OrdenAppService ordenAppService;

    public OrdenController(OrdenAppService ordenAppService) {
        this.ordenAppService = ordenAppService;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public OrdenResponse crear(@AuthenticationPrincipal UsuarioAutenticado usuario,
                               @Valid @RequestBody CrearOrdenRequest request) {
        return ordenAppService.crear(usuario.getId(), usuario.getUsername(), request);
    }

    @GetMapping("/mias")
    public List<OrdenResponse> mias(@AuthenticationPrincipal UsuarioAutenticado usuario) {
        return ordenAppService.mias(usuario.getId());
    }

    @GetMapping("/{id}")
    public OrdenResponse obtener(@AuthenticationPrincipal UsuarioAutenticado usuario, @PathVariable Long id) {
        boolean admin = "ADMIN".equals(usuario.getRol());
        return ordenAppService.obtener(id, usuario.getId(), admin);
    }
}
