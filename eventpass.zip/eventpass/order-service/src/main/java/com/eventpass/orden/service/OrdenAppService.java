package com.eventpass.orden.service;

import com.eventpass.common.exception.RecursoNoEncontradoException;
import com.eventpass.common.exception.ReglaNegocioException;
import com.eventpass.orden.client.EventoClient;
import com.eventpass.orden.domain.DetalleOrden;
import com.eventpass.orden.domain.EstadoOrden;
import com.eventpass.orden.domain.Orden;
import com.eventpass.orden.dto.CrearOrdenRequest;
import com.eventpass.orden.dto.OrdenResponse;
import com.eventpass.orden.repository.OrdenRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

@Service
public class OrdenAppService {

    private final OrdenRepository ordenRepository;
    private final EventoClient eventoClient;

    public OrdenAppService(OrdenRepository ordenRepository, EventoClient eventoClient) {
        this.ordenRepository = ordenRepository;
        this.eventoClient = eventoClient;
    }

    @Transactional
    public OrdenResponse crear(Long usuarioId, String email, CrearOrdenRequest request) {
        EventoClient.EventoSnapshot evento = eventoClient.obtener(request.eventoId());
        if (!evento.activo()) {
            throw new ReglaNegocioException("El evento no está disponible para compra");
        }
        Orden orden = new Orden();
        orden.setUsuarioId(usuarioId);
        orden.setEmailComprador(email);
        orden.setEstado(EstadoOrden.PENDIENTE_EMISION);

        DetalleOrden detalle = new DetalleOrden();
        detalle.setEventoId(evento.id());
        detalle.setNombreEvento(evento.nombre());
        detalle.setCantidad(request.cantidad());
        detalle.setPrecioUnitario(evento.precio());
        orden.agregarDetalle(detalle);

        return OrdenResponse.from(ordenRepository.save(orden));
    }

    @Transactional(readOnly = true)
    public List<OrdenResponse> mias(Long usuarioId) {
        return ordenRepository.findByUsuarioIdOrderByCreadaEnDesc(usuarioId).stream()
                .map(OrdenResponse::from)
                .toList();
    }

    @Transactional(readOnly = true)
    public OrdenResponse obtener(Long id, Long usuarioId, boolean admin) {
        Orden orden = buscar(id);
        if (!admin && !orden.getUsuarioId().equals(usuarioId)) {
            throw new RecursoNoEncontradoException("Orden no encontrada");
        }
        return OrdenResponse.from(orden);
    }

    @Transactional(readOnly = true)
    public List<OrdenResponse> pendientes() {
        return ordenRepository.findByEstadoOrderByCreadaEnAsc(EstadoOrden.PENDIENTE_EMISION).stream()
                .map(OrdenResponse::from)
                .toList();
    }

    @Transactional
    public OrdenResponse reclamar(Long id) {
        int n = ordenRepository.reclamar(id);
        if (n == 0) {
            throw new ReglaNegocioException("La orden no está pendiente de emisión");
        }
        return OrdenResponse.from(buscar(id));
    }

    @Transactional
    public OrdenResponse marcarEmitida(Long id) {
        ordenRepository.finalizar(id, EstadoOrden.EMITIDA, Instant.now(), null);
        return OrdenResponse.from(buscar(id));
    }

    @Transactional
    public OrdenResponse rechazarSinCupo(Long id, String motivo) {
        ordenRepository.finalizar(id, EstadoOrden.RECHAZADA_SIN_CUPO, Instant.now(), motivo);
        return OrdenResponse.from(buscar(id));
    }

    private Orden buscar(Long id) {
        return ordenRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Orden no encontrada"));
    }
}
