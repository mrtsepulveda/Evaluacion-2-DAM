package com.eventpass.orden.config;

import com.eventpass.common.security.JwtService;
import com.eventpass.common.security.SecurityConfigSupport;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class OrdenSecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http,
                                                   JwtService jwtService,
                                                   @Value("${eventpass.internal-token}") String internalToken) throws Exception {
        return SecurityConfigSupport.jwtStateless(http, jwtService, internalToken)
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/h2-console/**", "/swagger-ui/**", "/v3/api-docs/**").permitAll()
                        .requestMatchers("/internal/**").permitAll()
                        .requestMatchers("/api/ordenes/**").hasAnyRole("COMPRADOR", "ADMIN")
                        .anyRequest().authenticated())
                .build();
    }
}
