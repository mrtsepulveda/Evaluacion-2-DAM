package com.eventpass.orden.dto;

import com.eventpass.orden.domain.DetalleOrden;
import com.eventpass.orden.domain.EstadoOrden;
import com.eventpass.orden.domain.Orden;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

public record OrdenResponse(
        Long id,
        Long usuarioId,
        String emailComprador,
        EstadoOrden estado,
        BigDecimal total,
        Instant creadaEn,
        Instant procesadaEn,
        String motivoRechazo,
        List<DetalleResponse> detalles
) {
    public record DetalleResponse(Long eventoId, String nombreEvento, Integer cantidad, BigDecimal precioUnitario) {
    }

    public static OrdenResponse from(Orden orden) {
        List<DetalleResponse> detalles = orden.getDetalles().stream()
                .map(d -> new DetalleResponse(d.getEventoId(), d.getNombreEvento(), d.getCantidad(), d.getPrecioUnitario()))
                .toList();
        return new OrdenResponse(
                orden.getId(),
                orden.getUsuarioId(),
                orden.getEmailComprador(),
                orden.getEstado(),
                orden.getTotal(),
                orden.getCreadaEn(),
                orden.getProcesadaEn(),
                orden.getMotivoRechazo(),
                detalles
        );
    }

    public static OrdenResponse from(Orden orden, List<DetalleOrden> loaded) {
        return from(orden);
    }
}
