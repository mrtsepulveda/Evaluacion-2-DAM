package com.eventpass.orden.web;

import com.eventpass.orden.dto.OrdenResponse;
import com.eventpass.orden.service.OrdenAppService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/internal/ordenes")
public class OrdenInternalController {

    private final OrdenAppService ordenAppService;

    public OrdenInternalController(OrdenAppService ordenAppService) {
        this.ordenAppService = ordenAppService;
    }

    @GetMapping("/pendientes")
    public List<OrdenResponse> pendientes() {
        return ordenAppService.pendientes();
    }

    @PostMapping("/{id}/reclamar")
    public OrdenResponse reclamar(@PathVariable Long id) {
        return ordenAppService.reclamar(id);
    }

    @PostMapping("/{id}/emitida")
    public OrdenResponse emitida(@PathVariable Long id) {
        return ordenAppService.marcarEmitida(id);
    }

    @PostMapping("/{id}/rechazar")
    public OrdenResponse rechazar(@PathVariable Long id,
                                  @RequestParam(defaultValue = "Sin cupo disponible") String motivo) {
        return ordenAppService.rechazarSinCupo(id, motivo);
    }
}
