package com.eventpass.orden.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public record CrearOrdenRequest(
        @NotNull Long eventoId,
        @NotNull @Min(1) Integer cantidad
) {
}
