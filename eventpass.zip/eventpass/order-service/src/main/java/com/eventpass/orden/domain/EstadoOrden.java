package com.eventpass.orden.domain;

public enum EstadoOrden {
    PENDIENTE_EMISION,
    EN_PROCESO,
    EMITIDA,
    RECHAZADA_SIN_CUPO
}
