package com.eventpass.orden.repository;

import com.eventpass.orden.domain.EstadoOrden;
import com.eventpass.orden.domain.Orden;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.Instant;
import java.util.List;

public interface OrdenRepository extends JpaRepository<Orden, Long> {

    @EntityGraph(attributePaths = "detalles")
    List<Orden> findByUsuarioIdOrderByCreadaEnDesc(Long usuarioId);

    @EntityGraph(attributePaths = "detalles")
    List<Orden> findByEstadoOrderByCreadaEnAsc(EstadoOrden estado);

    @Modifying
    @Query("""
            update Orden o
               set o.estado = com.eventpass.orden.domain.EstadoOrden.EN_PROCESO
             where o.id = :id
               and o.estado = com.eventpass.orden.domain.EstadoOrden.PENDIENTE_EMISION
            """)
    int reclamar(@Param("id") Long id);

    @Modifying
    @Query("""
            update Orden o
               set o.estado = :estado, o.procesadaEn = :cuando, o.motivoRechazo = :motivo
             where o.id = :id
            """)
    int finalizar(@Param("id") Long id,
                  @Param("estado") EstadoOrden estado,
                  @Param("cuando") Instant cuando,
                  @Param("motivo") String motivo);
}
