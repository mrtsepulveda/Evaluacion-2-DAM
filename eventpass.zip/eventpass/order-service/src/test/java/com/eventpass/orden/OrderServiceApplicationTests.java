package com.eventpass.orden;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderServiceApplicationTests {
    @Test
    void contextLoads() {
    }
}
