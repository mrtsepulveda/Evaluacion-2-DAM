package com.eventpass.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatusCode;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * Equivalente local de una función Lambda disparada por SQS:
 * toma órdenes aceptadas y pendientes de emisión, verifica aforo y genera códigos.
 */
@Component
public class EmisionWorker {

    private static final Logger log = LoggerFactory.getLogger(EmisionWorker.class);

    private final RestClient orders;
    private final RestClient events;
    private final RestClient tickets;
    private final String token;

    public EmisionWorker(@Value("${eventpass.order-service-url}") String ordersUrl,
                         @Value("${eventpass.event-service-url}") String eventsUrl,
                         @Value("${eventpass.ticket-service-url}") String ticketsUrl,
                         @Value("${eventpass.internal-token}") String token) {
        this.token = token;
        this.orders = RestClient.builder().baseUrl(ordersUrl).build();
        this.events = RestClient.builder().baseUrl(eventsUrl).build();
        this.tickets = RestClient.builder().baseUrl(ticketsUrl).build();
    }

    @Scheduled(fixedDelayString = "${eventpass.poll-ms}")
    public void procesarCola() {
        List<OrdenPendiente> pendientes = orders.get()
                .uri("/internal/ordenes/pendientes")
                .header("X-Internal-Token", token)
                .retrieve()
                .body(new ParameterizedTypeReference<>() {
                });
        if (pendientes == null || pendientes.isEmpty()) {
            return;
        }
        for (OrdenPendiente orden : pendientes) {
            procesar(orden);
        }
    }

    private void procesar(OrdenPendiente orden) {
        try {
            orders.post()
                    .uri("/internal/ordenes/{id}/reclamar", orden.id())
                    .header("X-Internal-Token", token)
                    .retrieve()
                    .toBodilessEntity();

            for (Detalle detalle : orden.detalles()) {
                events.post()
                        .uri("/internal/eventos/{id}/reservar-cupo", detalle.eventoId())
                        .header("X-Internal-Token", token)
                        .body(Map.of("cantidad", detalle.cantidad()))
                        .retrieve()
                        .onStatus(HttpStatusCode::isError, (req, res) -> {
                            throw new SinCupoException("Sin cupo para evento " + detalle.eventoId());
                        })
                        .toBodilessEntity();

                tickets.post()
                        .uri("/internal/tickets")
                        .header("X-Internal-Token", token)
                        .body(Map.of(
                                "ordenId", orden.id(),
                                "eventoId", detalle.eventoId(),
                                "usuarioId", orden.usuarioId(),
                                "nombreEvento", detalle.nombreEvento(),
                                "cantidad", detalle.cantidad()
                        ))
                        .retrieve()
                        .toBodilessEntity();
            }

            orders.post()
                    .uri("/internal/ordenes/{id}/emitida", orden.id())
                    .header("X-Internal-Token", token)
                    .retrieve()
                    .toBodilessEntity();
            log.info("Orden {} emitida", orden.id());
        } catch (SinCupoException ex) {
            log.warn("Orden {} rechazada: {}", orden.id(), ex.getMessage());
            orders.post()
                    .uri("/internal/ordenes/{id}/rechazar?motivo={motivo}", orden.id(), ex.getMessage())
                    .header("X-Internal-Token", token)
                    .retrieve()
                    .toBodilessEntity();
        } catch (Exception ex) {
            log.error("Fallo procesando orden {}", orden.id(), ex);
        }
    }

    public record OrdenPendiente(Long id, Long usuarioId, List<Detalle> detalles) {
    }

    public record Detalle(Long eventoId, String nombreEvento, Integer cantidad, BigDecimal precioUnitario) {
    }

    static class SinCupoException extends RuntimeException {
        SinCupoException(String message) {
            super(message);
        }
    }
}
