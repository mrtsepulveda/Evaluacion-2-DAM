package com.eventpass.processor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class TicketProcessorApplication {
    public static void main(String[] args) {
        SpringApplication.run(TicketProcessorApplication.class, args);
    }
}
