package com.eventpass.common.config;

import com.eventpass.common.exception.GlobalExceptionHandler;
import com.eventpass.common.security.JwtProperties;
import com.eventpass.common.security.JwtService;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@EnableConfigurationProperties(JwtProperties.class)
@Import(GlobalExceptionHandler.class)
public class CommonAutoConfiguration {

    @Bean
    public JwtService jwtService(JwtProperties properties) {
        return new JwtService(properties);
    }
}
