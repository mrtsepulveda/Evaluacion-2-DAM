package com.eventpass.common.exception;

import java.time.Instant;

public record ApiError(Instant timestamp, int status, String error, String mensaje, String path) {
}
