package com.eventpass.common.security;

public final class Roles {
    public static final String COMPRADOR = "COMPRADOR";
    public static final String STAFF = "STAFF";
    public static final String ADMIN = "ADMIN";

    private Roles() {
    }
}
