package com.eventpass.common.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;

public class JwtService {

    private final JwtProperties properties;

    public JwtService(JwtProperties properties) {
        this.properties = properties;
    }

    public String generar(Long usuarioId, String email, String rol) {
        Date ahora = new Date();
        Date expira = new Date(ahora.getTime() + properties.getExpirationMs());
        return Jwts.builder()
                .subject(email)
                .claim("uid", usuarioId)
                .claim("rol", rol)
                .issuedAt(ahora)
                .expiration(expira)
                .signWith(clave())
                .compact();
    }

    public Claims validar(String token) {
        return Jwts.parser()
                .verifyWith(clave())
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    private SecretKey clave() {
        byte[] bytes = properties.getSecret().getBytes(StandardCharsets.UTF_8);
        if (bytes.length < 32) {
            bytes = (properties.getSecret() + "0123456789abcdef0123456789abcdef")
                    .substring(0, 32)
                    .getBytes(StandardCharsets.UTF_8);
        }
        return Keys.hmacShaKeyFor(bytes);
    }
}
