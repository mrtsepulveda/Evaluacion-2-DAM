package com.eventpass.evento;

import com.eventpass.evento.repository.EventoRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class EventoRepositoryTest {

    @Autowired
    private EventoRepository eventoRepository;

    @Test
    @Transactional
    void reservaCupoAtomicaNoPermiteNegativo() {
        Long id = eventoRepository.findByActivoTrueOrderByFechaHoraAsc().get(0).getId();
        int ok = eventoRepository.reservarCupo(id, 1);
        int exceso = eventoRepository.reservarCupo(id, 10_000);
        assertThat(ok).isEqualTo(1);
        assertThat(exceso).isEqualTo(0);
    }
}
