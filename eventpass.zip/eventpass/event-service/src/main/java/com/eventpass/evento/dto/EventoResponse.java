package com.eventpass.evento.dto;

import com.eventpass.evento.domain.Evento;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public record EventoResponse(
        Long id,
        String nombre,
        String descripcion,
        LocalDateTime fechaHora,
        Integer aforoTotal,
        Integer aforoDisponible,
        BigDecimal precio,
        boolean activo,
        String categoria,
        String recinto,
        String direccion
) {
    public static EventoResponse from(Evento evento) {
        return new EventoResponse(
                evento.getId(),
                evento.getNombre(),
                evento.getDescripcion(),
                evento.getFechaHora(),
                evento.getAforoTotal(),
                evento.getAforoDisponible(),
                evento.getPrecio(),
                evento.isActivo(),
                evento.getCategoria().getNombre(),
                evento.getRecinto().getNombre(),
                evento.getRecinto().getDireccion()
        );
    }
}
