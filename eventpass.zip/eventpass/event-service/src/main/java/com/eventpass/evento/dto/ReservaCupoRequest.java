package com.eventpass.evento.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public record ReservaCupoRequest(@NotNull @Min(1) Integer cantidad) {
}
