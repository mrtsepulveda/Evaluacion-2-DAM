package com.eventpass.evento.web;

import com.eventpass.evento.dto.EventoResponse;
import com.eventpass.evento.dto.ReservaCupoRequest;
import com.eventpass.evento.service.EventoAppService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/internal/eventos")
public class EventoInternalController {

    private final EventoAppService eventoAppService;

    public EventoInternalController(EventoAppService eventoAppService) {
        this.eventoAppService = eventoAppService;
    }

    @PostMapping("/{id}/reservar-cupo")
    public EventoResponse reservar(@PathVariable Long id, @Valid @RequestBody ReservaCupoRequest request) {
        return eventoAppService.reservarCupo(id, request.cantidad());
    }
}
