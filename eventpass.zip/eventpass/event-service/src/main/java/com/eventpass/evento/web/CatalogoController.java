package com.eventpass.evento.web;

import com.eventpass.evento.domain.Categoria;
import com.eventpass.evento.domain.Recinto;
import com.eventpass.evento.repository.CategoriaRepository;
import com.eventpass.evento.repository.RecintoRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api")
public class CatalogoController {

    private final CategoriaRepository categoriaRepository;
    private final RecintoRepository recintoRepository;

    public CatalogoController(CategoriaRepository categoriaRepository, RecintoRepository recintoRepository) {
        this.categoriaRepository = categoriaRepository;
        this.recintoRepository = recintoRepository;
    }

    @GetMapping("/categorias")
    public List<CategoriaVista> categorias() {
        return categoriaRepository.findAll().stream()
                .map(c -> new CategoriaVista(c.getId(), c.getNombre()))
                .toList();
    }

    @GetMapping("/recintos")
    public List<RecintoVista> recintos() {
        return recintoRepository.findAll().stream()
                .map(r -> new RecintoVista(r.getId(), r.getNombre(), r.getDireccion(), r.getCapacidadMaxima()))
                .toList();
    }

    public record CategoriaVista(Long id, String nombre) {
    }

    public record RecintoVista(Long id, String nombre, String direccion, Integer capacidadMaxima) {
    }
}
