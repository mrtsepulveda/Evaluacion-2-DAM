package com.eventpass.evento.config;

import com.eventpass.evento.domain.Categoria;
import com.eventpass.evento.domain.Evento;
import com.eventpass.evento.domain.Recinto;
import com.eventpass.evento.repository.CategoriaRepository;
import com.eventpass.evento.repository.EventoRepository;
import com.eventpass.evento.repository.RecintoRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Configuration
public class DatosIniciales {

    @Bean
    CommandLineRunner seedEventos(CategoriaRepository categorias,
                                  RecintoRepository recintos,
                                  EventoRepository eventos) {
        return args -> {
            if (eventos.count() > 0) {
                return;
            }
            Categoria concierto = categorias.save(new Categoria("Concierto"));
            Categoria universitario = categorias.save(new Categoria("Universitario"));
            Recinto teatro = recintos.save(new Recinto("Teatro Central U", "Av. Universidad 100", 400));
            Recinto estadio = recintos.save(new Recinto("Estadio Campus", "Camino Norte 50", 800));

            Evento primavera = new Evento();
            primavera.setNombre("Festival Primavera Campus");
            primavera.setDescripcion("Preventa de festival universitario");
            primavera.setFechaHora(LocalDateTime.now().plusMonths(2));
            primavera.setAforoTotal(50);
            primavera.setAforoDisponible(50);
            primavera.setPrecio(new BigDecimal("15000"));
            primavera.setCategoria(universitario);
            primavera.setRecinto(teatro);

            Evento rock = new Evento();
            rock.setNombre("Concierto Rock Express");
            rock.setDescripcion("Aforo reducido para demostrar rechazo por cupo");
            rock.setFechaHora(LocalDateTime.now().plusMonths(1));
            rock.setAforoTotal(2);
            rock.setAforoDisponible(2);
            rock.setPrecio(new BigDecimal("25000"));
            rock.setCategoria(concierto);
            rock.setRecinto(estadio);

            eventos.save(primavera);
            eventos.save(rock);
        };
    }
}
