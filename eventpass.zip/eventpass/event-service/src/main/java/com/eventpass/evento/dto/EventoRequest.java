package com.eventpass.evento.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public record EventoRequest(
        @NotBlank String nombre,
        String descripcion,
        @NotNull @Future LocalDateTime fechaHora,
        @NotNull @Min(1) Integer aforoTotal,
        @NotNull @DecimalMin("0.0") BigDecimal precio,
        @NotNull Long categoriaId,
        @NotNull Long recintoId,
        Boolean activo
) {
}
