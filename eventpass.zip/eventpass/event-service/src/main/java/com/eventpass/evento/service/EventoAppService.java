package com.eventpass.evento.service;

import com.eventpass.common.exception.RecursoNoEncontradoException;
import com.eventpass.common.exception.ReglaNegocioException;
import com.eventpass.evento.domain.Categoria;
import com.eventpass.evento.domain.Evento;
import com.eventpass.evento.domain.Recinto;
import com.eventpass.evento.dto.EventoRequest;
import com.eventpass.evento.dto.EventoResponse;
import com.eventpass.evento.repository.CategoriaRepository;
import com.eventpass.evento.repository.EventoRepository;
import com.eventpass.evento.repository.RecintoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class EventoAppService {

    private final EventoRepository eventoRepository;
    private final CategoriaRepository categoriaRepository;
    private final RecintoRepository recintoRepository;

    public EventoAppService(EventoRepository eventoRepository,
                            CategoriaRepository categoriaRepository,
                            RecintoRepository recintoRepository) {
        this.eventoRepository = eventoRepository;
        this.categoriaRepository = categoriaRepository;
        this.recintoRepository = recintoRepository;
    }

    @Transactional(readOnly = true)
    public List<EventoResponse> listar() {
        return eventoRepository.findByActivoTrueOrderByFechaHoraAsc().stream()
                .map(EventoResponse::from)
                .toList();
    }

    @Transactional(readOnly = true)
    public EventoResponse obtener(Long id) {
        return EventoResponse.from(buscar(id));
    }

    @Transactional
    public EventoResponse crear(EventoRequest request) {
        Evento evento = new Evento();
        aplicar(evento, request);
        evento.setAforoDisponible(request.aforoTotal());
        return EventoResponse.from(eventoRepository.save(evento));
    }

    @Transactional
    public EventoResponse actualizar(Long id, EventoRequest request) {
        Evento evento = buscar(id);
        int vendidos = evento.getAforoTotal() - evento.getAforoDisponible();
        aplicar(evento, request);
        int disponible = request.aforoTotal() - vendidos;
        if (disponible < 0) {
            throw new ReglaNegocioException("El nuevo aforo es menor a las entradas ya reservadas");
        }
        evento.setAforoDisponible(disponible);
        return EventoResponse.from(evento);
    }

    @Transactional
    public void eliminar(Long id) {
        Evento evento = buscar(id);
        evento.setActivo(false);
    }

    @Transactional
    public EventoResponse reservarCupo(Long id, int cantidad) {
        int actualizados = eventoRepository.reservarCupo(id, cantidad);
        if (actualizados == 0) {
            throw new ReglaNegocioException("No hay cupos suficientes para el evento " + id);
        }
        return obtener(id);
    }

    private Evento buscar(Long id) {
        return eventoRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Evento no encontrado"));
    }

    private void aplicar(Evento evento, EventoRequest request) {
        Categoria categoria = categoriaRepository.findById(request.categoriaId())
                .orElseThrow(() -> new RecursoNoEncontradoException("Categoría no encontrada"));
        Recinto recinto = recintoRepository.findById(request.recintoId())
                .orElseThrow(() -> new RecursoNoEncontradoException("Recinto no encontrado"));
        evento.setNombre(request.nombre());
        evento.setDescripcion(request.descripcion());
        evento.setFechaHora(request.fechaHora());
        evento.setAforoTotal(request.aforoTotal());
        evento.setPrecio(request.precio());
        evento.setCategoria(categoria);
        evento.setRecinto(recinto);
        evento.setActivo(request.activo() == null || request.activo());
    }
}
