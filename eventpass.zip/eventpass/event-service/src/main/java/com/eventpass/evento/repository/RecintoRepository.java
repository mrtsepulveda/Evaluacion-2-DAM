package com.eventpass.evento.repository;

import com.eventpass.evento.domain.Recinto;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface RecintoRepository extends JpaRepository<Recinto, Long> {
    Optional<Recinto> findByNombreIgnoreCase(String nombre);
}
