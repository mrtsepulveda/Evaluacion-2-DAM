package com.eventpass.ticket.web;

import com.eventpass.common.security.UsuarioAutenticado;
import com.eventpass.ticket.dto.TicketResponse;
import com.eventpass.ticket.dto.ValidacionResponse;
import com.eventpass.ticket.service.TicketAppService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/tickets")
public class TicketController {

    private final TicketAppService ticketAppService;

    public TicketController(TicketAppService ticketAppService) {
        this.ticketAppService = ticketAppService;
    }

    @GetMapping("/mios")
    public List<TicketResponse> mios(@AuthenticationPrincipal UsuarioAutenticado usuario) {
        return ticketAppService.mios(usuario.getId());
    }

    @GetMapping("/{codigo}")
    public TicketResponse porCodigo(@AuthenticationPrincipal UsuarioAutenticado usuario, @PathVariable String codigo) {
        return ticketAppService.porCodigo(codigo, usuario.getId(), usuario.getRol());
    }

    @PostMapping("/{codigo}/validar")
    public ValidacionResponse validar(@AuthenticationPrincipal UsuarioAutenticado usuario, @PathVariable String codigo) {
        return ticketAppService.validar(codigo, usuario.getId());
    }
}
