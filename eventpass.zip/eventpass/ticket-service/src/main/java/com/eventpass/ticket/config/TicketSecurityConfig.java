package com.eventpass.ticket.config;

import com.eventpass.common.security.JwtService;
import com.eventpass.common.security.SecurityConfigSupport;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class TicketSecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http,
                                                   JwtService jwtService,
                                                   @Value("${eventpass.internal-token}") String internalToken) throws Exception {
        return SecurityConfigSupport.jwtStateless(http, jwtService, internalToken)
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/h2-console/**", "/swagger-ui/**", "/v3/api-docs/**").permitAll()
                        .requestMatchers("/internal/**").permitAll()
                        .requestMatchers(HttpMethod.POST, "/api/tickets/*/validar").hasRole("STAFF")
                        .requestMatchers("/api/tickets/**").hasAnyRole("COMPRADOR", "STAFF", "ADMIN")
                        .anyRequest().authenticated())
                .build();
    }
}
