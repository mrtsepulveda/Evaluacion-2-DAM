package com.eventpass.ticket.service;

import com.eventpass.common.exception.RecursoNoEncontradoException;
import com.eventpass.common.exception.ReglaNegocioException;
import com.eventpass.ticket.domain.EstadoTicket;
import com.eventpass.ticket.domain.Ticket;
import com.eventpass.ticket.domain.ValidacionAcceso;
import com.eventpass.ticket.dto.EmitirTicketRequest;
import com.eventpass.ticket.dto.TicketResponse;
import com.eventpass.ticket.dto.ValidacionResponse;
import com.eventpass.ticket.repository.TicketRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@Service
public class TicketAppService {

    private static final String ALFABETO = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    private final TicketRepository ticketRepository;
    private final SecureRandom random = new SecureRandom();

    public TicketAppService(TicketRepository ticketRepository) {
        this.ticketRepository = ticketRepository;
    }

    @Transactional
    public List<TicketResponse> emitir(EmitirTicketRequest request) {
        if (ticketRepository.existsByOrdenId(request.ordenId())) {
            throw new ReglaNegocioException("La orden ya tiene tickets emitidos");
        }
        List<TicketResponse> emitidos = new ArrayList<>();
        for (int i = 0; i < request.cantidad(); i++) {
            Ticket ticket = new Ticket();
            ticket.setCodigoAcceso(generarCodigo());
            ticket.setOrdenId(request.ordenId());
            ticket.setEventoId(request.eventoId());
            ticket.setUsuarioId(request.usuarioId());
            ticket.setNombreEvento(request.nombreEvento());
            ticket.setEstado(EstadoTicket.EMITIDO);
            emitidos.add(TicketResponse.from(ticketRepository.save(ticket)));
        }
        return emitidos;
    }

    @Transactional(readOnly = true)
    public List<TicketResponse> mios(Long usuarioId) {
        return ticketRepository.findByUsuarioIdOrderByEmitidoEnDesc(usuarioId).stream()
                .map(TicketResponse::from)
                .toList();
    }

    @Transactional(readOnly = true)
    public TicketResponse porCodigo(String codigo, Long usuarioId, String rol) {
        Ticket ticket = buscarPorCodigo(codigo);
        if ("COMPRADOR".equals(rol) && !ticket.getUsuarioId().equals(usuarioId)) {
            throw new RecursoNoEncontradoException("Ticket no encontrado");
        }
        return TicketResponse.from(ticket);
    }

    @Transactional
    public ValidacionResponse validar(String codigo, Long staffId) {
        Ticket ticket = buscarPorCodigo(codigo);
        ValidacionAcceso validacion = new ValidacionAcceso();
        validacion.setTicket(ticket);
        validacion.setStaffId(staffId);

        if (ticket.getEstado() == EstadoTicket.UTILIZADO) {
            validacion.setAceptado(false);
            validacion.setObservacion("Código ya utilizado");
            ticket.getValidaciones().add(validacion);
            throw new ReglaNegocioException("El código de acceso ya fue utilizado");
        }
        if (ticket.getEstado() != EstadoTicket.EMITIDO) {
            validacion.setAceptado(false);
            validacion.setObservacion("Ticket no válido para ingreso");
            ticket.getValidaciones().add(validacion);
            throw new ReglaNegocioException("El ticket no se puede validar en su estado actual");
        }

        ticket.setEstado(EstadoTicket.UTILIZADO);
        validacion.setAceptado(true);
        validacion.setObservacion("Ingreso autorizado");
        ticket.getValidaciones().add(validacion);
        return new ValidacionResponse(true, "Ingreso autorizado", ticket.getCodigoAcceso(), ticket.getEstado());
    }

    private Ticket buscarPorCodigo(String codigo) {
        return ticketRepository.findByCodigoAcceso(codigo.toUpperCase(Locale.ROOT))
                .orElseThrow(() -> new RecursoNoEncontradoException("Código de acceso no encontrado"));
    }

    private String generarCodigo() {
        StringBuilder sb = new StringBuilder("EP-");
        for (int i = 0; i < 8; i++) {
            sb.append(ALFABETO.charAt(random.nextInt(ALFABETO.length())));
        }
        return sb.toString();
    }
}
