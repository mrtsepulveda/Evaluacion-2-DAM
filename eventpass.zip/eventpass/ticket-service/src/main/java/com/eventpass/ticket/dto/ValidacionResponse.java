package com.eventpass.ticket.dto;

import com.eventpass.ticket.domain.EstadoTicket;

public record ValidacionResponse(boolean aceptado, String mensaje, String codigoAcceso, EstadoTicket estado) {
}
