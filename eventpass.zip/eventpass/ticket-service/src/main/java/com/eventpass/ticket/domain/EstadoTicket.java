package com.eventpass.ticket.domain;

public enum EstadoTicket {
    EMITIDO,
    UTILIZADO,
    ANULADO
}
