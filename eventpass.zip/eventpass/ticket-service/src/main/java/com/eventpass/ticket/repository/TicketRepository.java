package com.eventpass.ticket.repository;

import com.eventpass.ticket.domain.Ticket;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface TicketRepository extends JpaRepository<Ticket, Long> {

    @EntityGraph(attributePaths = "validaciones")
    Optional<Ticket> findByCodigoAcceso(String codigoAcceso);

    List<Ticket> findByUsuarioIdOrderByEmitidoEnDesc(Long usuarioId);

    boolean existsByOrdenId(Long ordenId);
}
