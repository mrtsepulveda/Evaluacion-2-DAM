package com.eventpass.ticket.dto;

import com.eventpass.ticket.domain.EstadoTicket;
import com.eventpass.ticket.domain.Ticket;

import java.time.Instant;

public record TicketResponse(
        Long id,
        String codigoAcceso,
        Long ordenId,
        Long eventoId,
        Long usuarioId,
        String nombreEvento,
        EstadoTicket estado,
        Instant emitidoEn
) {
    public static TicketResponse from(Ticket ticket) {
        return new TicketResponse(
                ticket.getId(),
                ticket.getCodigoAcceso(),
                ticket.getOrdenId(),
                ticket.getEventoId(),
                ticket.getUsuarioId(),
                ticket.getNombreEvento(),
                ticket.getEstado(),
                ticket.getEmitidoEn()
        );
    }
}
