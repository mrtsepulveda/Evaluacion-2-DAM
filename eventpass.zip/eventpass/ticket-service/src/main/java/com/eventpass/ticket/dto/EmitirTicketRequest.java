package com.eventpass.ticket.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record EmitirTicketRequest(
        @NotNull Long ordenId,
        @NotNull Long eventoId,
        @NotNull Long usuarioId,
        @NotBlank String nombreEvento,
        @NotNull Integer cantidad
) {
}
