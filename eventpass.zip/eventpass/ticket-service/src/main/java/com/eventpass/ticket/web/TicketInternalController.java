package com.eventpass.ticket.web;

import com.eventpass.ticket.dto.EmitirTicketRequest;
import com.eventpass.ticket.dto.TicketResponse;
import com.eventpass.ticket.service.TicketAppService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/internal/tickets")
public class TicketInternalController {

    private final TicketAppService ticketAppService;

    public TicketInternalController(TicketAppService ticketAppService) {
        this.ticketAppService = ticketAppService;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public List<TicketResponse> emitir(@Valid @RequestBody EmitirTicketRequest request) {
        return ticketAppService.emitir(request);
    }
}
