$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

Write-Host "Compilando EventPass..."
& "$root\mvnw.cmd" -q clean package -DskipTests
if ($LASTEXITCODE -ne 0) { throw "Maven falló" }

$jars = @(
    @{ Name = "api-gateway";       Jar = "api-gateway\target\api-gateway-1.0.0.jar" },
    @{ Name = "auth-service";      Jar = "auth-service\target\auth-service-1.0.0.jar" },
    @{ Name = "event-service";     Jar = "event-service\target\event-service-1.0.0.jar" },
    @{ Name = "order-service";     Jar = "order-service\target\order-service-1.0.0.jar" },
    @{ Name = "ticket-service";    Jar = "ticket-service\target\ticket-service-1.0.0.jar" },
    @{ Name = "ticket-processor";  Jar = "ticket-processor\target\ticket-processor-1.0.0.jar" }
)

New-Item -ItemType Directory -Force -Path "$root\logs" | Out-Null

foreach ($item in $jars) {
    Write-Host "Iniciando $($item.Name)..."
    Start-Process -FilePath "java" -ArgumentList "-jar", $item.Jar -WorkingDirectory $root -WindowStyle Minimized
}

Write-Host ""
Write-Host "Gateway:            http://localhost:8080"
Write-Host "Auth Swagger:       http://localhost:8081/swagger-ui.html"
Write-Host "Eventos Swagger:    http://localhost:8082/swagger-ui.html"
Write-Host "Ordenes Swagger:    http://localhost:8083/swagger-ui.html"
Write-Host "Tickets Swagger:    http://localhost:8084/swagger-ui.html"
Write-Host "Processor:          http://localhost:8085"
