# EventPass

Plataforma académica de venta de entradas para conciertos y eventos universitarios, implementada como **microservicios Spring Boot** con persistencia JPA. La compra se acepta de inmediato y la emisión del código de acceso ocurre **después**, en un proceso asíncrono, para no vender más cupos que el aforo.

## Caso de negocio

1. El comprador consulta eventos y confirma una compra.
2. La orden queda **aceptada y pendiente de emisión** (no se descuenta el aforo en ese momento).
3. Un procesador (equivalente a **AWS Lambda + Amazon SQS**) toma la orden, verifica aforo en el microservicio de Eventos y, si hay cupo, genera el código en el microservicio de Tickets.
4. Si no hay cupo, la orden se rechaza y **no** se convierte en ticket.
5. El staff de puerta valida el código. Un código usado correctamente no se puede volver a usar.

## Equivalencia con la arquitectura del caso (AWS)

| Componente del caso | Implementación local (para clonar y ejecutar) |
| --- | --- |
| Amazon API Gateway | `api-gateway` (Spring Cloud Gateway, puerto 8080) |
| Autenticación y usuarios | `auth-service` (JWT, roles COMPRADOR / STAFF / ADMIN) |
| Microservicio de Eventos | `event-service` (CRUD + reserva atómica de aforo) |
| Microservicio de Órdenes | `order-service` (aceptación inmediata) |
| Microservicio de Tickets | `ticket-service` (códigos y validación en puerta) |
| Amazon SQS | Cola de órdenes `PENDIENTE_EMISION` |
| AWS Lambda | `ticket-processor` (worker que consume la cola) |
| Base de datos relacional | H2 (por defecto) o PostgreSQL (`docker compose` + perfil `postgres`) |

Los clientes **no** llaman a los microservicios internos: todo el tráfico público entra por el gateway en `http://localhost:8080`.

## Arquitectura interna de cada servicio

```
controller  →  service  →  repository  →  entidad JPA
                 ↑
               DTOs / validación
```

Relaciones JPA relevantes:

- `Rol` 1 — N `Usuario`
- `Categoria` 1 — N `Evento` y `Recinto` 1 — N `Evento`
- `Orden` 1 — N `DetalleOrden`
- `Ticket` 1 — N `ValidacionAcceso`

## Requisitos

- JDK 17 o superior
- Maven 3.9+ (o el wrapper `mvnw` incluido)
- Opcional: Docker Desktop, para PostgreSQL

## Cómo clonar, instalar y ejecutar

```bash
git clone <url-del-repositorio>
cd eventpass
```

### 1. Compilar, testear y empaquetar (JAR)

```bash
./mvnw clean package
```

En Windows:

```bat
mvnw.cmd clean package
```

Eso genera JAR en cada `*/target/*-1.0.0.jar`.

### 2. Levantar los microservicios (H2, sin Docker)

Abra **seis terminales** en la raíz del proyecto:

```bat
mvnw.cmd -pl api-gateway spring-boot:run
mvnw.cmd -pl auth-service spring-boot:run
mvnw.cmd -pl event-service spring-boot:run
mvnw.cmd -pl order-service spring-boot:run
mvnw.cmd -pl ticket-service spring-boot:run
mvnw.cmd -pl ticket-processor spring-boot:run
```

O, después de `mvnw.cmd clean package -DskipTests`:

```bat
java -jar api-gateway\target\api-gateway-1.0.0.jar
java -jar auth-service\target\auth-service-1.0.0.jar
java -jar event-service\target\event-service-1.0.0.jar
java -jar order-service\target\order-service-1.0.0.jar
java -jar ticket-service\target\ticket-service-1.0.0.jar
java -jar ticket-processor\target\ticket-processor-1.0.0.jar
```

En Windows también puede usar `scripts\run-local.ps1`.

### 3. PostgreSQL (opcional, perfil `postgres`)

```bash
docker compose up -d
```

Luego inicie cada servicio con `-Dspring-boot.run.profiles=postgres` (o `SPRING_PROFILES_ACTIVE=postgres`).

## Puertos

| Servicio | Puerto | Consola H2 / Swagger |
| --- | --- | --- |
| API Gateway | 8080 | — |
| Auth | 8081 | http://localhost:8081/swagger-ui.html |
| Eventos | 8082 | http://localhost:8082/swagger-ui.html |
| Órdenes | 8083 | http://localhost:8083/swagger-ui.html |
| Tickets | 8084 | http://localhost:8084/swagger-ui.html |
| Processor | 8085 | — |

H2 (usuario `sa`, sin clave): `/h2-console` en cada servicio con persistencia. JDBC URL de ejemplo: `jdbc:h2:file:./data/authdb`.

## Usuarios de prueba

| Email | Password | Rol |
| --- | --- | --- |
| ana@eventpass.cl | Comprador123! | COMPRADOR |
| staff@eventpass.cl | Staff123! | STAFF |
| admin@eventpass.cl | Admin123! | ADMIN |

Eventos semilla:

1. Festival Primavera Campus (aforo 50)
2. Concierto Rock Express (aforo 2, para demostrar rechazo por cupo)

## Endpoints públicos (siempre vía gateway :8080)

| Método | Ruta | Rol | Descripción |
| --- | --- | --- | --- |
| POST | `/api/auth/registro` | público | Alta de comprador |
| POST | `/api/auth/login` | público | JWT |
| GET | `/api/usuarios/me` | autenticado | Perfil |
| GET | `/api/eventos` | público | Listado |
| GET | `/api/eventos/{id}` | público | Detalle |
| POST/PUT/DELETE | `/api/eventos` | ADMIN | CRUD catálogo |
| POST | `/api/ordenes` | COMPRADOR | Compra (aceptación inmediata) |
| GET | `/api/ordenes/mias` | COMPRADOR | Historial |
| GET | `/api/tickets/mios` | COMPRADOR | Códigos emitidos |
| POST | `/api/tickets/{codigo}/validar` | STAFF | Validación en puerta |

Las rutas `/internal/**` no se publican en el gateway.

## Pruebas con Postman

Importe `postman/EventPass.postman_collection.json`.

Flujo sugerido:

1. Login comprador → copiar `token`.
2. GET eventos.
3. POST orden `{ "eventoId": 1, "cantidad": 1 }` → estado `PENDIENTE_EMISION`.
4. Esperar ~2 segundos (processor).
5. GET órdenes mías → `EMITIDA`.
6. GET tickets míos → copiar `codigoAcceso`.
7. Login staff → POST validar código → `aceptado: true`.
8. Volver a validar el mismo código → 409, no reutilizable.

## Módulos Maven

```
eventpass/                  (POM padre)
├── eventpass-common        JWT, errores, filtros
├── api-gateway
├── auth-service
├── event-service
├── order-service
├── ticket-service
└── ticket-processor
```
