package com.eventpass.auth;

import com.eventpass.auth.repository.UsuarioRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class AuthServiceApplicationTests {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Test
    void cargaContextoYUsuariosSemilla() {
        assertThat(usuarioRepository.findByEmailIgnoreCase("ana@eventpass.cl")).isPresent();
        assertThat(usuarioRepository.findByEmailIgnoreCase("staff@eventpass.cl")).isPresent();
    }
}
