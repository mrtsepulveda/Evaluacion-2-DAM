package com.eventpass.auth.web;

import com.eventpass.auth.dto.AuthResponse;
import com.eventpass.auth.dto.LoginRequest;
import com.eventpass.auth.dto.RegistroRequest;
import com.eventpass.auth.dto.UsuarioResponse;
import com.eventpass.auth.service.AuthAppService;
import com.eventpass.common.security.UsuarioAutenticado;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class AuthController {

    private final AuthAppService authAppService;

    public AuthController(AuthAppService authAppService) {
        this.authAppService = authAppService;
    }

    @PostMapping("/auth/registro")
    @ResponseStatus(HttpStatus.CREATED)
    public AuthResponse registro(@Valid @RequestBody RegistroRequest request) {
        return authAppService.registrar(request);
    }

    @PostMapping("/auth/login")
    public AuthResponse login(@Valid @RequestBody LoginRequest request) {
        return authAppService.login(request);
    }

    @GetMapping("/usuarios/me")
    public UsuarioResponse me(@AuthenticationPrincipal UsuarioAutenticado principal) {
        return authAppService.obtener(principal.getId());
    }
}
