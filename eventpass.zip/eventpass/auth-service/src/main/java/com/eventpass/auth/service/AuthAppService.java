package com.eventpass.auth.service;

import com.eventpass.auth.domain.Rol;
import com.eventpass.auth.domain.Usuario;
import com.eventpass.auth.dto.AuthResponse;
import com.eventpass.auth.dto.LoginRequest;
import com.eventpass.auth.dto.RegistroRequest;
import com.eventpass.auth.dto.UsuarioResponse;
import com.eventpass.auth.repository.RolRepository;
import com.eventpass.auth.repository.UsuarioRepository;
import com.eventpass.common.exception.RecursoNoEncontradoException;
import com.eventpass.common.exception.ReglaNegocioException;
import com.eventpass.common.security.JwtService;
import com.eventpass.common.security.Roles;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuthAppService {

    private final UsuarioRepository usuarioRepository;
    private final RolRepository rolRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public AuthAppService(UsuarioRepository usuarioRepository,
                          RolRepository rolRepository,
                          PasswordEncoder passwordEncoder,
                          JwtService jwtService) {
        this.usuarioRepository = usuarioRepository;
        this.rolRepository = rolRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
    }

    @Transactional
    public AuthResponse registrar(RegistroRequest request) {
        if (usuarioRepository.existsByEmailIgnoreCase(request.email())) {
            throw new ReglaNegocioException("El correo ya está registrado");
        }
        Rol rolComprador = rolRepository.findByNombre(Roles.COMPRADOR)
                .orElseThrow(() -> new RecursoNoEncontradoException("Rol COMPRADOR no configurado"));
        Usuario usuario = new Usuario();
        usuario.setEmail(request.email().toLowerCase());
        usuario.setPasswordHash(passwordEncoder.encode(request.password()));
        usuario.setNombre(request.nombre());
        usuario.setRol(rolComprador);
        usuarioRepository.save(usuario);
        return tokenDe(usuario);
    }

    @Transactional(readOnly = true)
    public AuthResponse login(LoginRequest request) {
        Usuario usuario = usuarioRepository.findByEmailIgnoreCase(request.email())
                .orElseThrow(() -> new RecursoNoEncontradoException("Credenciales inválidas"));
        if (!usuario.isActivo() || !passwordEncoder.matches(request.password(), usuario.getPasswordHash())) {
            throw new ReglaNegocioException("Credenciales inválidas");
        }
        return tokenDe(usuario);
    }

    @Transactional(readOnly = true)
    public UsuarioResponse obtener(Long id) {
        return usuarioRepository.findById(id)
                .map(UsuarioResponse::from)
                .orElseThrow(() -> new RecursoNoEncontradoException("Usuario no encontrado"));
    }

    private AuthResponse tokenDe(Usuario usuario) {
        String token = jwtService.generar(usuario.getId(), usuario.getEmail(), usuario.getRol().getNombre());
        return new AuthResponse(token, "Bearer", UsuarioResponse.from(usuario));
    }
}
