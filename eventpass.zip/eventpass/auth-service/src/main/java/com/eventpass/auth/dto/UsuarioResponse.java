package com.eventpass.auth.dto;

import com.eventpass.auth.domain.Usuario;

public record UsuarioResponse(Long id, String email, String nombre, String rol, boolean activo) {
    public static UsuarioResponse from(Usuario usuario) {
        return new UsuarioResponse(
                usuario.getId(),
                usuario.getEmail(),
                usuario.getNombre(),
                usuario.getRol().getNombre(),
                usuario.isActivo()
        );
    }
}
