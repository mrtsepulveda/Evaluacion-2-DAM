package com.eventpass.auth.config;

import com.eventpass.auth.domain.Rol;
import com.eventpass.auth.domain.Usuario;
import com.eventpass.auth.repository.RolRepository;
import com.eventpass.auth.repository.UsuarioRepository;
import com.eventpass.common.security.Roles;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DatosIniciales {

    @Bean
    CommandLineRunner seedAuth(RolRepository roles, UsuarioRepository usuarios, PasswordEncoder encoder) {
        return args -> {
            Rol admin = upsertRol(roles, Roles.ADMIN, "Administración de catálogo");
            Rol comprador = upsertRol(roles, Roles.COMPRADOR, "Compra de entradas");
            Rol staff = upsertRol(roles, Roles.STAFF, "Validación en puerta");
            upsertUsuario(usuarios, encoder, "admin@eventpass.cl", "Admin123!", "Admin EventPass", admin);
            upsertUsuario(usuarios, encoder, "ana@eventpass.cl", "Comprador123!", "Ana Compradora", comprador);
            upsertUsuario(usuarios, encoder, "staff@eventpass.cl", "Staff123!", "Pedro Staff", staff);
        };
    }

    private Rol upsertRol(RolRepository roles, String nombre, String descripcion) {
        return roles.findByNombre(nombre).orElseGet(() -> roles.save(new Rol(nombre, descripcion)));
    }

    private void upsertUsuario(UsuarioRepository usuarios, PasswordEncoder encoder,
                               String email, String password, String nombre, Rol rol) {
        if (usuarios.existsByEmailIgnoreCase(email)) {
            return;
        }
        Usuario usuario = new Usuario();
        usuario.setEmail(email);
        usuario.setPasswordHash(encoder.encode(password));
        usuario.setNombre(nombre);
        usuario.setRol(rol);
        usuarios.save(usuario);
    }
}
