package com.eventpass.auth.dto;

public record AuthResponse(String token, String tipo, UsuarioResponse usuario) {
}
